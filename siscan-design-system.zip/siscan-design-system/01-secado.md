# Secado y estados

El vocabulario es el mismo en el portal, la app, el reloj y el firmware del ESP32.

## Proceso del lote

| Fase | Código | Qué pasa |
|---|---|---|
| Inicio | `inicio` | Se registra el lote y se pesa la muestra inicial |
| Calentamiento | `calentamiento` | La cámara sube a la temperatura del protocolo |
| Secado activo | `secado` | Se retira el agua libre del grano |
| Reducción de humedad | `reduccion` | El grano baja hacia 12 %; se pesa cada mañana |
| Ajustes | `ajustes` | Correcciones finas de temperatura y aire cerca del objetivo |
| Finalización | `final` | La muestra está en 10 – 12 % y se cierra el lote |

`ProcessTimeline` las muestra: pasadas con ✓ y hora, la actual con halo y «En curso», las siguientes «Pendiente».

## Dónde se seca

Cada lote es **Secador** (con protocolo, p. ej. «Continuo · 40 °C») o **Aire libre** (testigo). La comparación de protocolos usa horas hasta 40 %, horas hasta el objetivo, energía y costo.

## Escala de humedad del grano

| Rango | Nombre | Color |
|---|---|---|
| > 30 % | Húmedo | `cafe` |
| 20 – 30 % | Oreado | `cafe` → `pergamino` |
| 12 – 20 % | Secando | `pergamino` |
| 10 – 12 % | Objetivo alcanzado | banda `objetivo` + `operando` |
| < 10 % | Sobresecado | `pausa` |

## Método gravimétrico (conservación de materia seca, Cenicafé)

- Materia seca = muestra inicial × (1 − humedad inicial). Con 200 g al 53 %: 94,0 g.
- Humedad actual = 1 − materia seca / peso actual. 107,3 g → 12,4 %.
- Peso de retiro para el objetivo H = materia seca / (1 − H). Para 10 – 12 %: **entre 104,4 y 106,8 g**.
- Veredicto: «Todavía le falta secar», «Está en el rango comercial: retíralo» o «Ya pasó el punto: está sobre-secado».
- Sin medidor, la humedad inicial usa la referencia Cenicafé de 53 %; con medidor, los puntos medidos ajustan la curva.

## Estado del secador

| Estado | Token | Ícono | Texto |
|---|---|---|---|
| En operación | `operando` | punto | «En operación», «Secando» |
| En pausa | `pausa` | dos barras | «En pausa» |
| Alerta | `alerta` | triángulo | «Alerta» |
| Sin conexión | `fuera` | wifi tachado | «Sin conexión · último dato 07:12» |

## Actuadores

Ventilador principal (120 W) y resistencia (1.500 W). Estados: Encendido, Apagado, Encendiendo… / Apagando… (esperando al ESP32), Bloqueado por seguridad (p. ej. tope sobre 48 °C). Modo Automático (manda el protocolo, interruptores de solo lectura) o Manual.

## Rangos de alerta por defecto

| Magnitud | Advertencia | Crítica |
|---|---|---|
| Temperatura tope | 45 – 48 °C | > 48 °C (daña el grano; bloquea la resistencia) |
| Humedad relativa interior | > 70 % | > 80 % |
| Humedad del grano | < 11 % sin cerrar lote | < 9 % |
| Reporte del ESP32 | sin dato 2 min | sin dato 10 min → sin conexión |
