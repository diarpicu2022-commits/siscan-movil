# Datos y gráficas

## Tarjeta de métrica

`MetricCard`: ícono + nombre arriba, valor en `lectura` con unidad en `lectura-unidad`, variación en `apoyo` (↑/↓ con color: hacia el objetivo `operando`, alejándose `pausa`), y una línea de tendencia de 24 h en el color de la magnitud con área al 12 %. El último punto lleva un círculo; si el dato está en vivo, late.

## Colores fijos por magnitud

Temperatura interior y tope `dato-temperatura` · Humedad relativa `dato-humedad` (esmeralda) · Exterior y red eléctrica `dato-exterior` · Humedad del grano `dato-grano` (café) · Solar `dato-solar-relleno` (verde de las hojas del logo) · Potencia `pausa` · Objetivo `objetivo` · Predicción de IA `prediccion` (violeta, línea punteada).

Nunca cambies el color de una magnitud entre pantallas: el técnico aprende a leer el color.

## Reglas de gráfica

- Rejilla horizontal en `linea`, sin rejilla vertical; ejes en `apoyo` con `tinta-suave`.
- La curva de humedad del grano usa área con degradado vertical (24 % → 0 %), puntos en cada día y el último valor en una etiqueta oscura `bosque` con texto `sobre-bosque` («12,4 %»).
- Banda de objetivo 10 – 12 % siempre visible en gráficas de humedad del grano.
- Barras de energía: solar abajo en degradado `brote-vivo` → `lima`, red arriba en `dato-electrica`, esquinas de 5px, como en el panel aprobado.
- La predicción de IA continúa la curva con línea punteada `prediccion` y un punto hueco; nunca se pinta igual que un dato medido.
- Cada gráfica lleva un resumen de una línea debajo o como `aria-label`.
- Al cargar, la curva se dibuja en `dur-lenta` (por evento). Con datos en vivo no se redibuja todo: solo se agrega el punto nuevo.

## Mapa de secadores

`DryerMap` es un mapa esquemático del departamento de Nariño (relieve, curvas de nivel, río, vía y municipios: Pasto, Chachagüí, La Unión, Sandoná, Ipiales), no una foto satelital: así carga sin conexión y se lee en ambos temas. Cada secador es un pin con el color de su estado; los pines en alerta tienen una onda (siempre, mientras dure la alerta). Al lado, la leyenda con conteos por estado.

## Tablas

`BatchTable`: filas de 52px, encabezado en `etiqueta`, cifras alineadas a la derecha con tabulares, estado en píldora, y la fila del lote activo en `superficie-hoja`.
