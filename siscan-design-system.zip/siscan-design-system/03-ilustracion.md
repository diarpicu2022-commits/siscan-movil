# Ilustración

La escena de SISCAN está dibujada en vectores (`Landscape`), en capas planas con luz suave, para que funcione sin conexión y en los dos temas.

## Qué contiene

- Cielo con degradado, sol con halo, nubes y aves (de día).
- Tres cordilleras con bruma en el horizonte, como las montañas de Nariño.
- Casa campesina de paredes claras y teja roja; un guamo de sombra.
- Surcos de cafetal con matas en tres verdes y **cerezas rojas**.
- Camino de tierra y pasto en primer plano.
- El **secador solar parabólico**: base de madera sobre patas, cubierta plástica transparente con costillas y reflejos, dos bandejas con café pergamino, puerta, **panel solar** en poste y la **caja del ESP32** con su led.

## Variantes

- `day`: secado solar; el aire fluye dentro del secador cuando el ventilador opera.
- `dusk`: atardecer; la resistencia encendida tiñe el interior.
- `night`: secado eléctrico nocturno; estrellas, luna, ventanas encendidas y brillo cálido en las bandejas.

## Dónde va

- **Ingreso web**: la escena completa de fondo; la tarjeta del formulario flota sobre ella.
- **Ingreso Android**: arriba, con el formulario en una hoja inferior.
- **Cabecera del panel y del lote**: detrás de la tarjeta de vidrio con la humedad del grano.
- **Foto del secador**, **lote activo** (viñeta) y **estados vacíos**.

Nunca en tablas, gráficas, formularios de ajustes ni alertas. Sin personas ni mascotas: el protagonista es el café.

## El grano con hojas

El dibujo a mano del grano con hojas es el sello del menú lateral: esquina inferior izquierda, versión clara, 20 % de opacidad. No se usa como ícono.
