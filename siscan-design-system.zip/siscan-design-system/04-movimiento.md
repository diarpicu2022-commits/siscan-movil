# Movimiento

En SISCAN el movimiento dice una de dos cosas: **«esto está funcionando ahora»** o **«esto acaba de cambiar»**. Cada animación es de una clase.

| Clase | Cuándo | Para qué | Regla |
|---|---|---|---|
| **Siempre** | Mientras el estado exista | Mostrar que un equipo o un dato está vivo | Lento y suave; se detiene en cuanto el estado termina |
| **Por evento** | Una vez, cuando algo cambia | Confirmar y orientar | Corto, nunca en bucle |
| **Nunca** | — | — | Fondos animados, partículas, parpadeos, cifras que saltan en cada muestra |

## Siempre

| Elemento | Movimiento | Token | Se detiene cuando |
|---|---|---|---|
| Ícono de ventilador encendido | Gira | `dur-ventilador`, lineal | Se apaga el ventilador |
| Punto «En vivo» y último punto de cada serie | Late (escala y halo) | `dur-latido` | El secador pasa a fuera de línea |
| Aire dentro del secador ilustrado | Líneas que fluyen | `dur-aire`, lineal | Ventiladores apagados o lote en reposo |
| Resistencia encendida | Brillo suave del ícono y del interior del secador | `dur-latido` | Se apaga |
| Led del ESP32 en la ilustración | Parpadeo | `dur-latido` | El secador deja de reportar |
| Interruptor esperando al ESP32 | Giro pequeño junto a «Encendiendo…» | 700ms, lineal | Llega la confirmación |
| Pin de mapa en alerta | Onda que se expande | `dur-latido` | Se atiende la alerta |

## Por evento

| Evento | Movimiento | Token |
|---|---|---|
| Llega una lectura nueva | La cifra sube 6px y aparece | `dur-media`, `ease-entrada` |
| Carga una gráfica | La curva se dibuja de izquierda a derecha | `dur-lenta`, `ease-entrada` |
| Carga un anillo o barra de progreso | Se llena desde cero | `dur-lenta`, `ease-entrada` |
| Llega una alerta | Entra desde la derecha con fundido | `dur-media`, `ease-entrada` |
| Cambias un interruptor | El botón se desliza | `dur-rapida` |
| Cambias de página o de pestaña | Fundido y desliz de 8px | `dur-media` |
| Mantienes presionado para encender (móvil) | La barra se llena; al completar, check | mientras se presiona |
| Confirmación en el reloj | Círculo y check que se dibujan + vibración corta | `dur-lenta` |

## Reglas

- Como máximo **tres** animaciones de clase Siempre visibles en una pantalla.
- La alerta no se mueve más rápido ni más grande que lo demás: sube por color, ícono y posición.
- El panel actualiza datos cada 30 s; la cifra anima solo si el valor cambió.

## Movimiento reducido

Con `prefers-reduced-motion`: el ventilador queda quieto (el estado se lee en la píldora «Encendido»), el punto en vivo queda lleno, el aire y las ondas desaparecen y todo lo de evento se vuelve inmediato.
