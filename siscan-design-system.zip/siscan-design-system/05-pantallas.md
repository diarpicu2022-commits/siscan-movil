# Pantallas

Todas están en los grupos «Web · pantallas», «Android · pantallas» y «Smartwatch · pantallas».

## Web

Menú: **Monitoreo · Lotes · Gravimétrico · Actuadores · Calibración · Historial · Alertas · Mapa**, con selector de secador arriba y estado del ESP32 abajo.

- **Ingreso**: escena completa, logo en placa translúcida, frase y datos vivos a la izquierda, tarjeta blanca flotante a la derecha. Sin divisiones.
- **Monitoreo**: cabecera con el lote sobre la ilustración; cinco lecturas; curva con predicción; energía; mapa y «¿Está funcionando el equipo?»; a la derecha predicción, actuadores, alertas y clima.
- **Lotes**: historial filtrable, comparación de protocolos, estado vacío.
- **Detalle de lote**: proceso en seis fases, curva, predicción, condiciones y pesajes.
- **Nuevo lote**: formulario con peso de retiro calculado.
- **Gravimétrico**: rango de retiro, veredicto, registrar y corregir pesajes, finalizar secado.
- **Actuadores**: modo, interruptores con confirmación del ESP32, bloqueo por seguridad, órdenes, sensores y energía por actuador.
- **Calibración**: Gravimet, ubicación del secador y corrección de sensores.
- **Historial**: órdenes y energía.
- **Alertas** y **Mapa**.

## Android

Barra inferior: **Inicio · Lotes · Pesaje · Equipo · Más**.

- Pantalla de carga, Ingreso (escena + hoja inferior) e Ingreso con huella.
- **Inicio**: encabezado `bosque` con el anillo de humedad del grano, lecturas en cuadrícula, equipo y alertas.
- **Lote** (curva, predicción, proceso vertical) y **Nuevo lote**.
- **Pesaje**: cifra grande con − y +, humedad resultante, rango de retiro, lista.
- **Equipo**: modo, actuadores, «mantén presionado para encender», sensores.
- **Alertas**, **Más** (perfil, calibración, mapa, historial, ubicación, reloj, notificaciones, huella, cerrar sesión), **Calibración** y **Mapa**.
- Fuera de la app: widgets 4×2 y 2×2, notificaciones con acciones y actividad del lote en la pantalla de bloqueo.

## Estados de carga y error

- Cargando: «Cargando el estado del secador…» con esqueletos en `superficie-fuerte`.
- Sin conexión: «El secador no reporta desde las 07:12» en `fuera-suave`, con el último dato y «Reintentar».
- Error de servidor: «No fue posible cargar estos datos» + Reintentar (se reintenta solo cada 30 s).
