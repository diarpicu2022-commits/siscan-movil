# Arquitectura y datos

Identificadores en inglés; textos visibles en español.

## Fuentes de datos

ESP32 (PlatformIO, C++17, doble núcleo) → API REST de WordPress en `cisna.narino.gov.co` → portal web, app Android (Flutter) y app de reloj (Wear OS, Jetpack Compose). Ninguna habla directo con el ESP32; el reloj recibe los datos del teléfono (Data Layer) y, si está solo, de la API por wifi.

## Tokens en código

- Web: `tokens.css` (variables CSS generadas de `tokens.json`) con `[data-theme="oscuro"]`.
- Wear OS: `ui/theme/SiscanWearTheme.kt` con los tokens del tema oscuro; componentes con `androidx.wear.compose.material3` (TimeText, ScalingLazyColumn, Chip, ToggleChip, CircularProgressIndicator) vestidos con estos colores.
- Flutter: `lib/core/theme/siscan_tokens.dart` con `SiscanColors` como `ThemeExtension` (claro y oscuro), `SiscanType`, `SiscanSpace`, `SiscanRadius`, `SiscanMotion`. Nombres en camelCase: `superficie-hoja` → `superficieHoja`, `dato-temperatura` → `datoTemperatura`.

## Modelos

`Dryer` (id, nombre, sitio, latitud, longitud, ubicación bloqueada, foto, estado, último dato), `Batch` (nombre, variedad, sitio `dryer` | `open_air`, protocolo, fase `inicio` … `final`, ingreso, muestra Gravimet, humedad inicial, objetivo), `Weighing` (hora, peso, humedad calculada, corregido), `Prediction` (restante, mínimo, máximo, confianza, entradas), `Command` (hora, actuador, acción, origen, confirmado), `Reading` (timestamp, temperatura, humedad de cámara, humedad exterior, humedad del grano, radiación), `Actuator` (tipo `fan` | `heater`, índice, encendido, modo `auto` | `manual`, último cambio), `Sensor` (tipo `dht22` | `capacitive` | `pyranometer` | `loadcell`, canal del 74HC4051, último dato), `EnergyReading` (kWh solar, kWh red, costo COP), `GravimetricSample`, `Alert` (tipo, severidad `warning` | `critical`, secador, valor, creado, atendido), `Threshold`.

## Componentes → código

| Componente | Web | Flutter (Android) | Compose (Wear OS) |
|---|---|---|---|
| `MetricCard` / `ReadingTile` | `Siscan.MetricCard` | `MetricCard` con `fl_chart` | `Chip` de lectura |
| `MoistureChart` | `Siscan.MoistureChart` | `MoistureChart` (`fl_chart`) | — |
| `ActuatorControl` | `Siscan.ActuatorControl` | `ActuatorControl` + `HoldButton` | `ToggleChip` |
| `PredictionCard` | `Siscan.PredictionCard` | `PredictionCard` | `WatchPrediction` |
| `WeighingPanel` | `Siscan.WeighingPanel` | pantalla Pesaje | `WatchWeigh` (corona) |
| `Sidebar` / `AndroidNav` | `Siscan.Sidebar` | `NavigationBar` M3 con indicador salvia | `ScalingLazyColumn` |
| `WatchArc` | — | — | `CircularProgressIndicator` con hueco arriba |
| `NotificationCard` / `HomeWidget` | — | notificación local + `home_widget` | `Tile` |

## Reglas

- La lógica (umbrales, fases, cálculo gravimétrico) vive en servicios, no en los componentes: `ThresholdService`, `BatchService`, `GravimetricCalculator`, `EnergyService`.
- Los datos se refrescan cada 30 s; si fallan, se muestra el último valor con su hora.
- Cambiar un actuador manualmente envía la orden, muestra «Enviando…» y confirma solo cuando el ESP32 reporta el nuevo estado.
