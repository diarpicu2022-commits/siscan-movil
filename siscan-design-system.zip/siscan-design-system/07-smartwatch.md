# Smartwatch (Wear OS)

El reloj responde de un vistazo: ¿cómo va el grano?, ¿funciona el equipo?, ¿hay algo que revisar? Y permite dos acciones rápidas: encender o apagar un actuador y registrar un pesaje.

## Reglas

- Siempre tema `oscuro` sobre negro (OLED), con un leve tinte verde arriba. Texto blanco para cifras, `tinta-suave` para lo secundario.
- Hora curva en el borde superior; el arco de progreso deja libre la parte de arriba.
- Una idea por pantalla, máximo tres datos. Cifras en Outfit, 34 – 56px.
- Chips a lo ancho de 48px de alto; botones redondos de 48px.
- Se navega con la corona (desplazamiento vertical) y deslizando entre tarjetas.

## Fuera de la app

- **Esfera con complicaciones**: humedad del grano en anillo, temperatura interior y número de alertas.
- **Tarjeta (Tile)**: lote, anillo, temperatura, tiempo restante y «Abrir».
- **Siempre activo**: solo contornos, sin color de estado ni animación.

## La app

- **Monitoreo**: arco de avance, humedad del grano, objetivo y estado del lote.
- **Lecturas**: interior, tope, humedad relativa y exterior.
- **Equipo**: chips que encienden y apagan; el ventilador gira y la resistencia brilla.
- **Predicción**: «Listo en 5 h 40», rango y confianza en `prediccion`.
- **Lotes**: lista con humedad final.

## Acciones

- **Alerta**: pantalla completa tintada (roja crítica, ámbar advertencia), ícono, dato y dos botones (descartar, ver). Vibración: un pulso para advertencia, doble para crítica.
- **Registrar pesaje**: − y + de 0,1 g (o la corona), humedad resultante y rango de retiro; «Guardar».
- **Confirmación**: el círculo y el check se dibujan; vibración corta; se cierra sola a los 2 s.
