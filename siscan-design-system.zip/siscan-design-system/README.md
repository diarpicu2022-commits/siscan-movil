SISCAN — *Secado Inteligente de Café* — es el ecosistema digital (portal web + app Flutter) de un secador híbrido solar‑eléctrico de café en Nariño. Su identidad es **gouache de cuento con precisión de instrumento**: paisajes pintados en capas planas y cálidas donde vive el proceso, y lecturas en una tipografía de instrumento que nunca miente sobre de dónde viene un dato. Agrícola sin ser rústico, técnico sin ser frío, cálido sin parecer una cafetería.

Toda la interfaz responde, en este orden, a cinco preguntas: **¿Cómo está el secado? · ¿Está funcionando el equipo? · ¿Cuánto falta? · ¿Hay algo que deba revisar? · ¿Cómo se comportó este lote?** Una pantalla que no ayuda a responder alguna de ellas sobra.

## Voz y contenido

- Todo texto visible va en **español de Colombia**, con *tú*: "Verifica la conexión del dispositivo", "Intenta nuevamente". Código, nombres de componentes y tipos en inglés (`<SensorReading />` muestra "Temperatura interior").
- Mayúscula solo inicial ("Gestión gravimétrica", no "Gestión Gravimétrica"). Las MAYÚSCULAS espaciadas son exclusivas de los rótulos de instrumento (`etiqueta` + clase `sc-rotulo`) y del código de lote ("LOTE B").
- Cifras con punto decimal y espacio antes de la unidad: `40.5 °C`, `14.5 %`, `210 W`, `1 250.0 g`. Duraciones como `18 h 20 min` (usa `Siscan.Duration`, que reduce las unidades).
- Estados en palabras cortas y concretas: "Proceso dentro del rango esperado", "Revisión recomendada", "Atención requerida". Errores humanos, nunca técnicos: "No pudimos cargar los datos del lote. Intenta nuevamente." — jamás "500 Internal Server Error".
- La IA habla como asistente de investigación: "Predicción de IA", "Tiempo restante estimado", "Confianza de la predicción", "Datos considerados". Prohibido: "predicción perfecta", "100 % garantizado", "IA revolucionaria".
- Sin emoji. Los glifos de estado (✓ círculo, ▲ triángulo, ■ cuadrado, ⊘, reloj) vienen de `Siscan.Glyph`/`StatusMark`, nunca de caracteres.
- Nombres de lote reales y verosímiles: "Café Supremo — Lote B", "Café Castillo — Lote A", "Café Caturra — Lote C".

## Color

La paleta sale del patio de secado a media mañana: pergamino al sol, arcilla de las estructuras, verde de cafetal, panela, óxido, bruma de la cordillera y añil del panel solar.

- **Superficies.** Página en `pergamino`; hojas, paneles y formularios en `papel`; pistas, filas alternas y campos de solo lectura en `arena`. Texto en `tierra` (principal) y `tierra-suave` (unidades, marcas de tiempo, ayudas) — ambos superan 4.5:1 en las tres superficies y en todos los `*-suave`.
- **Identidad.** `monte` (verde profundo de cafetal en sombra) es el bloque de marca: barra lateral, banda superior móvil. Sobre él, texto `sobre-monte` / `sobre-monte-suave` y foco `foco-sobre-monte`.
- **Acción.** `arcilla` es la única acción principal por vista (botón primario, pestaña activa, enlace). Presionado: `arcilla-fuerte`. Texto sobre ella: `sobre-arcilla`.
- **Estado del proceso.** `cafeto` = normal / encendido / objetivo alcanzado. `panela` = atención y **modo manual**. `oxido` = crítico, error, anomalía. `bruma` = información neutral y ambiente. Cada uno tiene su `*-suave` como fondo; el texto de color siempre va sobre su propio `*-suave`, `papel` o `pergamino`.
- **Nunca solo color.** `cafeto` y `oxido` se distinguen por tono pero casi no por luminosidad: cada estado lleva SIEMPRE glifo + palabra (`StatusMark`). `oxido` y `arcilla` son vecinos: lo crítico se reconoce por el glifo cuadrado "!" y el contorno, no por el rojo.
- **Pinturas.** `pintura-*` (cielo, sol, cordillera, loma, cafetal, hoja, cereza, barro, niebla) son exclusivas de la ilustración. Nunca comunican estado ni llevan texto encima, salvo `tierra` sobre `pintura-sol`.

## Medido · Estimado · Predicción

Ningún número aparece sin su procedencia. `Provenance` dibuja la muestra de trazo junto a la palabra, y los gráficos usan exactamente esos trazos:

| Procedencia | Token | Trazo | Ejemplo |
|---|---|---|---|
| Medido | `dato-medido` (= `tierra`) | continuo 2.5 px, puntos | lectura del DHT, peso en balanza |
| Estimado | `dato-estimado` (= `bruma`) | discontinuo 5‑3 | humedad calculada por gravimetría |
| Predicción | `dato-prediccion` (= `anil`) | punteado + banda `anil-suave` | tiempo restante de la IA |
| Objetivo | `dato-objetivo` (= `cafeto`) | raya‑punto | 11 % de humedad final |
| Desactualizado / No disponible | `linea-fuerte` | punteado fino, valor en `tierra-suave` sobre rayado | sensor sin datos hace 14 min |

Una cifra predicha se escribe en `anil`; una medida, en `tierra`. Nunca al revés, nunca iguales.

## Temas

- **Día** (`dia`, primero): el uso normal, en oficina o laboratorio.
- **Pleno sol** (`sol`): para la app de campo bajo sol directo. Fondos más blancos, tintas más oscuras (texto ≥ 12:1, colores de estado ≥ 8:1), `linea` y `linea-fuerte` mucho más marcadas y `sombra-hoja` sustituida por un borde — las sombras desaparecen al sol. Actívalo con `data-theme="sol"`; en Flutter, con el sensor de luz o un interruptor en Ajustes.

## Tipografía

Tres voces, cada una con un trabajo:

- **Fraunces** (variable, eje `SOFT` 100) — la voz editorial de publicación agrícola. `display` para el nombre del lote activo (una vez por pantalla), `titulo` para la página, `seccion` para las preguntas guía, `cita` (itálica) para la variedad del lote, el veredicto del proceso y la explicación de la IA. Los estilos ya aplican `SOFT 100`; el wordmark "SISCAN" usa además `WONK 1`.
- **Atkinson Hyperlegible Next** — la interfaz: `cuerpo`, `cuerpo-fuerte`, `etiqueta`, `nota`. Diseñada para baja visión: es la elección para leer a pleno sol con una mano.
- **Atkinson Hyperlegible Mono** — el instrumento: `lectura-xl` (la humedad dominante), `lectura`, `lectura-s`, `tabla`. Toda cifra medible, código de lote, eje de gráfico y celda numérica va en mono con cifras tabulares, alineada a la derecha en tablas.

Nunca pongas una lectura en Fraunces ni un título en mono.

## Forma y superficie

- Radios por significado, no por costumbre: `radio-etiqueta` (4 px) para lo preciso — rótulos, chips de procedencia, celdas, campos de medición; `radio-control` (10 px) para lo que se acciona — botones, palancas (un balancín físico, no una píldora); `radio-hoja` (20 px) para hojas de papel; `radio-loma` (40 px) para bloques grandes y orgánicos como el héroe del lote; `radio-grano` solo para marcas redondas.
- Formas propias: la **etiqueta de costal** (`BatchTag`, esquinas cortadas, ojal y costura en `arcilla`) es el registro físico del lote; los contenedores de icono usan la "hoja" asimétrica `12 12 12 4`; la pestaña activa de la barra lateral se funde con la página con esquinas invertidas.
- `sombra-hoja` levanta hojas sobre `pergamino`. `sombra-control` (sombra dura de 3 px) es para controles físicos — la palanca del actuador y el botón de mantener presionado. Los botones sólidos y los sellos de estado sólidos llevan el mismo canto de 3 px en el tono profundo de su color (son pulsadores); nada más lleva sombra dura. Sin glassmorphism: las superficies son sólidas.
- Bordes: `linea` para filetes decorativos; `linea-fuerte` (≥ 3:1) para todo borde que delimita un control.

## Ilustración

Gouache de cuento: capas planas superpuestas (cielo → cordillera → lomas → hileras de cafetos → primer plano), bordes ligeramente vivos (desplazamiento de ruido) y un grano fino. Sin contornos dibujados, sin degradados, sin personajes, sin robots. El motivo central es el **secador parabólico** con su cubierta `pintura-niebla`, marco `arcilla`, granos `pintura-barro` y panel solar `anil`, entre hileras de cafetal con alguna cereza.

Usa `Landscape` (`valle`, `vacio`, `loma`; `wide` para bandas) en el héroe del lote, estados vacíos, incorporación y la base de la barra lateral. Nunca dentro de tarjetas de sensor, tablas ni formularios: las pantallas técnicas son técnicas.

## Iconografía

Familia propia de 27 iconos (`Siscan.Icon`, y como SVG en el grupo *Iconos*): rejilla de 24 px, trazo redondo `trazo-icono` (1.75 px), uniones redondas y **un único punto de medición relleno** por icono — el bulbo del termómetro, el centro del ventilador, el ojal de la etiqueta. Hereda el color del texto (`currentColor`). Tamaños: 16 en rótulos, 20 en navegación, 22–24 en tarjetas, 28 en móvil. Contenedor opcional: hoja `arena` de 38–44 px. No mezcles otras librerías de iconos ni emoji.

## Botones, estados y procedencia

Son las piezas más repetidas, así que llevan la identidad con más fuerza:

- **Botones** con hoja de icono (la forma `12 12 12 4` de los contenedores), peso físico (borde inferior de 3 px en el tono profundo, se hunden al presionar) y un **tono por intención**: `arcilla` acción, `cafeto` encender/confirmar, `bruma` sincronizar, `anil` predicción, `panela` manual, `oxido` detener. Variantes sólido, suave, secundario y silencioso (subrayado ondulado, como un surco).
- **Sellos de estado** (`StatusMark`): glifo dentro de un sello + palabra, en píldora suave, sólida con halo cuando el estado es el mensaje, o en línea dentro de frases.
- **Chips de procedencia** (`Provenance`): una miniatura del trazo del gráfico sobre una hoja del color del dato — así "Medido", "Estimado" y "Predicción" se reconocen igual en un chip que en una curva.

## Datos y gráficos

- Lidera con el proceso, no con KPIs: el héroe agrupa humedad (dominante), temperatura, tiempo, tiempo restante y consumo como una secuencia unida por flechas punteadas — nunca nueve tarjetas iguales.
- La humedad se muestra como **lecho de secado** (`MoistureMeter`): el agua por retirar (`dato-agua`) se encoge sobre un lecho de granos; lo retirado queda punteado; el objetivo es una bandera `cafeto`. No uses anillos de fitness.
- Curvas: medida continua, predicción punteada con banda de incertidumbre, zona objetivo `cafeto-suave`, marca "Ahora" y anomalías como cuadrados `oxido` con "!". Ejes en `tabla` `tierra-suave`, rejilla `linea`. Sin arcoíris, sin azul genérico, sin leyendas largas.
- Confianza de la IA = **regla de confianza**: pista hundida con tres zonas (Baja < 60, Media 60–79, Alta ≥ 80), relleno `anil` rayado hasta el valor y una aguja de papel; el nivel también va en palabra ("Alta") junto a la cifra. Nunca un anillo.
- Densidad según la tarea: Monitoreo, Calibración y Gravimetría densos y precisos; Lotes e Historial medios; Predicción y móvil bajos.

## Controles físicos y seguridad

- `ActuatorControl` es una palanca con peso (`sombra-control`): "ENC"/"APAG" grabados, perilla con estrías, estado en palabra grande. Las transiciones se muestran ("Encendiendo…" → "Encendido") y el fallo se explica ("No fue posible encender el ventilador. Verifica la conexión del dispositivo.").
- **Automático vs. manual** debe verse desde lejos: el modo manual tiñe el control de `panela` y contornea la tarjeta.
- Las **resistencias** son guardadas: solo en modo manual, se encienden **manteniendo presionado** 1.5 s, con advertencia `panela` visible. Apagar siempre es inmediato.

## Movimiento

Todo se mueve, pero con la lógica del proceso físico: lo que está vivo se mueve **siempre** (despacio, sin distraer); lo que pide atención se mueve **de vez en cuando** (un gesto breve cada 4–9 s); lo que el usuario toca **responde** al instante. Nunca parpadeo.

**Permanente — el proceso vivo**
- Paisaje (`Landscape animated`): nubes que derivan, vapor que sube del secador, halo del sol que respira, árboles que se mecen.
- Humedad (`MoistureMeter`): al entrar, la cifra **baja** desde la humedad inicial hasta la actual y el agua se encoge — el secado en 1.6 s; luego sale vapor del agua por retirar y la bandera del objetivo ondea.
- Curva: la medida se dibuja al entrar; la predicción **fluye** hacia el objetivo; el punto "Ahora" emite un anillo.
- Héroe: las flechas punteadas entre lecturas corren de izquierda a derecha (el proceso avanza).
- Predicción: la regla se llena al entrar y sus rayas avanzan; la trama de puntos deriva. Chips de procedencia: el trazo de Predicción y Estimado se mueve; el de Medido queda quieto (es un hecho).
- Equipo: el ventilador encendido gira; la palanca encendida tiene energía corriendo; la resistencia encendida irradia calor `panela`.
- Marcadores en vivo, sellos `live` y la etapa en curso de la línea del proceso laten.

**Ocasional — atención y vida**
- Lecturas (`SensorReading simulate`, `ActiveBatchHero simulate`): cada 4–7 s llega un valor nuevo, la cifra se ilumina en `bruma`, aparece una flecha de tendencia ▲/▼ y "Ahora / Hace N s" se reinicia. La regla del sensor hace un barrido de lectura.
- Botón sólido: un destello de luz cruza cada ~7 s. Contadores (`badge`) dan un salto.
- Sellos de advertencia y crítico se sacuden levemente; la alerta crítica agita su icono; la advertencia flota.
- La etiqueta del lote en el héroe se mece como colgada de su ojal; el icono de predicción "piensa"; la mano del modo manual saluda.

**Respuesta — al tocar**
- Hojas (sensores, alertas, actuadores, gráficos) se levantan 3 px y su icono se inclina; botones suben, se hunden al presionar y su hoja de icono gira; la navegación asoma el icono.
- Formularios: la hoja del campo se vuelve `anil` al enfocar, el error sacude el campo, la casilla traza su marca, el botón pasa de "Verificando…" a `cafeto`.

**Entrada.** Toda hoja sube 14 px al aparecer, escalonada 80 ms entre hermanas; en páginas: encabezado → lote activo → sensores → predicción → alertas. Utilidades en `bundle.css`: `sc-enter` (con `--d` para el retraso), `sc-sheet-up`, `sc-fade`, `sc-float`, `sc-bubble`.

**Movimiento reducido.** Con `prefers-reduced-motion: reduce` se detiene toda animación del sistema (incluido el conteo de cifras, que salta al valor final); los cambios de estado siguen visibles por palabra, glifo y color.

## Accesibilidad

- Texto ≥ 4.5:1 en ambos temas (verificado para cada par que nombran los tokens); bordes de control, iconos y foco ≥ 3:1.
- Foco: anillo `trazo-foco` (2 px) `foco` con 2 px de separación; dentro de `monte`, `foco-sobre-monte`.
- Objetivos táctiles ≥ 44 px en web y ≥ 48 px en móvil (`size: "campo"`).
- Interruptores con `role="switch"`, medidor con `role="meter"` y texto de valor, alertas críticas con `role="alert"`, gráficos con `aria-label` que resume la lectura.

## Acceso

Las pantallas de acceso son las más ilustradas del producto: el paisaje animado ocupa media pantalla en web (izquierda, con el titular "El secado de tu café, a la vista." y burbujas de icono flotando) y la parte superior en móvil, con la hoja de `papel` subiendo encima. El formulario es `LoginForm`; en móvil va en `size: "campo"`. Flujo móvil: Bienvenida ("Tu secador, en el bolsillo.") → Ingresar ("¡Hola!") → Solicitar acceso (banda `monte`). Sin redes sociales: las cuentas las asigna CISNA.

## Widgets del teléfono

La app tiene widgets para la pantalla de inicio (`HomeWidget`: humedad, predicción, lote, equipo, alertas, curva; tamaños 2×2, 4×2 y 4×4) y accesorios para la pantalla de bloqueo (`LockWidget`). Reglas: cada widget responde UNA pregunta de un vistazo; siempre dicen cuándo se actualizaron; la predicción va en su widget `anil` propio; la resistencia jamás se enciende desde un widget (abre la app). Las alertas críticas son notificaciones, no widgets. El sistema operativo solo permite animar el cambio de datos: el movimiento continuo es para la app y las vistas previas (ver `components/HomeWidget/README.md`).

## Marca

SISCAN aún no tiene logotipo. Hasta que exista, el nombre se escribe en Fraunces 600 con `SOFT 100, WONK 1` (como en `SideNav`), acompañado de "Secado Inteligente de Café" en `cita`. No dibujes un símbolo provisional.
