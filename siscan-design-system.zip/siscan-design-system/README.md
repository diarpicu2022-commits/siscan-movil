SISCAN, Secado Inteligente de Café, es el ecosistema digital del secador híbrido solar–eléctrico de CISNA: portal web, app Android y app de reloj Wear OS, conectados al ESP32 del secador a través de la API de WordPress. Este sistema sale del logo y del panel aprobado: el verde bosque de la barra lateral, el ítem activo en verde salvia, curvas en verde esmeralda, barras en verde hoja, el grano en marrón tostado y lecturas grandes sobre superficies claras.

La idea que lo ordena: **la pantalla es una ventana al secador en el cafetal de Nariño**. La estructura es verde bosque, los datos van sobre papel claro y la ilustración del secador aparece donde da contexto (ingreso, lote activo, estados vacíos, foto del secador).

Principios, en orden de desempate:

1. **La lectura manda.** Cada tarjeta responde una pregunta y su cifra es lo más grande.
2. **El grano es el protagonista.** La humedad del grano y su llegada a 10 – 12 % es el dato central en las tres plataformas.
3. **Estado antes que detalle.** En operación, en pausa, alerta o sin conexión se ve de un vistazo, con color, ícono y palabra.
4. **Calma de campo.** Verdes del panel, crema y café; el rojo solo para alertas críticas.
5. **El equipo confirma.** Nada se da por hecho hasta que el ESP32 lo confirma («Encendiendo…» → «Encendido»).

## Logo

Usa siempre los archivos del grupo Logo; nunca redibujes el símbolo ni escribas «SISCAN» en una fuente como sustituto (la portada de este sistema es la única excepción).

- `siscan-logo.png`: logo completo a color sobre `fondo`, `superficie` o placas blancas translúcidas sobre la ilustración.
- `siscan-logo-claro.png`: logo completo en crema sobre `bosque` (barra lateral, encabezados Android, pantalla de carga).
- `siscan-simbolo.png` / `siscan-simbolo-claro.png`: el símbolo solo, para el ícono de la app, la barra colapsada, la tarjeta de ingreso, widgets, notificaciones y el reloj.
- `siscan-wordmark.png` / `siscan-wordmark-claro.png`: nombre y lema sin símbolo.
- El dibujo del **grano con hojas** (grupo Ilustración) va en la esquina inferior izquierda del menú lateral, al 20 % de opacidad, en su versión clara.
- Área de respeto: la altura de la «S» alrededor. Mínimo 120px de ancho para el logo completo y 24px para el símbolo. Sin sombras, sin recolorear.

## Voz y contenido

Todo lo que se lee está en español; el código en inglés.

- Claro, técnico sin ser frío, cercano al caficultor y al técnico de CISNA. Tuteo: «Escribe tu correo», «Revisa el ventilador».
- Magnitudes como en campo: «Humedad del grano», «Temperatura interior», «Temperatura tope», «Humedad relativa», «Potencia total», «Peso de la muestra».
- **Coma decimal** y espacio antes de la unidad: «42,6 °C», «12,4 %», «107,3 g», «$ 5.694 COP».
- Variaciones con flecha: «↓ −0,8 °C · última hora». Fechas cortas «2 oct · 07:40»; relativas en alertas «Hace 4 min».
- Lotes con nombre y variedad: «Lote B · Caturra». Secadores con sitio: «Secador CISNA · Chachagüí».
- Alertas: qué pasó, dónde y el dato. «Temperatura alta · tope 48,7 °C». Nunca «¡ERROR!».
- Errores que dicen cómo seguir: «No fue posible enviar la orden. Verifica la conexión.»

## Color

Dos temas: `claro` (por defecto) y `oscuro`. El reloj usa siempre el oscuro sobre negro OLED.

- Página `fondo`; tarjetas `superficie` con borde `linea` y `sombra-tarjeta`; tarjetas de lote y estados buenos en `superficie-hoja`; pistas y campos en `superficie-fuerte`.
- Texto `tinta` y `tinta-suave` (≥ 4,5:1 sobre las cuatro superficies en ambos temas).
- **Estructura**: `bosque` → `bosque-hondo` en la barra lateral y encabezados móviles; texto `sobre-bosque`, inactivos `sobre-bosque-suave`.
- **Activo**: el degradado `salvia-clara` → `salvia` con texto blanco y `sombra-activo` marca el ítem activo del menú y de la barra Android, como en el panel aprobado.
- **Acción**: botón principal en degradado `esmeralda` → `hoja`; interruptores encendidos en `hoja`.
- **Datos**: `esmeralda` para humedad relativa y curvas vivas; `brote-vivo` → `lima` para barras solares, anillos y puntos «En vivo»; `cafe` para el grano y los pesajes; `dato-temperatura`, `dato-exterior` (también la red eléctrica); `objetivo` para la banda 10 – 12 %; `prediccion` (violeta) solo para lo que estima la IA.
- **Estados**: `operando`, `pausa`, `alerta`, `fuera` con su `-suave`. Siempre con punto o ícono y palabra; sin conexión es gris.

## Tipografía

- **Outfit** (`display`): saludos, títulos, cifras protagonistas (humedad del grano en la cabecera, predicción, reloj).
- **Plus Jakarta Sans** (`ui`): todo lo demás, con cifras tabulares en las lecturas.
- Lectura de tarjeta `lectura` con unidad `lectura-unidad`; títulos de tarjeta `titulo-tarjeta` con su ícono en un cuadro `superficie-hoja`; metadatos `apoyo`; píldoras `etiqueta`.

## Formas y profundidad

- Base de 4px. Tarjetas `radius-lg` (20px), métricas 18px, campos 12–14px, píldoras y botones `radius-pill`, marco del portal y cabecera 24–28px.
- Sombras bajas en tarjetas; `sombra-flotante` para la tarjeta de ingreso, toasts y dispositivos.
- Vidrio esmerilado solo sobre la ilustración (tarjeta del lote en la cabecera, chips del ingreso, placa del logo).

## Iconografía

Trazo 1,75px en caja de 24px. La base es **Lucide** (licencia ISC), elegida porque se reconoce sin explicación; los propios son el **grano de café** (elipse inclinada con la hendidura en S), el **secador** (túnel con costillas) y la **resistencia**. El termómetro lleva el bulbo relleno para leerse a 16px. En tarjetas, el ícono va en un cuadro teñido del color de su magnitud. Sin emoji.

## Plataformas

- **Web**: barra lateral + contenido. Ver la sección Pantallas.
- **Android** (Flutter): barra inferior Material 3 (Inicio, Lotes, Pesaje, Equipo, Más), encabezado `bosque` en Inicio y Más, hojas inferiores, FAB, widgets, notificaciones con acciones y actividad en la pantalla de bloqueo.
- **Wear OS**: esfera con complicaciones, tarjeta, app con monitoreo, lecturas, equipo, predicción, alertas y registro de pesaje. Ver la sección Smartwatch.

## Movimiento

Siempre, mientras el estado exista: el ventilador encendido gira, la resistencia brilla, el aire fluye dentro del secador ilustrado, el led del ESP32 parpadea y el punto «En vivo» late. Por evento: una lectura nueva sube, la curva se dibuja, el anillo se llena, la alerta entra, el check se dibuja en el reloj. Nunca lo decorativo. Con movimiento reducido todo queda quieto y legible.

## Accesibilidad

- Foco con anillo de 3px en `esmeralda`. Objetivos táctiles de 44px (48px en el reloj).
- Estados nunca solo por color. Las gráficas traen resumen accesible.
- Encender un actuador desde el móvil exige mantener presionado, para evitar toques accidentales.
