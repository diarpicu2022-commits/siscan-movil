# Ilustración

- `grano-hojas-claro.png`: el dibujo a mano del grano de café con hojas, en crema, para la esquina inferior izquierda del menú lateral (20 % de opacidad sobre `bosque`).
- `grano-hojas.png`: la misma pieza en verde bosque, para fondos claros (documentos, estados vacíos impresos).
