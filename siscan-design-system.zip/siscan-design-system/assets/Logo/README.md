# Logo

Versiones del logo de SISCAN con fondo transparente, tomadas de los archivos de marca. No se redibujan ni se recolorean.

- `siscan-logo.png`: completo a color. Sobre fondos claros o placas blancas translúcidas.
- `siscan-logo-claro.png`: completo en crema. Sobre `bosque` y `bosque-hondo`.
- `siscan-simbolo.png` / `siscan-simbolo-claro.png`: solo el símbolo (ícono de app, widgets, notificaciones, reloj, menú colapsado).
- `siscan-wordmark.png` / `siscan-wordmark-claro.png`: nombre y lema sin símbolo.
