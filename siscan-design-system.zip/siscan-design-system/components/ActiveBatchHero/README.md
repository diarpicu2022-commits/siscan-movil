Cabecera del panel: el secador ilustrado de fondo y una tarjeta de vidrio con el lote, su estado, la humedad del grano en grande, lo que falta para el objetivo, el avance y los datos del lote.
