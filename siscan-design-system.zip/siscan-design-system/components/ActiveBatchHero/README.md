Héroe del lote activo: responde "¿Cómo está el secado?" con paisaje, etiqueta, humedad dominante y la secuencia temperatura → tiempo → restante → consumo.

Props: `batch: { code, variety, name, protocol, date, status, initial, moisture, target, temperature, elapsed, remaining, power }`, `status`, `verdict`, `simulate` (humedad que baja poco a poco y temperatura que varía, con tendencia), `animated` (paisaje vivo; por defecto `true`).

Movimiento: la humedad baja desde la inicial al entrar, las flechas entre lecturas corren, la etiqueta del lote se mece de vez en cuando.

Uno por pantalla, siempre primero en el panel principal. No lo conviertas en tres tarjetas KPI.
