Control táctil de un actuador (ventilador, resistencia, relé) con palanca física, modo y estados de transición.

Props: `name`, `icon`, `power` ("210 W"), `runtime`, `state` `"encendido" | "apagado" | "bloqueado" | "error"`, `mode` `"automatico" | "manual"`, `guarded` (resistencias: encender exige mantener presionado `holdMs` = 1500 ms), `warning`, `lockReason`, `errorText`, `size` `"campo"`, `onChange(state)`, `onModeChange(mode)`, `transitionMs`, `simulateFailure`.

- En automático la palanca está deshabilitada: "Controlado por el protocolo".
- Manual tiñe el control de `panela` y contornea la tarjeta: debe distinguirse a distancia.
- Muestra siempre la transición ("Encendiendo…") y el fallo con instrucción. Apagar nunca requiere confirmación.
