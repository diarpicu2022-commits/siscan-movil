Energía por actuador en 24 h, estimada con la potencia nominal y las horas de relé cerrado, con total y costo.
