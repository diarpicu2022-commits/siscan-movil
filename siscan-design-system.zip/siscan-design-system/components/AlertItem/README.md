Una alerta: cuadro con ícono en el color de su severidad (`alerta` crítica, `pausa` advertencia, `operando` resuelta, `info`), título, dato y hora. Es la fila de `AlertList` y de la pantalla Alertas.
