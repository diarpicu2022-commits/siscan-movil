Alerta del proceso con nivel, glifo, hora, lote, sensor y acción contextual.

Props: `level` `"informativa" | "advertencia" | "critica" | "resuelta"`, `title`, `description`, `time`, `batch`, `sensor`, `icon`, `action` + `onAction`, `secondaryAction`.

Crítica = fondo `oxido-suave`, contorno `oxido`, `role="alert"` y una acción concreta ("Apagar resistencia"). Explica qué pasó con cifras. Ordena: críticas sin resolver, recientes, resueltas al final.
