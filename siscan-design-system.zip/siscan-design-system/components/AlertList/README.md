Alertas con cuadro de ícono por severidad (crítica en `alerta`, advertencia en `pausa`, resuelta en `operando`, informativa en `info`). Sin alertas: «Sin alertas activas · Todo en orden.».
