Marco de teléfono para las pantallas Android: barra de estado (hora, wifi, batería), el cuerpo y, si se pide, `AndroidNav` abajo y un botón flotante (`fab`). `dark` para pantallas sobre `bosque`.
