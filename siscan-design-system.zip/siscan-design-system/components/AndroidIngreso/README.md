App Android, ingreso: pantalla de carga con el logo claro, ingreso con la escena arriba y una hoja inferior con el formulario (correo, contraseña, recordarme) y la opción de huella.
