App Android: Más (perfil, calibración, mapa, historial, ubicación, reloj, notificaciones, huella, cerrar sesión), Calibración y Mapa.
