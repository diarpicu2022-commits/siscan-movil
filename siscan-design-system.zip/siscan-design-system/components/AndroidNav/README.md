Barra de navegación de la app Android (Material 3): Inicio, Lotes, Pesaje, Equipo, Más; el destino activo lleva el indicador `salvia` con ícono blanco.
