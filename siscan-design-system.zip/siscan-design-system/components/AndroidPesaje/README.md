App Android: Pesaje (cifra grande con − y +, humedad resultante y rango de retiro, lista de pesajes), Equipo (modo, actuadores, botón de mantener presionado y sensores) y Alertas.
