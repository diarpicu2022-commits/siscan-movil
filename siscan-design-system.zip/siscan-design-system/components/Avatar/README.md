Iniciales del usuario en un círculo `brote` con texto `hoja`. Va en la barra superior junto al nombre y el rol, y en la pantalla «Más» de Android.
