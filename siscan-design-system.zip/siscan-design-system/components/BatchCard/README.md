Tarjeta del lote activo con una viñeta del secador, variedad, protocolo, ingreso y las fases compactas.
