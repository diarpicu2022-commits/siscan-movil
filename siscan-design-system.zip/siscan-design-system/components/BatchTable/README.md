Historial de lotes: nombre, sitio (Secador o Aire libre), variedad, ingreso, duración, humedad final y estado; el lote en curso resaltado.
