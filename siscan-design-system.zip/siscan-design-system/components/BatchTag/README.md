Etiqueta de costal: el registro físico de un lote de café.

Props: `code` ("LOTE B"), `variety` ("Café Supremo"), `protocol`, `date`, `status` `"programado" | "activo" | "secando" | "pausa" | "completado" | "detenido" | "alerta"`, `size` `"s"` (sin metadatos, para listas y móvil).

Úsala sobre la ilustración del héroe (ligeramente girada), en encabezados de detalle de lote y en filas de la lista de lotes. No la uses como tarjeta genérica.
