Botón de acción con "hoja" de icono, peso físico y un tono que dice la intención.

Props: `variant` `"primario" | "suave" | "secundario" | "silencioso" | "peligro"`, `tone` `"arcilla" | "cafeto" | "bruma" | "anil" | "panela" | "oxido" | "monte"` (por defecto `arcilla`; `peligro` = `oxido`), `size` `"sm" | "md" | "lg"` (lg = 56 px, móvil y campo), `icon` (nombre de `Icon`, va dentro de la hoja), `badge` (número sobre `pintura-sol`), `iconOnly` (el texto pasa a `aria-label`), `loading` + `loadingLabel`, y todo atributo de `<button>`.

- **Sólido** (`primario`): relleno del tono, borde inferior de 3 px en su tono profundo y halo del mismo color; se hunde al presionar como un pulsador. Uno por vista para la acción principal.
- El tono sigue la semántica del sistema: `arcilla` acción general, `cafeto` encender o confirmar, `bruma` sincronizar o ambiente, `anil` todo lo que abre la predicción, `panela` pasar a manual, `oxido` (`peligro`) detener equipos o borrar. Nunca un tono por decoración.
- **Suave**: fondo `*-suave` con la hoja sólida del tono, para acciones de apoyo y filtros. **Secundario**: papel con borde `linea-fuerte`. **Silencioso**: solo texto con subrayado ondulado (surco), para "Cancelar" o "Ver historial".
- La hoja del icono repite la forma asimétrica de los contenedores de icono (`12 12 12 4`) y se inclina al pasar el cursor.
- Deshabilitado = rayado `arena`, igual que un actuador bloqueado. Cargando conserva el tono y describe el proceso ("Guardando calibración…").
- Etiquetas en infinitivo: "Registrar pesaje", "Encender ventilador", "Iniciar lote".
