Tabla de calibración: referencia, medido, diferencia, ajuste y estado por sensor.

Props: `caption`, `rows: { sensor, icon, reference, measured, unit, adjustment?, tolerance? (0.5), decimals?, status?, statusLabel? }[]`.

La diferencia se colorea `cafeto` dentro de tolerancia y `panela` fuera, siempre con signo (+/−) y `StatusMark`. Columnas numéricas en mono alineadas a la derecha; encabezados en `etiqueta`.
