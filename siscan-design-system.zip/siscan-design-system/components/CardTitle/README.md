Encabezado de tarjeta: ícono en cuadro `superficie-hoja`, título en `titulo-tarjeta` y un enlace opcional a la derecha («Ver lote ›»). Toda tarjeta de datos empieza con uno.
