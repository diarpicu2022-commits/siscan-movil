Casilla con su texto. Marcada se rellena en `esmeralda` con el check blanco. Para opciones independientes («Recordarme», «Usar referencia Cenicafé»); para encender equipos usa `Switch`.
