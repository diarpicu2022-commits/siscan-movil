Casilla de verificación con forma de hoja: al marcarla se rellena de `cafeto`, se inclina y la marca se dibuja con un trazo.

Props: `label`, `checked`/`defaultChecked`, `onChange`, `name`. Usa un `<input type="checkbox">` real (accesible por teclado; foco con anillo `foco`). Para "Recordarme en este equipo", consentimientos y preferencias de alertas.
