Órdenes al equipo en línea de tiempo: hora, acción, quién la dio (persona, app, reloj o protocolo) y si el ESP32 la confirmó.
