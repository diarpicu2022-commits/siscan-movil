Condiciones durante el lote: mínimo, promedio y máximo por variable, con el ícono y el color de cada magnitud.
