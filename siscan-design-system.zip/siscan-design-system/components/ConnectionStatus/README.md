Píldora de conexión y sincronización con el secador.

Props: `status` `"conectado" | "sincronizando" | "offline" | "error"`, `detail` (línea secundaria: "Actualizado hace 3 s", "Los datos se sincronizarán cuando vuelva la conexión."), `onDark` (dentro de `monte`).

Va en la cabecera de página, en la base de `SideNav` y en la barra superior móvil. En `offline`, las lecturas deben pasar a "Última lectura".
