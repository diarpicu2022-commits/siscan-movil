Foto del secador con su sitio y coordenadas; mientras no haya foto se usa la ilustración.
