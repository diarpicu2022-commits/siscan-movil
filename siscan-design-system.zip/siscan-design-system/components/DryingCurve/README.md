Curva de humedad del lote: medida continua, predicción punteada con banda de incertidumbre, zona objetivo y "Ahora".

Props: `measured: [h, %][]`, `predicted: [h, %][]` (empieza en el último medido), `band: [h, bajo, alto][]`, `target`, `xMax`, `yMax`, `anomalies: [h, %][]`, `title` (o `false`), `xLabel`, `width`, `height`.

Responde "¿Cuánto falta?" y "¿Cómo se comportó este lote?". No añadas series sin pregunta detrás; para comparar lotes usa barras en `tierra` con el lote actual en `arcilla`.
