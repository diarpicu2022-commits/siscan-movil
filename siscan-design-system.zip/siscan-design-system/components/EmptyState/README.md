Estado vacío con la escena pequeña, una frase que dice qué hacer y la acción.
