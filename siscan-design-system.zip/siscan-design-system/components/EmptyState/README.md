Estado vacío con ilustración, frase y acción opcional.

Props: `title` ("No hay lotes registrados."), `text`, `action` + `onAction`, `actionIcon`, `scene`, `animated` (paisaje vivo; por defecto `true`).

Frases afirmativas y útiles: "No hay alertas pendientes." + "El secado avanza dentro del rango esperado."
