Consumo energético del día: kWh solares, kWh de red y costo en COP; barras por hora con solar abajo (degradado de las hojas del logo, como en el panel aprobado) y red arriba en azul.
