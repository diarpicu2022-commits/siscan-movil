Calibración del Gravimet: forma de calibrar (referencia Cenicafé 53 %, humedad inicial manual o puntos medidos), la lectura del medidor y los puntos con su diferencia.
