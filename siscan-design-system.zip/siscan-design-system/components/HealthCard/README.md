Responde «¿Está funcionando el equipo?» con una frase y tres comprobaciones: ESP32 conectado, sensores reportando y actuadores que responden.
