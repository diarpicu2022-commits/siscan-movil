Para encender un actuador a mano desde el móvil: hay que mantener presionado; la barra se llena y la orden se envía solo al completarla. Evita encendidos por un toque accidental.
