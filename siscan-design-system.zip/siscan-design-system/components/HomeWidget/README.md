Widgets de pantalla de inicio: 2×2 con la humedad del grano y 4×2 con anillo, temperatura, humedad relativa y tiempo estimado.
