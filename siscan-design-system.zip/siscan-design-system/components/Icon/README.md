Icono de línea propio de SISCAN, con un único punto de medición relleno.

`<Icon name="temperatura" size={24} title?="Temperatura" />` — `name` es uno de `Icon.names` (temperatura, humedad, aire, ventilador, resistencia, balanza, muestra, calibracion, lote, alerta, prediccion, sincronizar, sin-conexion, historial, mapa, energia, solar, candado, mano, correo, usuario, ojo, ojo-cerrado, finca, flecha, cerrar, check). Hereda `currentColor`; sin `title` es decorativo (`aria-hidden`).

- Usa 16 px en rótulos, 20 en navegación, 22–24 en tarjetas, 28 en móvil.
- No mezcles con otras librerías de iconos ni con emoji. Un icono nuevo sigue la gramática: 24 px, trazo 1.75 redondo, un punto relleno.
