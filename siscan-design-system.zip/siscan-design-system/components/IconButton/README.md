Botón circular de 44px con ícono y `label` accesible; `count` pone el contador rojo; `variant="dark"` sobre `bosque`.
