Ilustración gouache de SISCAN: cordillera, lomas con hileras de cafetal y el secador parabólico con panel solar.

Props: `scene` `"valle" | "vacio" | "loma"`, `wide` (banda 1280×280), `onDark` (para `loma` sobre `monte`), `preserve` (`preserveAspectRatio`), `title` (si es informativa), `animated` (nubes que derivan, vapor que sube del secador, halo del sol que respira, árboles que se mecen; se detiene con movimiento reducido), `sky` (`false` quita el cielo pintado para que el contenedor lo extienda con `pintura-cielo`, como en el acceso web).

Solo en héroe, estados vacíos, incorporación, base de navegación. Nunca dentro de sensores, tablas o formularios, ni detrás de cifras críticas. El contenedor define el tamaño (llena el 100 %).
