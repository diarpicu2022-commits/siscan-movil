Fila de lista de Android: ícono en cuadro `superficie-hoja`, título, una línea de apoyo y flecha. 56px de alto mínimo para el dedo. Se usa en «Más», en Lotes y en ajustes.
