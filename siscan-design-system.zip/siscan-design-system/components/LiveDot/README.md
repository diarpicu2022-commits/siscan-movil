Indicador «En vivo»: punto `operando` que late (Siempre) mientras llegan datos. `off` lo apaga y dice «Sin conexión» con el punto gris. `onLight` para fondos claros; por defecto va sobre `bosque`.
