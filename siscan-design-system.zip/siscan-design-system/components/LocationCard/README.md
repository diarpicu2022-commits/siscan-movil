Ubicación del secador: latitud, longitud, nombre del sitio, bloqueo contra la geolocalización por IP del ESP32, y acciones para usar la ubicación actual o guardar y refrescar el clima.
