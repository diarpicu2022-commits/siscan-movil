Accesorios de la pantalla de bloqueo: monocromos, translúcidos sobre el fondo del teléfono.

Props: `shape` `"circle" | "rect" | "inline"`, `moisture`, `initial`, `target`, `remaining`, `batch`, `style`.

- **Círculo:** gota que se llena según la humedad actual, con la cifra.
- **Rectángulo:** "SISCAN · Lote B", 14.5 % → 11 %, "Faltan 4 h 15 min" y barra de avance del secado.
- **En línea:** una frase sobre la hora ("Lote B · 14.5 % · faltan 4 h 15").
- El sistema los tiñe (blanco/tinte del usuario): no uses colores de estado aquí. Las alertas críticas llegan como notificación, no como accesorio.
