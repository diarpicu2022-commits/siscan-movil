Formulario de acceso completo de SISCAN: correo, contraseña, "Recordarme", recuperación y botón con todos sus estados.

Props: `size` `"campo"` (móvil), `defaultEmail`, `defaultPassword`, `onSuccess({ email })`, `onForgot`, `forgotHref`, `footer` (p. ej. "¿No tienes cuenta? Solicitar acceso"), `submitLabel` ("Ingresar"), `successLabel` ("¡Bienvenido!"), `delay` (ms de verificación simulada), `simulateError`, `resetAfter`, `baseDelay` (retraso de la entrada escalonada).

Estados: vacío o con correo mal escrito → los campos se sacuden y explican qué falta · datos válidos → ✓ en el correo · enviar → "Verificando…" con granos animados · éxito → el botón pasa a `cafeto` con ✓ "¡Bienvenido!" · fallo → aviso `oxido` "No pudimos verificar tus datos." con qué hacer. En la vista previa, la contraseña «error» simula el fallo.

Entrada: cada fila sube con `sc-enter` escalonado 70 ms. Sin inicio de sesión con redes sociales: las cuentas las asigna CISNA (backend WordPress).
