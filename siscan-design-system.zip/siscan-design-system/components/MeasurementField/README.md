Campo numérico de laboratorio con unidad fija y regla de medición, para gravimetría y calibración.

Props: `label` ("Muestra inicial (g)"), `unit` ("g"), `value`/`defaultValue`, `onChange`, `readOnly` (valores calculados como "Pérdida de peso"), `hint` ("Balanza B-02 · resolución 0.1 g"), `error`.

Cifras en mono, alineadas a la derecha. El error dice qué hacer: "El peso actual no puede superar la muestra inicial." Agrupa en una hoja de `papel` con fecha, hora y lote.
