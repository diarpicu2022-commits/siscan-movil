Medidor de humedad del café como lecho de secado: el agua por retirar se encoge hacia el objetivo.

Props: `initial` (52), `current` (14.5), `target` (11), `label`, `kind` (procedencia), `size` `"campo"` (lectura 76 px, sin leyenda, para móvil).

Fases automáticas: Húmedo → Secando → Cerca del objetivo → Objetivo alcanzado (el agua se vuelve `cafeto`). Expone `role="meter"` con texto de valor. Es la lectura dominante del héroe y del inicio móvil; no la sustituyas por un anillo.
