Escala lineal de humedad del grano: de húmedo (53 %, `cafe`) a pergamino y objetivo 10 – 12 %. Marca la lectura y nombra la zona.
