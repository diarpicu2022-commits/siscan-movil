Nuevo lote: nombre, dónde se seca, variedad, protocolo, muestra Gravimet, humedad inicial y objetivo, el peso de retiro calculado y las variables a registrar.
