Notificación del sistema con el símbolo de SISCAN, severidad, texto y acciones directas.
