Encabezado de página web: ruta corta en `etiqueta`, título en `titulo-pagina`, una línea de contexto y las acciones de la página a la derecha (máximo una primaria).
