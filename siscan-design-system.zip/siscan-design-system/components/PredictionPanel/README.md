Panel de la predicción de IA como asistente de investigación: tiempo restante, ventana, confianza y datos considerados.

Props: `remaining` ("4 h 15 min"), `low`, `high`, `eta`, `confidence` (0–100, dibujada como regla de confianza: pista hundida con zonas Baja < 60, Media 60–79 y Alta ≥ 80, relleno `anil` rayado y aguja; el nivel se repite en palabra junto al número), `variables: string[]`, `note` (explicación en una frase, o `false`), `size` `"campo"`.

Todo en `anil` y con `Provenance` "Predicción". Nada de robots, cerebros ni degradados morados; nada de "100 % garantizado".
