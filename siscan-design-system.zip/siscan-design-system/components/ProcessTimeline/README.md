Línea de etapas del secado, como terrazas: Inicio → Calentamiento → Secado activo → Reducción de humedad → Ajustes → Objetivo alcanzado → Finalización.

Props: `stages: { label, time?, flag?: { status, label } }[]`, `current` (índice), `vertical`.

La etapa en curso se escribe en Fraunces `arcilla`; las completadas llevan ✓ `cafeto`. Úsala en el detalle del lote (bitácora digital) y vertical en móvil.
