Comparación de protocolos entre el secador y el testigo a aire libre: horas hasta 40 %, horas hasta el objetivo, energía y costo.
