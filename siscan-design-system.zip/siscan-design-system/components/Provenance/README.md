Chip de procedencia: muestra, en miniatura, el mismo trazo que el dato tiene en los gráficos.

Props: `kind` `"medido" | "estimado" | "prediccion" | "objetivo" | "desactualizado" | "no-disponible"`, `label`, `source` (de dónde sale: "DHT22 · hace 3 s", "gravimetría", "modelo v2 · 87 %"), `variant` `"linea"` (sin fondo, para leyendas de gráficos).

- Medido: tinta `tierra`, línea continua con puntos de muestreo. Estimado: `bruma`, discontinua con una muestra cuadrada. Predicción: `anil`, tramo medido + punteado con banda de incertidumbre. Objetivo: `cafeto`, raya‑punto con bandera. Desactualizado: rayado `arena`, el trazo se corta. No disponible: contorno discontinuo, trazo tachado.
- Toda cifra visible lleva su `Provenance` cerca; una predicción nunca se presenta con el aspecto de una lectura medida.
- En leyendas usa `variant: "linea"`: el trazo toma el color `dato-*` exacto de la serie.
