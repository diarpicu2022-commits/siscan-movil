Lectura compacta para cuadrículas de 2 columnas en el móvil, con mini tendencia.
