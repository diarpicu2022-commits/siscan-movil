Anillo para una lectura protagonista. `gradient` usa el degradado de las hojas del logo (`brote-vivo` → `lima`); `band` marca la zona objetivo. Se llena al cargar.
