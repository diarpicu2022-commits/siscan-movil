Control segmentado para elegir entre opciones excluyentes: Automático / Manual, Secador / Aire libre, Un punto / Dos puntos. La opción activa es una pastilla blanca con texto `hoja`.
