Corrección de sensores por recta: crudo, corregido, ganancia y desplazamiento por variable, con su estado de tolerancia.
