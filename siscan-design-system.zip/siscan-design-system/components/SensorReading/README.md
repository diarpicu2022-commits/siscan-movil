Lectura de un sensor presentada como instrumento: escala, cifra grande, estado, procedencia y frescura.

Props: `name`, `icon`, `value` (número o `null`), `unit`, `decimals` (1), `status` `"normal" | "advertencia" | "error" | "desactualizado" | "sin-conexion"`, `live` (marcador en vivo), `range` ("38 – 42 °C"), `updated` ("Hace 3 s"), `kind` (procedencia; por defecto se deduce del estado), `compact`, `simulate` (lecturas en vivo simuladas: cada 4–7 s el valor cambia ±`jitter`, la cifra se ilumina, aparece la flecha de tendencia y "Ahora / Hace N s" cuenta solo), `jitter`.

Movimiento: entra contando hasta el valor, la regla superior hace un barrido de lectura de vez en cuando y la hoja se levanta al pasar el cursor.

- Desactualizado/sin conexión: la cifra pasa a `tierra-suave` sobre rayado y la procedencia cambia — nunca presentes datos viejos como actuales.
- Agrupa sensores en rejillas de 3–4 columnas en Monitoreo; en el panel principal muestra solo los que responden "¿Está funcionando el equipo?".
