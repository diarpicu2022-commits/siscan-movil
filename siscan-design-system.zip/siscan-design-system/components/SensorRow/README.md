Sensor con su lectura corregida y la frescura del dato («Hace 3 s», Desactualizado, Sin conexión).
