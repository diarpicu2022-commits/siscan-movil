Barra de navegación web en `monte`, con la pestaña activa fundida en la página y la loma pintada en la base.

Props: `items: { id, label, icon, href?, badge? }[]` (por defecto: Inicio, Monitoreo, Actuadores, Lotes, Gestión gravimétrica, Calibración, Historial, Alertas, Mapa), `active`, `onNavigate(id)`, `connection`, `device`.

Es navegación global; la local (pestañas del detalle de lote) y el contexto de datos (lote, rango de fechas) van en la página, nunca aquí.
