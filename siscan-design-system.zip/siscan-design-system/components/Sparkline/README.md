Línea de tendencia de 24 h dentro de `MetricCard`: curva suave en el color de la magnitud, área al 12 % y el último punto marcado (late si `live`). Sin ejes ni números: el número va en la tarjeta.
