Leyenda de estados con conteos que acompaña a `DryerMap`: punto del color de cada estado, nombre y cuántos secadores hay en él.
