Sello de estado: glifo dentro de un sello + palabra, para que el estado nunca dependa solo del color.

Props: `status` `"normal" | "advertencia" | "critico" | "error" | "sin-conexion" | "desactualizado" | "resuelta" | "info"`, `variant` `"suave" | "solido" | "linea"` (`quiet` = `linea`), `size` `"lg"`, `label` (sobrescribe la palabra: "Secando", "Atención requerida"), `detail` (dato corto tras un separador: "38–42 °C", "10:42", "hace 14 min"), `live` (anillo que respira alrededor del sello; solo para estados que se están midiendo ahora).

- **Suave** (por defecto): píldora `*-suave` con sello de papel; en sensores, tablas y alertas.
- **Sólido**: relleno del tono con borde inferior y halo, para cuando el estado ES el mensaje — el veredicto del lote, la etiqueta de una alerta crítica, "Objetivo alcanzado" en móvil.
- **Línea**: sin fondo, para frases dentro de texto ("Proceso dentro del rango esperado").
- Glifos: círculo ✓ normal/resuelta, triángulo advertencia, cuadrado "!" crítico/error, círculo tachado sin conexión, reloj desactualizado, punto informativa.
