Píldoras de estado: En operación (punto, `live` late), En pausa, Alerta, Sin conexión (gris, nunca rojo). `Chip` para etiquetas: `brote`, `cafe`, `neutral`, `pred`. `LiveDot` sobre `bosque` o claro.
