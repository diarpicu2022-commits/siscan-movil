Interruptor de actuadores y ajustes; encendido en `hoja` con un check en el botón. Deshabilitado cuando lo controla el protocolo o está bloqueado por seguridad. `Checkbox` para listas de opciones.
