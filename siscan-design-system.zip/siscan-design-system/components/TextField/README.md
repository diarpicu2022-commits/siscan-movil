Campo de texto con rótulo arriba y "hoja" de icono que se enciende en `anil` al enfocar; para acceso, registro y formularios de texto (las cifras usan `MeasurementField`).

Props: `label`, `icon` (nombre de `Icon`: correo, candado, usuario, finca…), `type` (`"password"` añade el botón Mostrar/Ocultar con `aria-pressed`), `value`/`defaultValue`, `onChange`, `placeholder`, `name`, `autoComplete`, `inputMode`, `hint`, `error` (borde y hoja `oxido`, sacudida breve y mensaje con `role="alert"`), `valid` (✓ `cafeto` que aparece con un salto), `aside` (enlace a la derecha del rótulo), `size` `"campo"` (58 px, móvil).

- El rótulo siempre visible arriba; el placeholder es solo un ejemplo ("nombre@correo.com"), nunca la etiqueta.
- Mensajes de error que dicen qué hacer: "Escribe tu correo.", "Revisa el correo: falta algo después de la @."
