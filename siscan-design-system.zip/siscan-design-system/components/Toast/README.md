Mensaje breve de confirmación o error tras una acción.

Props: `tone` `"success" | "info" | "warning" | "error"`, `title`, `description`, `label`, `onClose` (`false` lo oculta).

Una frase con punto final: "Pesaje registrado correctamente." + consecuencia: "Los valores fueron recalculados." Errores con instrucción. Abajo a la derecha en web, arriba en móvil.
