Confirmación breve sobre `bosque`. Se muestra cuando el servidor o el ESP32 confirman: «Pesaje registrado: 107,3 g · 12,4 %». `action` ofrece Deshacer o Reintentar.
