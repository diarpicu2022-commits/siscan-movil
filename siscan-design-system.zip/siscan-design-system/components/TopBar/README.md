Barra superior: saludo, subtítulo, clima, campana con contador y usuario.
