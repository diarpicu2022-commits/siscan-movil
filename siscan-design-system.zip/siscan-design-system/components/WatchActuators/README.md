Equipo en el reloj: un chip por actuador que enciende y apaga al tocarlo; el ventilador gira y la resistencia brilla mientras están encendidos. Muestra el modo (Automático o Manual).
