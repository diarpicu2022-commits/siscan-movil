Alerta a pantalla completa en el reloj: fondo tintado (rojo crítica, ámbar advertencia), ícono, dato y dos botones: descartar y ver.
