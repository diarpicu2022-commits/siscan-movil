Modo siempre activo: solo contornos, sin color de estado ni animación, para ahorrar batería.
