Arco de avance del reloj: tres cuartos de círculo con el hueco arriba para no tapar la hora; se llena desde cero (por evento). `tone` da el color (lima por defecto para el avance del lote).
