Lista de lotes en el reloj con su estado y humedad final; el activo resaltado.
