Confirmación en el reloj: el círculo y el check se dibujan con vibración corta; se cierra sola a los 2 s.
