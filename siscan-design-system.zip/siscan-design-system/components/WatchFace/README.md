Esfera de reloj con complicaciones de SISCAN: humedad del grano en anillo, temperatura interior y número de alertas.
