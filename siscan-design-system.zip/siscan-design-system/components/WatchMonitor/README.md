Pantalla principal de la app del reloj: arco de avance, humedad del grano en grande, objetivo y estado del lote.
