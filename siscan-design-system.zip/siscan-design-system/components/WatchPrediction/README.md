Predicción de IA en el reloj: «Listo en 5 h 40», rango y confianza en `prediccion`.
