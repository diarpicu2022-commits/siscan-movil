Lecturas en el reloj: hasta cuatro datos con el color de su magnitud (interior, tope, humedad relativa, exterior).
