Tarjeta (Tile) de Wear OS: lote, anillo de avance, temperatura, tiempo restante y «Abrir».
