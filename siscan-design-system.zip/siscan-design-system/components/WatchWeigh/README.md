Registrar pesaje desde el reloj: − y + de 0,1 g (o la corona), la humedad resultante y el rango de retiro; «Guardar».
