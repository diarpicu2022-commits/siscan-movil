Clima en la finca ahora (Open-Meteo): temperatura, cielo, humedad, radiación y probabilidad de lluvia. `WeatherChip` es la versión compacta de la barra superior.
