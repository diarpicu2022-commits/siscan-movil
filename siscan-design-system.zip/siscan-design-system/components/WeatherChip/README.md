Clima del sitio del secador en la barra superior: ícono, municipio y «18 °C · Parcialmente nublado». Es contexto, no un dato del secado: va en tinta suave, sin color de magnitud.
