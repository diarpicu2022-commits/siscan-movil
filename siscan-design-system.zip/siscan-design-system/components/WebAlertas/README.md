Alertas activas y resueltas, con la verificación del equipo y el mapa (el pin en alerta emite su onda).
