Calibración: Gravimet, ubicación del secador y corrección de sensores.
