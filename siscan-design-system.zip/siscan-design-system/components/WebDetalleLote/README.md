Detalle de lote: cabecera con el proceso en seis fases, curva completa con predicción, la predicción de IA, condiciones durante el lote y los pesajes.
