Gestión gravimétrica: rango de retiro, veredicto, registro y corrección de pesajes, curva por conservación de materia seca y escala.
