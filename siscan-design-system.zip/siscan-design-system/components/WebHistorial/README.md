Historial del equipo: órdenes, consumo de 24 h y energía por actuador.
