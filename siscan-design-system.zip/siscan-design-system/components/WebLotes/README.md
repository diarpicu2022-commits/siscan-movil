Lotes: historial con filtro por sitio y variedad, el lote en curso resaltado, la comparación de protocolos secador vs. aire libre y un estado vacío.
