Mapa de secadores con foto y clima del secador seleccionado.
