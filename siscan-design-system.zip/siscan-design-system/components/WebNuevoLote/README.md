Nuevo lote con el formulario completo, la escala de humedad y la verificación del equipo antes de iniciar.
