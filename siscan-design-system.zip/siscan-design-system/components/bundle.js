/* @ds-bundle: {"format":4,"namespace":"Siscan","components":[{"name":"Icon"},{"name":"Button"},{"name":"TextField"},{"name":"Checkbox"},{"name":"StatusMark"},{"name":"Provenance"},{"name":"ConnectionStatus"},{"name":"BatchTag"},{"name":"SensorReading"},{"name":"MoistureMeter"},{"name":"ActuatorControl"},{"name":"MeasurementField"},{"name":"CalibrationTable"},{"name":"ProcessTimeline"},{"name":"DryingCurve"},{"name":"PredictionPanel"},{"name":"AlertItem"},{"name":"Toast"},{"name":"Landscape"},{"name":"EmptyState"},{"name":"SideNav"},{"name":"ActiveBatchHero"},{"name":"LoginForm"},{"name":"HomeWidget"},{"name":"LockWidget"}]} */
(function () {
  "use strict";
  var React = window.React;
  var h = React.createElement;
  var useState = React.useState, useRef = React.useRef, useEffect = React.useEffect;

  function cx() {
    var out = [];
    for (var i = 0; i < arguments.length; i++) if (arguments[i]) out.push(arguments[i]);
    return out.join(" ");
  }
  function fmt(n, d) {
    if (n === null || n === undefined || isNaN(n)) return "—";
    return Number(n).toFixed(d === undefined ? 1 : d);
  }
  function Duration(props) {
    var parts = String(props.value || "").split(/\s+/).filter(Boolean);
    return h("span", { className: cx("sc-dur", props.className) }, parts.map(function (p, i) {
      return /^[0-9.,:]+$/.test(p) ? h("span", { key: i, className: "sc-num" }, p) : h("span", { key: i, className: "sc-unit" }, p);
    }));
  }
  var REDUCE = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  function useTween(to, from, ms) {
    var st = useState(REDUCE || from === undefined || to === null || to === undefined ? to : from), v = st[0], setV = st[1];
    var cur = useRef(v);
    useEffect(function () {
      if (REDUCE || to === null || to === undefined || isNaN(to)) { cur.current = to; setV(to); return; }
      var a = cur.current === null || cur.current === undefined || isNaN(cur.current) ? to : cur.current, t0 = performance.now(), raf;
      var step = function (now) {
        var p = Math.min(1, (now - t0) / (ms || 900)), e = 1 - Math.pow(1 - p, 3), x = a + (to - a) * e;
        cur.current = x; setV(x); if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
      return function () { cancelAnimationFrame(raf); };
    }, [to]);
    return v;
  }
  // Simula lecturas en vivo: cada 4–7 s mueve el valor ±jitter y reinicia la edad.
  function useLive(base, opts) {
    var on = !!opts.on;
    var vs = useState(base), val = vs[0], setVal = vs[1];
    var as = useState(opts.age || 3), age = as[0], setAge = as[1];
    var ts = useState({ k: 0, dir: 0 }), tick = ts[0], setTick = ts[1];
    useEffect(function () { setVal(base); }, [base]);
    useEffect(function () {
      if (!on || base === null || base === undefined) return;
      var alive = true, to;
      var iv = setInterval(function () { setAge(function (a) { return a + 1; }); }, 1000);
      var loop = function () {
        to = setTimeout(function () {
          if (!alive) return;
          var d = (Math.random() - (opts.drift || .5)) * 2 * (opts.jitter || .3);
          setVal(function (v) { return Math.round((v + d) * 100) / 100; });
          setAge(0); setTick(function (t) { return { k: t.k + 1, dir: d > 0 ? 1 : -1 }; });
          loop();
        }, (opts.every || 4000) + Math.random() * 3000);
      };
      loop();
      return function () { alive = false; clearInterval(iv); clearTimeout(to); };
    }, [on, base]);
    return { value: val, age: age, tick: tick };
  }
  function ageLabel(a) { return a < 2 ? "Ahora" : a < 60 ? "Hace " + a + " s" : "Hace " + Math.floor(a / 60) + " min"; }
  function Trend(props) {
    if (!props.tick || !props.tick.k) return null;
    return h("span", { key: props.tick.k, className: cx("sc-trend", props.tick.dir > 0 ? "is-up" : "is-down"), "aria-hidden": "true" },
      h("svg", { width: 10, height: 10, viewBox: "0 0 10 10" }, h("path", { d: props.tick.dir > 0 ? "M5 1.5 9 7.5H1z" : "M5 8.5 9 2.5H1z" })));
  }
  var uid = 0;
  function useId(prefix) {
    var r = useRef(null);
    if (r.current === null) { uid += 1; r.current = (prefix || "sc") + "-" + uid; }
    return r.current;
  }

  /* ------------------------------------------------------------------ Icon */
  // Grammar: 24px grid, round 1.75 stroke, ONE filled "punto de medición".
  var ICONS = {
    temperatura: { d: ["M10 4.5a2 2 0 0 1 4 0v8.8a4.2 4.2 0 1 1-4 0z", "M16.8 6.5h2.4M16.8 9.5h1.6M16.8 12.5h2.4"], dot: [12, 16.6, 2] },
    humedad: { d: ["M12 3.2c3.1 3.8 5.8 7.1 5.8 10.4a5.8 5.8 0 0 1-11.6 0c0-3.3 2.7-6.6 5.8-10.4z"], dot: [9.9, 14.8, 1.6] },
    aire: { d: ["M3 9h10.5a2.6 2.6 0 1 0-2.6-2.6", "M3 13h14.5a2.6 2.6 0 1 1-2.6 2.6", "M3 17h6"], dot: [20, 9, 1.4] },
    ventilador: { d: ["M12 12c-.4-4.2.9-7.4 3.4-7.4 2.6 0 3 3.6-3.4 7.4z", "M12 12c3.8 1.8 5.6 4.6 4.3 6.8-1.3 2.2-4.6.8-4.3-6.8z", "M12 12c-3.4 2.4-6.8 2.4-7.6-.1-.8-2.4 2.4-3.9 7.6.1z"], circle: [12, 12, 9.25], dot: [12, 12, 1.6] },
    resistencia: { d: ["M2.8 13h3l1.6-4.2 3 8.4 3-8.4 3 8.4 1.6-4.2h3.2", "M9 4.5c.8.8.8 1.7 0 2.5M13 4.5c.8.8.8 1.7 0 2.5"], dot: [17, 5.7, 1.4] },
    balanza: { d: ["M5 20.5h14M12 20.5V6.5M5.5 8h13", "M5.5 8 3.2 14h4.6zM18.5 8l-2.3 6h4.6z", "M3.2 14a2.3 2.3 0 0 0 4.6 0M16.2 14a2.3 2.3 0 0 0 4.6 0"], dot: [12, 4.6, 1.6] },
    muestra: { d: ["M12 3.2c3.6 0 6.2 4 6.2 8.8s-2.6 8.8-6.2 8.8S5.8 16.8 5.8 12 8.4 3.2 12 3.2z", "M12.6 3.4c-2.4 2.6-2.4 5.8-.6 8.6s1.8 6-.6 8.6"], dot: [19.6, 4.6, 1.3] },
    calibracion: { d: ["M4.2 16.8 16.8 4.2l3 3L7.2 19.8z", "M8.2 12.8l1.6 1.6M10.8 10.2l1.2 1.2M13.2 7.8l1.6 1.6"], dot: [19.4, 19.4, 1.6] },
    lote: { d: ["M3.5 12.3V4.5a1 1 0 0 1 1-1h7.8l8.2 8.2a1.1 1.1 0 0 1 0 1.5l-7.3 7.3a1.1 1.1 0 0 1-1.5 0z", "M13 13.5l2.5-2.5M10.6 11.1l2.5-2.5"], dot: [7.8, 7.8, 1.7] },
    alerta: { d: ["M12 3.8 21.2 19.6H2.8z", "M12 9.8v4.6"], dot: [12, 17, 1.25] },
    prediccion: { d: ["M11 8.2c2.5 0 4.3 2.5 4.3 5.7s-1.8 5.7-4.3 5.7-4.3-2.5-4.3-5.7S8.5 8.2 11 8.2z", "M11.5 8.4c-1.5 1.7-1.5 3.7-.4 5.5s1.1 3.8-.4 5.5", "M20.2 6.2l-.6 3.4-3.3-.9"], dash: "M3.3 10.2A8.6 8.6 0 0 1 19.4 9.4", dot: [3.3, 10.6, 1.6], grow: 1.12 },
    sincronizar: { d: ["M19.4 9.2A7.8 7.8 0 0 0 5.2 7.6", "M4.6 14.8a7.8 7.8 0 0 0 14.2 1.6", "M5 3.6v4.2h4.2M19 20.4v-4.2h-4.2"], dot: [12, 12, 1.6] },
    "sin-conexion": { d: ["M5 9.6a10 10 0 0 1 14 0", "M8.2 13a5.4 5.4 0 0 1 7.6 0", "M3.6 3.6l16.8 16.8"], dot: [12, 17.4, 1.5] },
    historial: { d: ["M3.6 12a8.4 8.4 0 1 0 2.4-5.9", "M3.6 3.8v3.8h3.8", "M12 7.6V12l3 2"], dot: [12, 12, 1.4] },
    mapa: { d: ["M2.8 20.6c3-3.8 6-4.6 9.2-2.8s6 1 9.2-2.8", "M12 3a4.2 4.2 0 0 1 4.2 4.2c0 3.2-4.2 7.4-4.2 7.4S7.8 10.4 7.8 7.2A4.2 4.2 0 0 1 12 3z"], dot: [12, 7.2, 1.6] },
    energia: { d: ["M13.2 2.8 5.6 13.4H12l-1.2 7.8 7.6-10.6H12z"], dot: [19.4, 4.4, 1.3] },
    solar: { d: ["M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"], circle: [12, 12, 4.2], dot: [12, 12, 1.6] },
    candado: { d: ["M6.2 10.8h11.6v9.4H6.2z", "M8.6 10.8V8a3.4 3.4 0 0 1 6.8 0v2.8"], dot: [12, 15.4, 1.5] },
    mano: { d: ["M8 13V5.6a1.4 1.4 0 0 1 2.8 0V11", "M10.8 10.6V4.4a1.4 1.4 0 0 1 2.8 0v6.2", "M13.6 10.6V5.6a1.4 1.4 0 0 1 2.8 0v6.8", "M16.4 9.4a1.4 1.4 0 0 1 2.8 0v4.2a7 7 0 0 1-7 7h-.6a6 6 0 0 1-5-2.7L4 14.4a1.5 1.5 0 0 1 2.4-1.8L8 14.4"], dot: [12.2, 17, 1.2] },
    correo: { d: ["M3.4 6.4h17.2v11.2H3.4z", "M3.8 6.9l8.2 6.2 8.2-6.2"], dot: [19.8, 3.9, 1.3] },
    usuario: { d: ["M12 3.8a3.7 3.7 0 1 1 0 7.4 3.7 3.7 0 0 1 0-7.4z", "M4.6 20.2c.7-3.9 3.5-6.1 7.4-6.1s6.7 2.2 7.4 6.1"], dot: [12, 7.5, 1.2] },
    ojo: { d: ["M2.8 12c2.4-4.2 5.6-6.3 9.2-6.3s6.8 2.1 9.2 6.3c-2.4 4.2-5.6 6.3-9.2 6.3S5.2 16.2 2.8 12z", "M12 8.9a3.1 3.1 0 1 1 0 6.2 3.1 3.1 0 0 1 0-6.2z"], dot: [12, 12, 1.3] },
    "ojo-cerrado": { d: ["M2.8 12c2.4-4.2 5.6-6.3 9.2-6.3s6.8 2.1 9.2 6.3c-2.4 4.2-5.6 6.3-9.2 6.3S5.2 16.2 2.8 12z", "M12 8.9a3.1 3.1 0 1 1 0 6.2 3.1 3.1 0 0 1 0-6.2z", "M4 4l16 16"], dot: [12, 12, 1.3] },
    finca: { d: ["M3.6 11.4 12 4.6l8.4 6.8", "M5.8 9.8v10h12.4v-10", "M10 19.8v-4.6h4v4.6"], dot: [12, 10.6, 1.3] },
    flecha: { d: ["M4 12h15.2", "M13.6 6.4 19.2 12l-5.6 5.6"], dot: [4.2, 12, 1.4] },
    cerrar: { d: ["M6 6l12 12M18 6 6 18"] },
    check: { d: ["M4.5 12.5l4.6 4.6L19.5 6.7"] }
  };
  function Icon(props) {
    var def = ICONS[props.name] || ICONS.alerta;
    var size = props.size || 24;
    var kids = [];
    if (def.circle) kids.push(h("circle", { key: "c", cx: def.circle[0], cy: def.circle[1], r: def.circle[2] }));
    def.d.forEach(function (d, i) { kids.push(h("path", { key: "p" + i, d: d })); });
    if (def.dash) kids.push(h("path", { key: "dash", d: def.dash, strokeDasharray: "0.01 3" }));
    if (def.dot) kids.push(h("circle", { key: "dot", cx: def.dot[0], cy: def.dot[1], r: def.dot[2], fill: "currentColor", stroke: "none" }));
    if (def.grow) kids = [h("g", { key: "g", transform: "translate(12 13) scale(" + def.grow + ") translate(-12 -13)", strokeWidth: (props.strokeWidth || 1.75) / def.grow }, kids)];
    return h("svg", {
      className: cx("sc-icon", props.className), width: size, height: size, viewBox: "0 0 24 24",
      fill: "none", stroke: "currentColor", strokeWidth: props.strokeWidth || 1.75, strokeLinecap: "round", strokeLinejoin: "round",
      role: props.title ? "img" : undefined, "aria-hidden": props.title ? undefined : "true", "aria-label": props.title, focusable: "false"
    }, kids);
  }
  Icon.names = Object.keys(ICONS);

  /* ---------------------------------------------------------------- Button */
  function Spinner() {
    return h("span", { className: "sc-spin", "aria-hidden": "true" }, h("span", null), h("span", null), h("span", null));
  }
  var BTN_TONE = { primario: "arcilla", peligro: "oxido" };
  function Button(props) {
    var variant = props.variant || "primario";
    var size = props.size || "md";
    var tone = props.tone || BTN_TONE[variant] || "arcilla";
    var kind = variant === "peligro" ? "solido" : variant === "primario" ? "solido" : variant;
    var rest = {};
    for (var k in props) if (["variant", "size", "icon", "loading", "children", "className", "loadingLabel", "tone", "badge", "iconOnly"].indexOf(k) < 0) rest[k] = props[k];
    var iconSize = size === "lg" ? 22 : size === "sm" ? 16 : 18;
    var hasTile = props.loading || props.icon;
    return h("button", Object.assign({ type: "button" }, rest, {
      className: cx("sc-btn", "sc-btn--" + kind, "sc-btn--" + size, "sc-btone-" + tone, hasTile && "has-tile", props.iconOnly && "is-icon-only", props.loading && "is-loading", props.className),
      disabled: props.disabled || props.loading, "aria-busy": props.loading ? "true" : undefined,
      "aria-label": props.iconOnly ? (props["aria-label"] || props.children) : props["aria-label"]
    }),
      hasTile ? h("span", { className: "sc-btn-tile", "aria-hidden": "true" }, props.loading ? h(Spinner) : h(Icon, { name: props.icon, size: iconSize })) : null,
      props.iconOnly ? null : h("span", { className: "sc-btn-label" }, props.loading ? (props.loadingLabel || props.children) : props.children),
      props.badge !== undefined && !props.iconOnly ? h("span", { className: "sc-btn-badge" }, props.badge) : null);
  }

  /* ------------------------------------------------------------ StatusMark */
  var STATUS = {
    normal: { label: "Normal", tone: "cafeto", glyph: "ok" },
    advertencia: { label: "Advertencia", tone: "panela", glyph: "tri" },
    critico: { label: "Crítico", tone: "oxido", glyph: "sq" },
    error: { label: "Error", tone: "oxido", glyph: "sq" },
    "sin-conexion": { label: "Sin conexión", tone: "neutro", glyph: "slash" },
    desactualizado: { label: "Desactualizado", tone: "neutro", glyph: "clock" },
    resuelta: { label: "Resuelta", tone: "neutro", glyph: "ok" },
    info: { label: "Informativa", tone: "bruma", glyph: "dot" }
  };
  function Glyph(props) {
    var g = props.glyph, s = props.size || 14, M = "var(--glyph-mark, var(--papel))";
    var inner;
    if (g === "ok") inner = [h("circle", { key: 1, cx: 7, cy: 7, r: 6.2, fill: "currentColor" }), h("path", { key: 2, d: "M4.2 7.2l1.9 1.9 3.8-4", stroke: M, strokeWidth: 1.6, fill: "none", strokeLinecap: "round", strokeLinejoin: "round" })];
    else if (g === "tri") inner = [h("path", { key: 1, d: "M7 .9 13.3 12.6H.7z", fill: "currentColor", stroke: "currentColor", strokeWidth: 1, strokeLinejoin: "round" }), h("path", { key: 2, d: "M7 5v3.4", stroke: M, strokeWidth: 1.6, strokeLinecap: "round" }), h("circle", { key: 3, cx: 7, cy: 10.4, r: .9, fill: M })];
    else if (g === "sq") inner = [h("rect", { key: 1, x: .8, y: .8, width: 12.4, height: 12.4, rx: 2.5, fill: "currentColor" }), h("path", { key: 2, d: "M7 3.6v4.2", stroke: M, strokeWidth: 1.7, strokeLinecap: "round" }), h("circle", { key: 3, cx: 7, cy: 10.2, r: 1, fill: M })];
    else if (g === "slash") inner = [h("circle", { key: 1, cx: 7, cy: 7, r: 6.2, fill: "currentColor" }), h("path", { key: 2, d: "M4 10 10 4", stroke: M, strokeWidth: 1.7, strokeLinecap: "round" })];
    else if (g === "clock") inner = [h("circle", { key: 1, cx: 7, cy: 7, r: 6.2, fill: "currentColor" }), h("path", { key: 2, d: "M7 3.8v3.4l2.1 1.3", stroke: M, strokeWidth: 1.6, fill: "none", strokeLinecap: "round" })];
    else inner = [h("circle", { key: 1, cx: 7, cy: 7, r: 6.2, fill: "currentColor" }), h("circle", { key: 2, cx: 7, cy: 7, r: 2.2, fill: M })];
    return h("svg", { className: "sc-glyph", width: s, height: s, viewBox: "0 0 14 14", "aria-hidden": "true" }, inner);
  }
  function StatusMark(props) {
    var st = STATUS[props.status] || STATUS.normal;
    var variant = props.variant || (props.quiet ? "linea" : "suave");
    return h("span", { className: cx("sc-status", "sc-status--" + variant, "sc-tone-" + st.tone, props.size === "lg" && "sc-status--lg", props.className) },
      h("span", { className: "sc-status-seal" }, h(Glyph, { glyph: st.glyph, size: props.size === "lg" ? 18 : 14 }),
        props.live ? h("span", { className: "sc-status-ring", "aria-hidden": "true" }) : null),
      h("span", { className: "sc-status-label" }, props.label || st.label),
      props.detail ? h("span", { className: "sc-status-detail" }, props.detail) : null);
  }

  /* ------------------------------------------------------------ Provenance */
  var PROV = {
    medido: "Medido", estimado: "Estimado", prediccion: "Predicción", objetivo: "Objetivo", desactualizado: "Desactualizado", "no-disponible": "No disponible"
  };
  function ProvTrace(props) {
    var k = props.kind;
    var kids;
    if (k === "medido") kids = [
      h("path", { key: 1, d: "M2 11 9 7 16 9 24 3", className: "pv-line" }),
      [[2, 11], [9, 7], [16, 9], [24, 3]].map(function (p, i) { return h("circle", { key: "d" + i, cx: p[0], cy: p[1], r: 1.9, className: "pv-dot" }); })];
    else if (k === "estimado") kids = [h("path", { key: 1, d: "M2 11 9 7 16 9 24 3", className: "pv-line pv-dash" }), h("rect", { key: 2, x: 14, y: 7, width: 4, height: 4, rx: .8, className: "pv-dot" })];
    else if (k === "prediccion") kids = [
      h("path", { key: 0, d: "M11 7.5 24 1.5V7L11 10Z", className: "pv-band" }),
      h("path", { key: 1, d: "M2 12 11 9", className: "pv-line" }),
      h("path", { key: 2, d: "M11 9 24 4.5", className: "pv-line pv-dots" }),
      h("circle", { key: 3, cx: 11, cy: 9, r: 2, className: "pv-dot" })];
    else if (k === "objetivo") kids = [h("path", { key: 1, d: "M2 7h22", className: "pv-line pv-dashdot" }), h("path", { key: 2, d: "M19 2v10", className: "pv-line pv-thin" }), h("path", { key: 3, d: "M19 2.4h4.5l-1.4 1.8 1.4 1.8H19", className: "pv-flag" })];
    else if (k === "desactualizado") kids = [h("path", { key: 1, d: "M2 9 9 6 14 8", className: "pv-line" }), h("path", { key: 2, d: "M14 8h10", className: "pv-line pv-dots" }), h("circle", { key: 3, cx: 14, cy: 8, r: 1.9, className: "pv-dot" })];
    else kids = [h("path", { key: 1, d: "M2 7h22", className: "pv-line pv-dots" }), h("path", { key: 2, d: "M9 2.5l8 9M17 2.5l-8 9", className: "pv-line pv-thin" })];
    return h("svg", { className: "sc-prov-trace", width: 30, height: 16, viewBox: "0 0 26 14", "aria-hidden": "true" }, kids);
  }
  function Provenance(props) {
    var kind = props.kind || "medido";
    return h("span", { className: cx("sc-prov", "sc-prov--" + kind, props.variant === "linea" && "sc-prov--linea", props.className), title: props.title },
      h("span", { className: "sc-prov-tile" }, h(ProvTrace, { kind: kind })),
      h("span", { className: "sc-prov-label" }, props.label || PROV[kind]),
      props.source ? h("span", { className: "sc-prov-src" }, props.source) : null);
  }

  /* ------------------------------------------------------ ConnectionStatus */
  var CONN = {
    conectado: { label: "Conectado", icon: "sincronizar", tone: "cafeto" },
    sincronizando: { label: "Sincronizando…", icon: "sincronizar", tone: "bruma" },
    offline: { label: "Modo offline", icon: "sin-conexion", tone: "panela" },
    error: { label: "Error de sincronización", icon: "sin-conexion", tone: "oxido" }
  };
  function ConnectionStatus(props) {
    var s = props.status || "conectado", c = CONN[s];
    return h("div", { className: cx("sc-conn", "sc-tone-" + c.tone, "sc-conn--" + s, props.onDark && "on-dark", props.className), role: "status" },
      h("span", { className: "sc-conn-pill" },
        s === "conectado" ? h("span", { className: "sc-live", "aria-hidden": "true" }) : h(Icon, { name: c.icon, size: 16, className: s === "sincronizando" ? "sc-rotate" : "" }),
        h("span", null, c.label)),
      props.detail ? h("span", { className: "sc-conn-detail" }, props.detail) : null);
  }

  /* ------------------------------------------------------------- BatchTag */
  var BATCH_STATUS = {
    programado: "Programado", activo: "Activo", secando: "Secando", pausa: "En pausa", completado: "Completado", detenido: "Detenido", alerta: "Con alerta"
  };
  function BatchTag(props) {
    var s = props.status || "secando";
    return h("div", { className: cx("sc-tag", "sc-tag--" + s, props.size === "s" && "sc-tag--s", props.className) },
      h("span", { className: "sc-tag-hole", "aria-hidden": "true" }),
      h("div", { className: "sc-tag-body" },
        h("div", { className: "sc-tag-code" }, props.code || "LOTE B"),
        h("div", { className: "sc-tag-variety" }, props.variety || "Café Supremo"),
        props.size === "s" ? null : h("dl", { className: "sc-tag-meta" },
          props.protocol ? [h("dt", { key: "a" }, "Protocolo"), h("dd", { key: "b" }, props.protocol)] : null,
          props.date ? [h("dt", { key: "c" }, "Ingreso"), h("dd", { key: "d" }, props.date)] : null),
        h("span", { className: "sc-tag-status" }, BATCH_STATUS[s] || s)));
  }

  /* -------------------------------------------------------- SensorReading */
  function SensorReading(props) {
    var status = props.status || "normal";
    var stale = status === "desactualizado" || status === "sin-conexion";
    var kind = props.kind || (status === "sin-conexion" ? "no-disponible" : stale ? "desactualizado" : "medido");
    var live = useLive(props.value, { on: props.simulate && !stale, jitter: props.jitter || Math.pow(10, -(props.decimals === undefined ? 1 : props.decimals)) * 3 });
    var shown = useTween(live.value, live.value === null || live.value === undefined ? live.value : live.value * 0.86, 1100);
    return h("article", { className: cx("sc-sensor", "is-" + status, props.compact && "sc-sensor--compact", props.className), "aria-label": props.name },
      h("div", { className: "sc-sensor-scale", "aria-hidden": "true" }),
      h("header", { className: "sc-sensor-head" },
        h("span", { className: "sc-sensor-icon" }, h(Icon, { name: props.icon || "temperatura", size: 22 })),
        h("span", { className: "sc-sensor-name" }, props.name || "Temperatura interior"),
        props.live && !stale ? h("span", { className: "sc-live", title: "En vivo" }) : null),
      h("div", { className: "sc-sensor-value" },
        h("span", { className: cx("sc-num", live.tick.k && "is-fresh"), key: "v" + live.tick.k }, status === "sin-conexion" ? "—" : fmt(shown, props.decimals)),
        h("span", { className: "sc-unit" }, props.unit || "°C"),
        h(Trend, { tick: live.tick })),
      props.range ? h("div", { className: "sc-sensor-range" }, "Rango esperado ", props.range) : null,
      h("footer", { className: "sc-sensor-foot" },
        h(StatusMark, { status: status }),
        h(Provenance, { kind: kind, label: kind === "desactualizado" ? "Última lectura" : undefined }),
        h("span", { className: "sc-sensor-time", "aria-live": "off" }, props.simulate && !stale ? ageLabel(live.age) : (props.updated || "Actualizado hace 3 s"))));
  }

  /* -------------------------------------------------------- MoistureMeter */
  function moisturePhase(cur, target) {
    if (cur <= target) return { key: "listo", label: "Objetivo alcanzado" };
    if (cur <= target + 3) return { key: "cerca", label: "Cerca del objetivo" };
    if (cur <= 30) return { key: "secando", label: "Secando" };
    return { key: "humedo", label: "Húmedo" };
  }
  function MoistureMeter(props) {
    var initial = props.initial || 52, target = props.target || 11;
    var cur = useTween(props.current === undefined ? 14.5 : props.current, props.initial || 52, 1600);
    var max = Math.max(initial, cur);
    var pct = function (v) { return Math.max(0, Math.min(100, (v / max) * 100)); };
    var phase = moisturePhase(cur, target);
    var removed = initial - cur, total = initial - target;
    var progress = Math.max(0, Math.min(100, (removed / total) * 100));
    var ticks = [];
    for (var t = 0; t <= max; t += 5) ticks.push(t);
    var gid = useId("mm");
    return h("figure", { className: cx("sc-moist", "is-" + phase.key, props.size === "campo" && "sc-moist--campo", props.className) },
      h("figcaption", { className: "sc-moist-head" },
        h("div", null,
          h("div", { className: "sc-rotulo" }, props.label || "Humedad del café"),
          h("div", { className: "sc-moist-value" }, h("span", { className: "sc-num" }, fmt(cur)), h("span", { className: "sc-unit" }, "%"))),
        h("div", { className: "sc-moist-side" },
          h("div", { className: "sc-moist-phase" }, h(Glyph, { glyph: phase.key === "listo" ? "ok" : "dot" }), phase.label),
          h("div", { className: "sc-moist-target" }, "Objetivo ", h("b", null, fmt(target, 0), " %")),
          h(Provenance, { kind: props.kind || "medido" }))),
      h("div", { className: "sc-moist-track", role: "meter", "aria-valuemin": 0, "aria-valuemax": initial, "aria-valuenow": cur,
        "aria-valuetext": fmt(cur) + " % de humedad; objetivo " + target + " %; " + Math.round(progress) + " % del agua por retirar ya retirada" },
        h("svg", { className: "sc-moist-svg", viewBox: "0 0 1000 56", preserveAspectRatio: "none", "aria-hidden": "true" },
          h("defs", null,
            h("pattern", { id: gid + "-g", width: 22, height: 14, patternUnits: "userSpaceOnUse" },
              h("ellipse", { cx: 6, cy: 5, rx: 5, ry: 3.4, className: "sc-bean" }),
              h("ellipse", { cx: 17, cy: 11, rx: 5, ry: 3.4, className: "sc-bean" }))),
          h("rect", { x: 0, y: 0, width: 1000, height: 56, fill: "url(#" + gid + "-g)", className: "sc-moist-bed" }),
          h("clipPath", { id: gid + "-c" }, h("path", { d: "M0 0H" + (pct(cur) * 10 - 8) + "c10 8-8 14 4 22s-6 16 4 26c4 4 2 6 0 8H0z" })),
          h("path", { className: "sc-moist-water", d: "M0 0H" + (pct(cur) * 10 - 8) + "c10 8-8 14 4 22s-6 16 4 26c4 4 2 6 0 8H0z" }),
          h("g", { clipPath: "url(#" + gid + "-c)", className: "sc-moist-vapor" },
            [0, 1, 2, 3, 4, 5].map(function (i) { return h("path", { key: i, d: "M" + (i * 170 - 60) + " 60c18-14 4-22 22-34s4-22 22-34", className: "sc-vapor-line", style: { animationDelay: (i * -0.9) + "s" } }); })),
          h("rect", { className: "sc-moist-removed", x: pct(cur) * 10, y: 3, width: Math.max(0, (pct(initial) - pct(cur)) * 10), height: 50, rx: 6 })),
        h("span", { className: "sc-moist-flag", style: { left: pct(target) + "%" } }, h("span", null, "Objetivo ", fmt(target, 0), " %"))),
      h("div", { className: "sc-moist-ticks", "aria-hidden": "true" },
        ticks.map(function (v) { return h("span", { key: v, style: { left: pct(v) + "%" } }, v); })),
      props.size === "campo" ? null : h("div", { className: "sc-moist-legend" },
        h("span", null, h("i", { className: "k-water" }), "Agua por retirar"),
        h("span", null, h("i", { className: "k-removed" }), "Retirada desde ", fmt(initial, 0), " %"),
        h("span", { className: "sc-moist-progress" }, Math.round(progress), " % del secado completado")));
  }

  /* ------------------------------------------------------- ActuatorControl */
  var ACT_LABEL = { encendido: "Encendido", apagado: "Apagado", bloqueado: "Bloqueado", error: "Error", encendiendo: "Encendiendo…", apagando: "Apagando…" };
  function ActuatorControl(props) {
    var initial = props.state || "apagado";
    var st = useState(initial), state = st[0], setState = st[1];
    var md = useState(props.mode || "automatico"), mode = md[0], setMode = md[1];
    var hp = useState(0), hold = hp[0], setHold = hp[1];
    var timer = useRef(null), raf = useRef(null);
    useEffect(function () { setState(props.state || "apagado"); }, [props.state]);
    useEffect(function () { return function () { clearTimeout(timer.current); cancelAnimationFrame(raf.current); }; }, []);
    var locked = state === "bloqueado" || mode === "automatico";
    var on = state === "encendido" || state === "apagando";
    var busy = state === "encendiendo" || state === "apagando";
    function commit(next) {
      setState(next === "encendido" ? "encendiendo" : "apagando");
      timer.current = setTimeout(function () {
        var result = props.simulateFailure && next === "encendido" ? "error" : next;
        setState(result);
        if (props.onChange) props.onChange(result);
      }, props.transitionMs || 1200);
    }
    function toggle() {
      if (locked || busy || state === "error") return;
      if (on) return commit("apagado");
      if (props.guarded) return;
      commit("encendido");
    }
    function startHold(e) {
      if (!props.guarded || on || locked || busy) return;
      e.preventDefault();
      var t0 = performance.now(), dur = props.holdMs || 1500;
      var step = function (now) {
        var p = Math.min(1, (now - t0) / dur);
        setHold(p);
        if (p < 1) raf.current = requestAnimationFrame(step); else { setHold(0); commit("encendido"); }
      };
      raf.current = requestAnimationFrame(step);
    }
    function endHold() { cancelAnimationFrame(raf.current); setHold(0); }
    var swId = useId("act");
    var shownState = state === "error" ? "error" : state;
    return h("section", { className: cx("sc-act", "is-" + shownState, "mode-" + mode, "act-" + (props.icon || "ventilador"), props.size === "campo" && "sc-act--campo", props.guarded && "is-guarded", props.className), "aria-labelledby": swId + "-n" },
      h("header", { className: "sc-act-head" },
        h("span", { className: "sc-act-icon" }, h(Icon, { name: props.icon || "ventilador", size: props.size === "campo" ? 28 : 24, className: on && (props.icon || "ventilador") === "ventilador" ? "sc-fan-on" : "" })),
        h("div", null,
          h("div", { className: "sc-act-name", id: swId + "-n" }, props.name || "Ventilador principal"),
          h("div", { className: "sc-act-power" }, "Nominal ", h("b", null, props.power || "210 W"), props.runtime ? h("span", null, " · ", props.runtime) : null))),
      h("div", { className: "sc-act-body" },
        h("button", {
          type: "button", role: "switch", "aria-checked": on ? "true" : "false", className: "sc-lever", id: swId,
          "aria-labelledby": swId + "-n", "aria-describedby": swId + "-s",
          disabled: locked || state === "error", onClick: toggle,
          onPointerDown: startHold, onPointerUp: endHold, onPointerLeave: endHold,
          onKeyDown: function (e) { if (props.guarded && !on && (e.key === " " || e.key === "Enter") && !e.repeat) startHold(e); },
          onKeyUp: function (e) { if (props.guarded && (e.key === " " || e.key === "Enter")) endHold(); }
        },
          h("span", { className: "sc-lever-track" },
            h("span", { className: "sc-lever-word w-on" }, "ENC"),
            h("span", { className: "sc-lever-word w-off" }, "APAG"),
            h("span", { className: "sc-lever-knob" }, h("i"), h("i"), h("i"))),
          hold > 0 ? h("span", { className: "sc-lever-hold", style: { width: hold * 100 + "%" } }) : null),
        h("div", { className: "sc-act-state", id: swId + "-s", "aria-live": "polite" },
          h("span", { className: "sc-act-state-word" }, ACT_LABEL[shownState] || shownState),
          state === "bloqueado" ? h("span", { className: "sc-act-hint" }, h(Icon, { name: "candado", size: 16 }), props.lockReason || "Bloqueado por seguridad") :
          state === "error" ? h("span", { className: "sc-act-hint is-error" }, props.errorText || "No fue posible encender. Verifica la conexión del dispositivo.") :
          props.guarded && !on && !busy && mode === "manual" ? h("span", { className: "sc-act-hint" }, "Mantén presionado para encender") :
          mode === "automatico" ? h("span", { className: "sc-act-hint" }, "Controlado por el protocolo") : null)),
      h("div", { className: "sc-act-mode", role: "radiogroup", "aria-label": "Modo de operación" },
        ["automatico", "manual"].map(function (m) {
          return h("button", { key: m, type: "button", role: "radio", "aria-checked": mode === m ? "true" : "false", className: cx("sc-mode", mode === m && "is-on", "m-" + m),
            disabled: state === "bloqueado", onClick: function () { setMode(m); if (props.onModeChange) props.onModeChange(m); } },
            m === "manual" ? h(Icon, { name: "mano", size: 16 }) : h(Icon, { name: "sincronizar", size: 16 }),
            m === "manual" ? "Manual" : "Automático");
        })),
      props.guarded && mode === "manual" ? h("p", { className: "sc-act-warn" }, h(Glyph, { glyph: "tri" }), props.warning || "La resistencia eleva la temperatura de la cámara. Verifica que el ventilador esté encendido.") : null);
  }

  /* ------------------------------------------------------ MeasurementField */
  function MeasurementField(props) {
    var id = useId("mf");
    var invalid = !!props.error;
    return h("div", { className: cx("sc-field", invalid && "is-invalid", props.readOnly && "is-readonly", props.className) },
      h("label", { className: "sc-rotulo", htmlFor: id }, props.label || "Muestra inicial (g)"),
      h("div", { className: "sc-field-box" },
        h("input", {
          id: id, inputMode: "decimal", className: "sc-field-input", value: props.value, defaultValue: props.value === undefined ? props.defaultValue : undefined,
          readOnly: props.readOnly, onChange: props.onChange, placeholder: props.placeholder || "0.0", "aria-invalid": invalid ? "true" : undefined,
          "aria-describedby": (props.hint || props.error) ? id + "-h" : undefined
        }),
        h("span", { className: "sc-field-unit" }, props.unit || "g")),
      h("div", { className: "sc-field-ruler", "aria-hidden": "true" }),
      props.error ? h("div", { className: "sc-field-help is-error", id: id + "-h" }, h(Glyph, { glyph: "sq", size: 12 }), props.error) :
        props.hint ? h("div", { className: "sc-field-help", id: id + "-h" }, props.hint) : null);
  }

  /* ------------------------------------------------------ CalibrationTable */
  function CalibrationTable(props) {
    var rows = props.rows || [];
    return h("div", { className: "sc-table-wrap" },
      h("table", { className: "sc-table sc-calib" },
        props.caption ? h("caption", null, props.caption) : null,
        h("thead", null, h("tr", null,
          ["Sensor", "Valor de referencia", "Valor medido", "Diferencia", "Ajuste", "Estado"].map(function (c, i) {
            return h("th", { key: c, scope: "col", className: i > 0 && i < 5 ? "num" : "" }, c);
          }))),
        h("tbody", null, rows.map(function (r, i) {
          var diff = r.measured - r.reference;
          var tol = r.tolerance || 0.5;
          var ok = Math.abs(diff) <= tol;
          return h("tr", { key: i },
            h("th", { scope: "row" }, h("span", { className: "sc-calib-sensor" }, h(Icon, { name: r.icon || "temperatura", size: 18 }), r.sensor)),
            h("td", { className: "num" }, fmt(r.reference, r.decimals), " ", h("span", { className: "u" }, r.unit)),
            h("td", { className: "num" }, fmt(r.measured, r.decimals), " ", h("span", { className: "u" }, r.unit)),
            h("td", { className: cx("num", "sc-diff", ok ? "is-ok" : "is-off") }, (diff > 0 ? "+" : diff < 0 ? "−" : "±"), fmt(Math.abs(diff), r.decimals), " ", h("span", { className: "u" }, r.unit)),
            h("td", { className: "num" }, r.adjustment === undefined ? "—" : ((r.adjustment > 0 ? "+" : r.adjustment < 0 ? "−" : "±") + fmt(Math.abs(r.adjustment), r.decimals))),
            h("td", null, h(StatusMark, { status: r.status || (ok ? "normal" : "advertencia"), label: r.statusLabel || (ok ? "Dentro de tolerancia" : "Requiere ajuste") })));
        }))));
  }

  /* ------------------------------------------------------ ProcessTimeline */
  var DEFAULT_STAGES = [
    { label: "Inicio", time: "06:10" }, { label: "Calentamiento", time: "06:25" }, { label: "Secado activo", time: "07:40" },
    { label: "Reducción de humedad", time: "En curso" }, { label: "Ajustes" }, { label: "Objetivo alcanzado" }, { label: "Finalización" }
  ];
  function ProcessTimeline(props) {
    var stages = props.stages || DEFAULT_STAGES;
    var current = props.current === undefined ? 3 : props.current;
    return h("ol", { className: cx("sc-timeline", props.vertical && "is-vertical", props.className) },
      stages.map(function (s, i) {
        var st = i < current ? "done" : i === current ? "now" : "next";
        return h("li", { key: i, className: "is-" + st, "aria-current": st === "now" ? "step" : undefined },
          h("span", { className: "sc-tl-mark", "aria-hidden": "true" }),
          h("span", { className: "sc-tl-label" }, s.label),
          h("span", { className: "sc-tl-time" }, st === "now" ? (s.time || "En curso") : (s.time || (st === "next" ? "Pendiente" : ""))),
          s.flag ? h("span", { className: "sc-tl-flag" }, h(StatusMark, { status: s.flag.status, label: s.flag.label })) : null);
      }));
  }

  /* ---------------------------------------------------------- DryingCurve */
  function DryingCurve(props) {
    var W = props.width || 640, H = props.height || 260;
    var m = { l: 46, r: 18, t: 18, b: 40 };
    var measured = props.measured || [[0, 52], [2, 47.8], [4, 41.5], [6, 35.2], [8, 30.1], [10, 25.6], [12, 21.8], [14, 18.6], [16, 16.2], [18.3, 14.5]];
    var predicted = props.predicted || [[18.3, 14.5], [19.5, 13.4], [20.8, 12.3], [22.55, 11]];
    var band = props.band || [[18.3, 14.5, 14.5], [19.5, 13.0, 13.8], [20.8, 11.6, 12.9], [22.55, 10.2, 11.8]];
    var target = props.target || 11;
    var xMax = props.xMax || 24, yMax = props.yMax || 55;
    var X = function (v) { return m.l + (v / xMax) * (W - m.l - m.r); };
    var Y = function (v) { return m.t + (1 - v / yMax) * (H - m.t - m.b); };
    var line = function (pts) { return pts.map(function (p, i) { return (i ? "L" : "M") + X(p[0]).toFixed(1) + " " + Y(p[1]).toFixed(1); }).join(""); };
    var bandPath = band.map(function (p, i) { return (i ? "L" : "M") + X(p[0]) + " " + Y(p[2]); }).join("") +
      band.slice().reverse().map(function (p) { return "L" + X(p[0]) + " " + Y(p[1]); }).join("") + "Z";
    var now = measured[measured.length - 1];
    var yt = [0, 10, 20, 30, 40, 50], xt = [0, 4, 8, 12, 16, 20, 24];
    return h("figure", { className: cx("sc-chart", props.className) },
      props.title === false ? null : h("figcaption", { className: "sc-chart-head" },
        h("span", { className: "sc-chart-title" }, props.title || "Curva de secado — humedad del café"),
        h("span", { className: "sc-chart-legend" },
          h(Provenance, { kind: "medido", variant: "linea" }), h(Provenance, { kind: "prediccion", variant: "linea" }),
          h(Provenance, { kind: "objetivo", variant: "linea" }))),
      h("svg", { viewBox: "0 0 " + W + " " + H, className: "sc-chart-svg", role: "img",
        "aria-label": "Humedad del café: " + fmt(now[1]) + " % a las " + fmt(now[0]) + " h; predicción de objetivo " + target + " % hacia las " + fmt(predicted[predicted.length - 1][0]) + " h." },
        yt.map(function (v) { return h("g", { key: "y" + v }, h("line", { x1: m.l, x2: W - m.r, y1: Y(v), y2: Y(v), className: "sc-grid" }), h("text", { x: m.l - 8, y: Y(v) + 4, className: "sc-axis", textAnchor: "end" }, v)); }),
        xt.map(function (v) { return h("text", { key: "x" + v, x: X(v), y: H - m.b + 18, className: "sc-axis", textAnchor: "middle" }, v + " h"); }),
        h("text", { x: m.l - 36, y: m.t - 4, className: "sc-axis sc-axis-title" }, "%"),
        h("rect", { x: m.l, y: Y(target), width: W - m.l - m.r, height: Y(0) - Y(target), className: "sc-target-zone" }),
        h("line", { x1: m.l, x2: W - m.r, y1: Y(target), y2: Y(target), className: "sc-target-line" }),
        h("text", { x: m.l + 6, y: Y(target) - 6, className: "sc-axis sc-target-label", textAnchor: "start" }, "Objetivo " + target + " %"),
        h("path", { d: bandPath, className: "sc-band" }),
        h("line", { x1: X(now[0]), x2: X(now[0]), y1: m.t, y2: Y(0), className: "sc-now" }),
        h("text", { x: X(now[0]) + 6, y: m.t + 10, className: "sc-axis sc-now-label" }, "Ahora"),
        h("path", { d: line(measured), className: "sc-series-measured" }),
        h("path", { d: line(predicted), className: "sc-series-predicted" }),
        measured.map(function (p, i) { return h("circle", { key: "m" + i, cx: X(p[0]), cy: Y(p[1]), r: i === measured.length - 1 ? 5 : 3, className: "sc-pt" + (i === measured.length - 1 ? " is-now" : "") }); }),
        h("circle", { cx: X(now[0]), cy: Y(now[1]), r: 5, className: "sc-pt-ring" }),
        h("circle", { cx: X(predicted[predicted.length - 1][0]), cy: Y(target), r: 5, className: "sc-pt-pred" }),
        props.anomalies ? props.anomalies.map(function (a, i) {
          return h("g", { key: "a" + i, transform: "translate(" + X(a[0]) + " " + (Y(a[1]) - 16) + ")" },
            h("rect", { x: -7, y: -7, width: 14, height: 14, rx: 2.5, className: "sc-anom" }), h("text", { y: 4, textAnchor: "middle", className: "sc-anom-t" }, "!"));
        }) : null),
      h("div", { className: "sc-chart-xlabel" }, props.xLabel || "Horas de secado"));
  }

  /* ------------------------------------------------------ PredictionPanel */
  function PredictionPanel(props) {
    var conf = props.confidence === undefined ? 87 : props.confidence;
    var level = conf >= 80 ? { key: "alta", label: "Alta" } : conf >= 60 ? { key: "media", label: "Media" } : { key: "baja", label: "Baja" };
    var scale = h("div", { className: cx("sc-conf-scale", "is-" + level.key), role: "meter", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": conf, "aria-valuetext": "Confianza " + level.label.toLowerCase() + ", " + conf + " %" },
      h("div", { className: "sc-conf-track" },
        h("span", { className: "sc-conf-zone z-baja" }), h("span", { className: "sc-conf-zone z-media" }), h("span", { className: "sc-conf-zone z-alta" }),
        h("span", { className: "sc-conf-fill", style: { width: conf + "%" } }),
        h("span", { className: "sc-conf-notch", style: { left: "60%" } }), h("span", { className: "sc-conf-notch", style: { left: "80%" } }),
        h("span", { className: "sc-conf-pin", style: { left: conf + "%" } })),
      h("div", { className: "sc-conf-ticks", "aria-hidden": "true" },
        [0, 20, 40, 60, 80, 100].map(function (t) { return h("span", { key: t, style: { left: t + "%" } }); })),
      h("div", { className: "sc-conf-zones", "aria-hidden": "true" },
        h("span", { className: level.key === "baja" ? "is-on" : "" }, "Baja"),
        h("span", { className: level.key === "media" ? "is-on" : "" }, "Media"),
        h("span", { className: level.key === "alta" ? "is-on" : "" }, "Alta")));
    var vars = props.variables || ["Humedad del café", "Temperatura interior", "Humedad relativa", "Flujo de aire", "Radiación solar", "12 lotes anteriores"];
    return h("section", { className: cx("sc-pred", props.size === "campo" && "sc-pred--campo", props.className), "aria-label": "Predicción de IA" },
      h("header", { className: "sc-pred-head" },
        h(Icon, { name: "prediccion", size: 22 }),
        h("span", { className: "sc-pred-title" }, "Predicción de IA"),
        h(Provenance, { kind: "prediccion" })),
      h("div", { className: "sc-pred-main" },
        h("div", { className: "sc-rotulo" }, "Tiempo restante estimado"),
        h("div", { className: "sc-pred-value" }, h(Duration, { value: props.remaining || "4 h 15 min" })),
        h("div", { className: "sc-pred-window" }, "Entre ", h("b", null, props.low || "3 h 50 min"), " y ", h("b", null, props.high || "4 h 40 min"),
          props.eta ? h("span", null, " · objetivo hacia las ", h("b", null, props.eta)) : null)),
      h("div", { className: "sc-conf" },
        h("div", { className: "sc-conf-row" },
          h("span", { className: "sc-rotulo" }, "Confianza de la predicción"),
          h("span", { className: "sc-conf-num" }, h("b", null, conf, " %"), h("span", { className: "sc-conf-level" }, level.label))),
        scale),
      props.size === "campo" ? null : h("div", { className: "sc-pred-vars" },
        h("div", { className: "sc-rotulo" }, "Datos considerados"),
        h("ul", null, vars.map(function (v) { return h("li", { key: v }, v); }))),
      props.note === false ? null : h("p", { className: "sc-pred-note" }, props.note || "La humedad baja 0.9 % por hora; el ritmo es similar al de lotes Supremo anteriores."));
  }

  /* ------------------------------------------------------------ AlertItem */
  var ALERT = {
    informativa: { label: "Informativa", status: "info", icon: "sincronizar" },
    advertencia: { label: "Advertencia", status: "advertencia", icon: "alerta" },
    critica: { label: "Crítica", status: "critico", icon: "temperatura" },
    resuelta: { label: "Resuelta", status: "resuelta", icon: "check" }
  };
  function AlertItem(props) {
    var lv = props.level || "advertencia", a = ALERT[lv];
    return h("article", { className: cx("sc-alert", "is-" + lv, props.className), role: lv === "critica" ? "alert" : undefined },
      h("span", { className: "sc-alert-icon", "aria-hidden": "true" }, h(Icon, { name: props.icon || a.icon, size: 22 })),
      h("div", { className: "sc-alert-body" },
        h("div", { className: "sc-alert-top" },
          h(StatusMark, { status: a.status, label: a.label }),
          h("time", { className: "sc-alert-time" }, props.time || "Hace 4 min")),
        h("h4", { className: "sc-alert-title" }, props.title || "Revisión recomendada"),
        props.description ? h("p", { className: "sc-alert-desc" }, props.description) : null,
        h("div", { className: "sc-alert-meta" },
          props.batch ? h("span", null, h(Icon, { name: "lote", size: 14 }), props.batch) : null,
          props.sensor ? h("span", null, h(Icon, { name: "temperatura", size: 14 }), props.sensor) : null),
        props.action ? h("div", { className: "sc-alert-actions" },
          h(Button, { variant: lv === "critica" ? "peligro" : "secundario", size: "md", onClick: props.onAction }, props.action),
          props.secondaryAction ? h(Button, { variant: "silencioso" }, props.secondaryAction) : null) : null));
  }

  /* ---------------------------------------------------------------- Toast */
  var TOAST = { success: ["normal", "check"], info: ["info", "sincronizar"], warning: ["advertencia", "alerta"], error: ["critico", "alerta"] };
  function Toast(props) {
    var t = props.tone || "success", d = TOAST[t];
    return h("div", { className: cx("sc-toast", "is-" + t, props.className), role: t === "error" ? "alert" : "status" },
      h(StatusMark, { status: d[0], label: props.label || { success: "Listo", info: "Información", warning: "Atención", error: "Error" }[t] }),
      h("div", { className: "sc-toast-body" },
        h("div", { className: "sc-toast-title" }, props.title || "Pesaje registrado correctamente."),
        props.description ? h("div", { className: "sc-toast-desc" }, props.description) : null),
      props.onClose !== false ? h("button", { type: "button", className: "sc-iconbtn", "aria-label": "Cerrar", onClick: props.onClose }, h(Icon, { name: "cerrar", size: 18 })) : null);
  }

  /* ------------------------------------------------------------ Landscape */
  function cafetal(rows, seedOffset) {
    var out = [];
    rows.forEach(function (r, ri) {
      for (var x = r.x0; x < r.x1; x += r.step) {
        var y = r.y + Math.sin((x + ri * 40) / r.wave) * r.amp;
        out.push(h("ellipse", { key: ri + "-" + x, cx: x, cy: y, rx: r.rx, ry: r.rx * 0.72, className: "p-cafetal" }));
        if (((x * 7 + ri * 13 + seedOffset) % 9) === 0) out.push(h("circle", { key: "c" + ri + "-" + x, cx: x + r.rx * 0.5, cy: y + 1, r: 1.8, className: "p-cereza" }));
      }
    });
    return out;
  }
  function Landscape(props) {
    var scene = props.scene || "valle";
    var fid = useId("gw");
    var filters = h("defs", null,
      h("filter", { id: fid, x: "-5%", y: "-5%", width: "110%", height: "110%" },
        h("feTurbulence", { type: "fractalNoise", baseFrequency: "0.035", numOctaves: 2, seed: 7, result: "n" }),
        h("feDisplacementMap", { in: "SourceGraphic", in2: "n", scale: 5, xChannelSelector: "R", yChannelSelector: "G", result: "d" }),
        h("feTurbulence", { type: "fractalNoise", baseFrequency: "0.9", numOctaves: 1, seed: 3, result: "g" }),
        h("feColorMatrix", { in: "g", type: "matrix", values: "0 0 0 0 0.17  0 0 0 0 0.12  0 0 0 0 0.08  0 0 0 0.10 0", result: "gg" }),
        h("feComposite", { in: "gg", in2: "d", operator: "in", result: "grain" }),
        h("feMerge", null, h("feMergeNode", { in: "d" }), h("feMergeNode", { in: "grain" }))));
    if (scene === "loma") {
      return h("svg", { className: cx("sc-land", "sc-land--loma", props.className), viewBox: "0 0 400 120", preserveAspectRatio: props.preserve || "xMidYMax slice", role: props.title ? "img" : undefined, "aria-hidden": props.title ? undefined : "true", "aria-label": props.title },
        filters,
        h("g", { filter: "url(#" + fid + ")" },
          h("path", { className: props.onDark ? "p-loma-oscura" : "p-cordillera", d: "M-10 70C40 40 80 52 130 34s90 10 140-4 90 6 140 18V130H-10Z" }),
          h("path", { className: props.onDark ? "p-cafetal" : "p-loma", d: "M-10 92C60 70 120 82 200 72s140 6 210-6V130H-10Z" }),
          cafetal([{ x0: 10, x1: 400, step: 16, y: 96, amp: 3, wave: 40, rx: 5 }, { x0: 2, x1: 400, step: 18, y: 110, amp: 3, wave: 50, rx: 6 }], 1),
          props.onDark ? null : h("circle", { className: "p-sol", cx: 320, cy: 30, r: 14 })));
    }
    var k = props.wide ? 2 : 1, VW = 640 * k;
    var ox = props.wide ? 300 : 0;
    var dryer = h("g", { className: "sc-land-dryer", transform: "translate(" + ox + " 0)" },
      h("path", { className: "p-niebla", d: "M118 232V196c0-40 186-40 186 0v36z" }),
      h("path", { className: "p-marco", d: "M118 232V196c0-40 186-40 186 0v36M150 232v-58M180 232v-66M211 232v-68M242 232v-66M272 232v-58" }),
      h("rect", { className: "p-barro", x: 128, y: 214, width: 166, height: 10, rx: 4 }),
      [134, 146, 158, 170, 182, 194, 206, 218, 230, 242, 254, 266, 278].map(function (x, i) { return h("ellipse", { key: x, className: "p-grano", cx: x + (i % 2) * 3, cy: 214, rx: 4.5, ry: 3 }); }),
      h("rect", { className: "p-marco-fill", x: 298, y: 200, width: 18, height: 18, rx: 4 }),
      h("circle", { className: "p-niebla", cx: 307, cy: 209, r: 5 }),
      h("path", { className: "p-aire", d: "M160 160c10-10 0-18 10-28M206 154c10-10 0-18 10-28M252 160c10-10 0-18 10-28" }),
      h("path", { className: "p-marco", d: "M352 232v-20" }),
      h("path", { className: "p-panel", d: "M330 214l38-15 30 11-38 15z" }),
      h("path", { className: "p-panel-line", d: "M342 209.5l30 11M355 204.5l30 11M349 202l-7 21M362 207l-7 21" }));
    var rows = [
      { x0: 380, x1: 650, step: 14, y: 170, amp: 4, wave: 30, rx: 5 },
      { x0: 360, x1: 650, step: 15, y: 186, amp: 4, wave: 34, rx: 5.5 },
      { x0: 340, x1: 650, step: 16, y: 203, amp: 4, wave: 38, rx: 6 },
      { x0: -10, x1: 110, step: 15, y: 196, amp: 3, wave: 30, rx: 5.5 },
      { x0: -10, x1: 110, step: 16, y: 212, amp: 3, wave: 34, rx: 6 }];
    if (props.wide) rows = [
      { x0: 860, x1: 1290, step: 14, y: 168, amp: 4, wave: 30, rx: 5 },
      { x0: 820, x1: 1290, step: 15, y: 186, amp: 4, wave: 34, rx: 5.5 },
      { x0: 780, x1: 1290, step: 16, y: 203, amp: 4, wave: 38, rx: 6 },
      { x0: -10, x1: 330, step: 15, y: 194, amp: 3, wave: 30, rx: 5.5 },
      { x0: -10, x1: 360, step: 16, y: 210, amp: 3, wave: 34, rx: 6 }];
    return h("svg", { className: cx("sc-land", props.animated && "is-animated", props.className), viewBox: "0 0 " + VW + " 280", preserveAspectRatio: props.preserve || "xMidYMid slice", role: props.title ? "img" : undefined, "aria-hidden": props.title ? undefined : "true", "aria-label": props.title },
      filters,
      h("g", { filter: "url(#" + fid + ")" },
        props.sky === false ? null : h("rect", { className: "p-cielo", x: -10, y: -10, width: VW + 20, height: 300 }),
        h("circle", { className: "p-sol p-halo", cx: props.wide ? 700 : VW - 128, cy: 72, r: 54 }),
        h("circle", { className: "p-sol", cx: props.wide ? 700 : VW - 128, cy: 72, r: 32 }),
        h("g", { className: "p-nube-g n1" }, h("path", { className: "p-niebla p-nube", d: "M60 70c6-16 30-18 40-6 10-12 34-8 36 8 14 0 18 16 4 18H66c-16 0-18-18-6-20z" })),
        h("g", { className: "p-nube-g n2" }, h("path", { className: "p-niebla p-nube", transform: "translate(" + (props.wide ? 560 : 250) + " -30) scale(.7)", d: "M60 70c6-16 30-18 40-6 10-12 34-8 36 8 14 0 18 16 4 18H66c-16 0-18-18-6-20z" })),
        props.wide ? h("g", { className: "p-nube-g n3" }, h("path", { className: "p-niebla p-nube", transform: "translate(980 -6) scale(.9)", d: "M60 70c6-16 30-18 40-6 10-12 34-8 36 8 14 0 18 16 4 18H66c-16 0-18-18-6-20z" })) : null,
        h("g", { transform: "scale(" + k + " 1)" },
          h("path", { className: "p-cordillera", d: "M-10 154C50 112 100 122 156 98s96 6 146-8 102-50 150-26 108 6 198 30V290H-10Z" }),
          h("path", { className: "p-loma", d: "M-10 194C70 154 156 166 240 146s136 8 220-8 120 2 190-6V290H-10Z" })),
        cafetal(rows, 0),
        h("g", { transform: "scale(" + k + " 1)" },
          h("path", { className: "p-hoja", d: "M-10 232C110 214 250 218 360 226s200-8 290-2V290H-10Z" })),
        scene === "vacio" ? null : dryer,
        h("g", { transform: "translate(" + (VW - 640) + " 0)" }, h("g", { className: "p-arbol" },
          h("path", { className: "p-tronco", d: "M577 244v-44" }),
          h("path", { className: "p-cafetal", d: "M560 236c-8-30 4-52 18-60 14 8 24 30 14 60z" }))),
        h("g", { className: "p-arbol a2" }, h("path", { className: "p-cafetal", d: "M30 246c-8-22 2-40 14-46 12 6 22 24 12 46z" }))));
  }

  /* ----------------------------------------------------------- EmptyState */
  function EmptyState(props) {
    return h("div", { className: cx("sc-empty", props.className) },
      h("div", { className: "sc-empty-art" }, h(Landscape, { scene: props.scene || "vacio", animated: props.animated !== false })),
      h("h3", { className: "sc-empty-title" }, props.title || "No hay lotes registrados."),
      h("p", { className: "sc-empty-text" }, props.text || "Cuando ingreses café al secador, su registro aparecerá aquí."),
      props.action ? h(Button, { variant: "primario", icon: props.actionIcon || "lote", onClick: props.onAction }, props.action) : null);
  }

  /* -------------------------------------------------------------- SideNav */
  var NAV = [
    { id: "inicio", label: "Inicio", icon: "solar" }, { id: "monitoreo", label: "Monitoreo", icon: "temperatura" },
    { id: "actuadores", label: "Actuadores", icon: "ventilador" }, { id: "lotes", label: "Lotes", icon: "lote" },
    { id: "gravimetria", label: "Gestión gravimétrica", icon: "balanza" }, { id: "calibracion", label: "Calibración", icon: "calibracion" },
    { id: "historial", label: "Historial", icon: "historial" }, { id: "alertas", label: "Alertas", icon: "alerta" }, { id: "mapa", label: "Mapa", icon: "mapa" }
  ];
  function SideNav(props) {
    var items = props.items || NAV;
    var active = props.active || "inicio";
    return h("nav", { className: cx("sc-nav", props.className), "aria-label": "Navegación principal" },
      h("div", { className: "sc-nav-brand" },
        h("span", { className: "sc-nav-word" }, "SISCAN"),
        h("span", { className: "sc-nav-sub" }, "Secado Inteligente de Café")),
      h("ul", { className: "sc-nav-list" }, items.map(function (it) {
        var on = it.id === active;
        return h("li", { key: it.id },
          h("a", { href: it.href || "#" + it.id, className: cx("sc-nav-item", on && "is-active"), "aria-current": on ? "page" : undefined, onClick: props.onNavigate ? function (e) { e.preventDefault(); props.onNavigate(it.id); } : undefined },
            h(Icon, { name: it.icon, size: 20 }), h("span", null, it.label),
            it.badge ? h("span", { className: "sc-nav-badge", "aria-label": it.badge + " pendientes" }, it.badge) : null));
      })),
      h("div", { className: "sc-nav-foot" },
        h(ConnectionStatus, { status: props.connection || "conectado", onDark: true, detail: props.device || "Secador CISNA · Pasto" }),
        h(Landscape, { scene: "loma", onDark: true, className: "sc-nav-land" })));
  }

  /* ------------------------------------------------------- ActiveBatchHero */
  function ActiveBatchHero(props) {
    var b = props.batch || {};
    var lm = useLive(b.moisture === undefined ? 14.5 : b.moisture, { on: props.simulate, jitter: .1, drift: .9, every: 7000 });
    var lt = useLive(b.temperature === undefined ? 40.5 : b.temperature, { on: props.simulate, jitter: .3, every: 4500 });
    var tShown = useTween(lt.value, lt.value * 0.8, 1300);
    function reading(icon, label, value, kind, unit, tick) {
      return h("div", { className: cx("sc-hero-r", kind === "prediccion" && "is-pred") },
        h("div", { className: "sc-rotulo" }, h(Icon, { name: icon, size: 16 }), label),
        h("div", { className: "sc-hero-v" }, unit ? [h("span", { key: "n" + (tick ? tick.k : ""), className: cx("sc-num", tick && tick.k && "is-fresh") }, value), h("span", { key: "u", className: "sc-unit" }, unit), h(Trend, { key: "t", tick: tick })] : h(Duration, { value: value })),
        h(Provenance, { kind: kind }));
    }
    var arrow = function (k) { return h("div", { key: k, className: "sc-hero-arrow", "aria-hidden": "true" }); };
    return h("section", { className: cx("sc-hero", props.className), "aria-label": "Lote activo" },
      h("div", { className: "sc-hero-art" },
        h(Landscape, { scene: "valle", wide: true, animated: props.animated !== false, preserve: "xMidYMax slice" }),
        h(BatchTag, { code: b.code || "LOTE B", variety: b.variety || "Café Supremo", protocol: b.protocol || "Continuo · 40 °C", date: b.date || "29 sep · 06:10", status: b.status || "secando", className: "sc-hero-tag" })),
      h("div", { className: "sc-hero-sheet" },
        h("div", { className: "sc-hero-title" },
          h("div", { className: "sc-rotulo" }, "Lote activo"),
          h("h2", { className: "display" }, (b.variety || "Café Supremo"), " — ", (b.name || "Lote B")),
          h("p", { className: "sc-hero-verdict" }, h(StatusMark, { status: props.status || "normal", label: props.verdict || "Proceso dentro del rango esperado" }))),
        h("div", { className: "sc-hero-meter" }, h(MoistureMeter, { initial: b.initial || 52, current: lm.value, target: b.target || 11 })),
        h("div", { className: "sc-hero-readings" },
          reading("temperatura", "Temperatura interior", fmt(tShown), "medido", "°C", lt.tick),
          arrow(1),
          reading("historial", "Tiempo de secado", b.elapsed || "18 h 20 min", "medido"),
          arrow(2),
          reading("prediccion", "Tiempo restante", b.remaining || "4 h 15 min", "prediccion"),
          arrow(3),
          reading("energia", "Consumo", fmt(b.power === undefined ? 212 : b.power, 0), "medido", "W"))));
  }

  /* ------------------------------------------------------------ TextField */
  function TextField(props) {
    var id = useId("tf");
    var isPwd = props.type === "password";
    var sh = useState(false), show = sh[0], setShow = sh[1];
    var invalid = !!props.error;
    var help = props.error || props.hint;
    return h("div", { className: cx("sc-tf", invalid && "is-invalid", props.size === "campo" && "sc-tf--campo", props.className), style: props.style },
      h("div", { className: "sc-tf-top" },
        h("label", { className: "sc-tf-label", htmlFor: id }, props.label),
        props.aside || null),
      h("div", { className: "sc-tf-box" },
        props.icon ? h("span", { className: "sc-tf-tile", "aria-hidden": "true" }, h(Icon, { name: props.icon, size: props.size === "campo" ? 20 : 18 })) : null,
        h("input", {
          id: id, name: props.name, type: isPwd ? (show ? "text" : "password") : (props.type || "text"), className: "sc-tf-input",
          value: props.value, defaultValue: props.value === undefined ? props.defaultValue : undefined, onChange: props.onChange,
          placeholder: props.placeholder, autoComplete: props.autoComplete, inputMode: props.inputMode, required: props.required,
          "aria-invalid": invalid ? "true" : undefined, "aria-describedby": help ? id + "-h" : undefined
        }),
        isPwd ? h("button", { type: "button", className: "sc-tf-eye", "aria-label": show ? "Ocultar contraseña" : "Mostrar contraseña", "aria-pressed": show ? "true" : "false", onClick: function () { setShow(!show); } },
          h(Icon, { name: show ? "ojo-cerrado" : "ojo", size: 18 })) : null,
        props.valid && !invalid ? h("span", { className: "sc-tf-ok", "aria-hidden": "true" }, h(Glyph, { glyph: "ok", size: 16 })) : null),
      help ? h("div", { className: cx("sc-tf-help", invalid && "is-error"), id: id + "-h", role: invalid ? "alert" : undefined },
        invalid ? h(Glyph, { glyph: "sq", size: 12 }) : null, help) : null);
  }

  /* ------------------------------------------------------------- Checkbox */
  function Checkbox(props) {
    var id = useId("cb");
    return h("label", { className: cx("sc-check", props.className), htmlFor: id },
      h("input", { id: id, type: "checkbox", className: "sc-check-input", checked: props.checked, defaultChecked: props.checked === undefined ? props.defaultChecked : undefined, onChange: props.onChange, name: props.name }),
      h("span", { className: "sc-check-box", "aria-hidden": "true" },
        h("svg", { viewBox: "0 0 16 16", width: 16, height: 16 }, h("path", { d: "M3.5 8.4l2.8 2.8 6.2-6.4", className: "sc-check-mark" }))),
      h("span", { className: "sc-check-label" }, props.label));
  }

  /* ------------------------------------------------------------ LoginForm */
  function LoginForm(props) {
    var campo = props.size === "campo";
    var e = useState(props.defaultEmail || ""), email = e[0], setEmail = e[1];
    var p = useState(props.defaultPassword || ""), pwd = p[0], setPwd = p[1];
    var s = useState("idle"), status = s[0], setStatus = s[1];
    var er = useState({}), errors = er[0], setErrors = er[1];
    var sk = useState(0), shake = sk[0], setShake = sk[1];
    var t = useRef(null);
    useEffect(function () { return function () { clearTimeout(t.current); }; }, []);
    function submit(ev) {
      ev.preventDefault();
      if (status === "loading" || status === "ok") return;
      var next = {};
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = email ? "Revisa el correo: falta algo después de la @." : "Escribe tu correo.";
      if (!pwd) next.pwd = "Escribe tu contraseña.";
      setErrors({});
      if (next.email || next.pwd) { setStatus("idle"); setShake(shake + 1); setTimeout(function () { setErrors(next); }, 20); return; }
      setStatus("loading");
      t.current = setTimeout(function () {
        if (props.simulateError || pwd === "error") { setStatus("error"); setShake(shake + 1); return; }
        setStatus("ok");
        if (props.onSuccess) props.onSuccess({ email: email });
        if (props.resetAfter) t.current = setTimeout(function () { setStatus("idle"); }, props.resetAfter);
      }, props.delay || 1400);
    }
    var d = function (i) { return { "--d": (props.baseDelay || 0) + i * 70 + "ms" }; };
    return h("form", { className: cx("sc-login", campo && "sc-login--campo", "is-" + status, props.className), noValidate: true, onSubmit: submit, "aria-busy": status === "loading" ? "true" : undefined },
      h(TextField, { className: "sc-enter", style: d(0), label: "Correo", icon: "correo", type: "email", name: "email", autoComplete: "email", inputMode: "email",
        placeholder: "nombre@correo.com", value: email, size: props.size, error: errors.email, valid: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
        onChange: function (ev) { setEmail(ev.target.value); if (errors.email) setErrors(Object.assign({}, errors, { email: null })); } }),
      h(TextField, { className: "sc-enter", style: d(1), label: "Contraseña", icon: "candado", type: "password", name: "password", autoComplete: "current-password",
        placeholder: "Tu contraseña", value: pwd, size: props.size, error: errors.pwd,
        onChange: function (ev) { setPwd(ev.target.value); if (errors.pwd) setErrors(Object.assign({}, errors, { pwd: null })); } }),
      h("div", { className: "sc-login-row sc-enter", style: d(2) },
        h(Checkbox, { label: "Recordarme en este equipo", defaultChecked: true }),
        h("a", { className: "sc-link", href: props.forgotHref || "#recuperar", onClick: props.onForgot }, "¿Olvidaste tu contraseña?")),
      status === "error" ? h("div", { className: "sc-login-error", role: "alert", key: "err" + shake },
        h(StatusMark, { status: "critico", variant: "linea", label: "No pudimos verificar tus datos." }),
        h("span", null, "Revisa el correo y la contraseña, o pide ayuda al administrador de CISNA.")) : null,
      h("div", { className: "sc-enter", style: d(3) },
        h(Button, {
          type: "submit", size: "lg", className: "sc-btn--block sc-login-submit",
          tone: status === "ok" ? "cafeto" : undefined, icon: status === "ok" ? "check" : "flecha",
          loading: status === "loading", loadingLabel: "Verificando…"
        }, status === "ok" ? (props.successLabel || "¡Bienvenido!") : (props.submitLabel || "Ingresar"))),
      props.footer ? h("div", { className: "sc-login-foot sc-enter", style: d(4) }, props.footer) : null);
  }

  /* ----------------------------------------------------------- HomeWidget */
  // Widgets de la pantalla de inicio del teléfono (Android / iOS). Tamaños: s 2×2, m 4×2, l 4×4.
  function MiniTube(props) {
    var pct = Math.max(0, Math.min(1, props.value / props.initial));
    var tg = Math.max(0, Math.min(1, props.target / props.initial));
    var H = 100, top = H * (1 - pct);
    return h("svg", { className: "sc-wg-tube", viewBox: "0 0 30 100", preserveAspectRatio: "none", "aria-hidden": "true" },
      h("rect", { x: 1, y: 1, width: 28, height: 98, rx: 14, className: "tube-bed" }),
      h("rect", { x: 1, y: top, width: 28, height: H - top - 1, rx: 12, className: "tube-water" }),
      [0, 1, 2].map(function (i) { return h("path", { key: i, d: "M" + (8 + i * 7) + " 98c-3-8 3-12 0-20s3-12 0-20", className: "tube-vapor", style: { animationDelay: (-i * .8) + "s" } }); }),
      h("path", { d: "M-2 " + (H * (1 - tg)) + "H32", className: "tube-target" }));
  }
  function WidgetHead(props) {
    return h("div", { className: "sc-wg-head" },
      h("span", { className: "sc-wg-app" }, h(Icon, { name: props.icon || "muestra", size: 14 })),
      h("span", { className: "sc-wg-title" }, props.title),
      props.live ? h("span", { className: "sc-live", title: "Datos recientes" }) : null);
  }
  function HomeWidget(props) {
    var kind = props.kind || "humedad";
    var d = Object.assign({ batch: "Lote B", variety: "Café Supremo", moisture: 14.5, initial: 52, target: 11, temperature: 40.5, remaining: "4 h 15 min", eta: "18:27", confidence: 87, updated: "14:10" }, props.data || {});
    var lm = useLive(d.moisture, { on: props.simulate, jitter: .1, drift: .9, every: 8000 });
    var moist = useTween(lm.value, d.initial, 1500);
    var fs = useState(props.fanOn !== false), fan = fs[0], setFan = fs[1];
    var upd = props.simulate && lm.tick.k ? "Ahora" : "Actualizado " + d.updated;
    var size = props.size || ({ humedad: "s", prediccion: "s", alertas: "s", lote: "m", equipo: "m", curva: "l" })[kind];
    var body;
    if (kind === "humedad") {
      body = [
        h(WidgetHead, { key: "h", icon: "humedad", title: d.batch, live: true }),
        h("div", { key: "b", className: "sc-wg-hum" },
          h("div", null,
            h("div", { className: "sc-wg-big" }, h("span", { className: cx("sc-num", lm.tick.k && "is-fresh"), key: lm.tick.k }, fmt(moist)), h("span", { className: "sc-unit" }, "%")),
            h("div", { className: "sc-wg-phase" }, "Secando"),
            h("div", { className: "sc-wg-meta" }, "Objetivo ", h("b", null, d.target, " %"))),
          h(MiniTube, { value: moist, initial: d.initial, target: d.target })),
        h("div", { key: "f", className: "sc-wg-foot" }, upd)];
    } else if (kind === "prediccion") {
      body = [
        h(WidgetHead, { key: "h", icon: "prediccion", title: "Predicción" }),
        h("div", { key: "l", className: "sc-wg-label" }, "Listo en"),
        h("div", { key: "v", className: "sc-wg-pred" }, h(Duration, { value: d.remaining })),
        h("div", { key: "e", className: "sc-wg-meta" }, "hacia las ", h("b", null, d.eta)),
        h("div", { key: "c", className: "sc-wg-conf" },
          h("span", { className: "sc-wg-conf-track" }, h("span", { className: "sc-wg-conf-fill", style: { width: d.confidence + "%" } })),
          h("span", { className: "sc-wg-conf-n" }, d.confidence, " %"))];
    } else if (kind === "alertas") {
      var lv = props.level || "critica";
      body = [
        h(WidgetHead, { key: "h", icon: "alerta", title: "Alertas" }),
        h("div", { key: "s", className: "sc-wg-alert-seal" }, h(StatusMark, { status: lv === "critica" ? "critico" : lv === "advertencia" ? "advertencia" : "normal", variant: "solido", label: lv === "critica" ? "1 crítica" : lv === "advertencia" ? "1 aviso" : "Todo en orden" })),
        h("div", { key: "t", className: "sc-wg-alert-t" }, d.alert || (lv === "critica" ? "Posible anomalía térmica" : lv === "advertencia" ? "Humedad relativa alta" : "Sin alertas pendientes")),
        h("div", { key: "f", className: "sc-wg-foot" }, d.alertTime || "10:42", " · ", d.batch)];
    } else if (kind === "lote") {
      body = [
        h("div", { key: "a", className: "sc-wg-band" }, h(Landscape, { scene: "valle", wide: true, animated: true, preserve: "xMidYMax slice" }),
          h("div", { className: "sc-wg-band-tag" }, h("span", null, d.batch.toUpperCase()), d.variety)),
        h("div", { key: "r", className: "sc-wg-row" },
          h("div", null, h("div", { className: "sc-wg-k" }, "Humedad"), h("div", { className: "sc-wg-v" }, h("span", { className: cx("sc-num", lm.tick.k && "is-fresh"), key: lm.tick.k }, fmt(moist)), h("small", null, "%"))),
          h("div", null, h("div", { className: "sc-wg-k" }, "Temperatura"), h("div", { className: "sc-wg-v" }, fmt(d.temperature), h("small", null, "°C"))),
          h("div", { className: "is-pred" }, h("div", { className: "sc-wg-k" }, "Faltan"), h("div", { className: "sc-wg-v" }, h(Duration, { value: d.remaining.replace(" min", "") })))),
        h("div", { key: "f", className: "sc-wg-foot sc-wg-foot--row" }, h("span", { className: "sc-live" }), upd)];
    } else if (kind === "equipo") {
      body = [
        h(WidgetHead, { key: "h", icon: "ventilador", title: "Equipo · " + d.batch }),
        h("div", { key: "g", className: "sc-wg-eq" },
          h("button", { type: "button", className: cx("sc-wg-tog", fan && "is-on"), "aria-pressed": fan ? "true" : "false", onClick: function () { setFan(!fan); } },
            h("span", { className: "sc-wg-tog-ic" }, h(Icon, { name: "ventilador", size: 22, className: fan ? "sc-fan-on" : "" })),
            h("span", { className: "sc-wg-tog-t" }, "Ventilador"),
            h("span", { className: "sc-wg-tog-s" }, fan ? "Encendido" : "Apagado")),
          h("a", { href: props.appHref || "#controles", className: "sc-wg-tog is-guarded" },
            h("span", { className: "sc-wg-tog-ic" }, h(Icon, { name: "resistencia", size: 22 })),
            h("span", { className: "sc-wg-tog-t" }, "Resistencia"),
            h("span", { className: "sc-wg-tog-s" }, h(Icon, { name: "candado", size: 12 }), "Abrir en la app")))];
    } else {
      var pts = [[0, 52], [3, 44], [6, 35.2], [9, 28], [12, 21.8], [15, 17.4], [18.3, 14.5]], pr = [[18.3, 14.5], [20.5, 12.4], [22.6, 11]];
      var X = function (v) { return 6 + v / 24 * 294; }, Y = function (v) { return 8 + (1 - v / 55) * 104; };
      var ln = function (a) { return a.map(function (p, i) { return (i ? "L" : "M") + X(p[0]).toFixed(1) + " " + Y(p[1]).toFixed(1); }).join(""); };
      body = [
        h(WidgetHead, { key: "h", icon: "muestra", title: d.variety + " — " + d.batch, live: true }),
        h("div", { key: "t", className: "sc-wg-l-top" },
          h("div", null, h("div", { className: "sc-wg-big" }, h("span", { className: "sc-num" }, fmt(moist)), h("span", { className: "sc-unit" }, "%")), h("div", { className: "sc-wg-phase" }, "Secando · objetivo ", d.target, " %")),
          h("div", { className: "sc-wg-l-pred" }, h("div", { className: "sc-wg-k" }, "Faltan"), h("div", { className: "sc-wg-pred" }, h(Duration, { value: d.remaining })))),
        h("svg", { key: "c", className: "sc-wg-curve", viewBox: "0 0 306 120", "aria-label": "Curva de humedad del lote" },
          h("rect", { x: 6, y: Y(d.target), width: 294, height: Y(0) - Y(d.target), className: "sc-target-zone" }),
          h("line", { x1: 6, x2: 300, y1: Y(d.target), y2: Y(d.target), className: "sc-target-line" }),
          h("path", { d: ln(pts), className: "sc-series-measured" }),
          h("path", { d: ln(pr), className: "sc-series-predicted" }),
          h("circle", { cx: X(18.3), cy: Y(14.5), r: 4, className: "sc-pt is-now" }),
          h("circle", { cx: X(18.3), cy: Y(14.5), r: 4, className: "sc-pt-ring" })),
        h("div", { key: "r", className: "sc-wg-row sc-wg-row--l" },
          h("div", null, h("div", { className: "sc-wg-k" }, "Temperatura"), h("div", { className: "sc-wg-v" }, fmt(d.temperature), h("small", null, "°C"))),
          h("div", null, h("div", { className: "sc-wg-k" }, "Ventilador"), h("div", { className: "sc-wg-v sc-wg-v--s" }, h(Icon, { name: "ventilador", size: 16, className: "sc-fan-on" }), "Enc.")),
          h("div", null, h("div", { className: "sc-wg-k" }, "Alertas"), h("div", { className: "sc-wg-v sc-wg-v--s" }, h(Glyph, { glyph: "ok", size: 14 }), "0"))),
        h("div", { key: "f", className: "sc-wg-foot" }, upd)];
    }
    return h("a", { href: props.href || "#abrir-siscan", className: cx("sc-wg", "sc-wg--" + size, "sc-wg-" + kind, kind === "alertas" && "lv-" + (props.level || "critica"), lm.tick.k && "is-refresh", props.className), style: props.style,
      "aria-label": props.label || ("Widget SISCAN: " + kind) },
      h("span", { className: "sc-wg-sweep", key: "sw" + lm.tick.k, "aria-hidden": "true" }), body);
  }

  /* ----------------------------------------------------------- LockWidget */
  // Accesorios de la pantalla de bloqueo: monocromos, sobre el fondo del teléfono.
  function LockWidget(props) {
    var shape = props.shape || "rect";
    var m = props.moisture === undefined ? 14.5 : props.moisture, initial = props.initial || 52;
    if (shape === "circle") {
      var f = Math.max(0, Math.min(1, m / initial));
      return h("div", { className: "sc-lk sc-lk--circle", "aria-label": "Humedad " + fmt(m) + " %" },
        h("svg", { viewBox: "0 0 40 40", width: 34, height: 34, "aria-hidden": "true" },
          h("defs", null, h("clipPath", { id: "lkdrop" }, h("path", { d: "M20 3c7 8.5 12 15 12 21.5a12 12 0 0 1-24 0C8 18 13 11.5 20 3z" }))),
          h("path", { d: "M20 3c7 8.5 12 15 12 21.5a12 12 0 0 1-24 0C8 18 13 11.5 20 3z", className: "lk-drop" }),
          h("rect", { x: 0, y: 3 + 34 * (1 - f), width: 40, height: 40, clipPath: "url(#lkdrop)", className: "lk-fill" })),
        h("span", { className: "lk-n" }, fmt(m), "%"));
    }
    if (shape === "inline") return h("div", { className: "sc-lk sc-lk--inline" }, h(Icon, { name: "muestra", size: 14 }), " ", props.batch || "Lote B", " · ", fmt(m), " % · faltan ", props.remaining || "4 h 15");
    return h("div", { className: "sc-lk sc-lk--rect" },
      h("div", { className: "lk-t" }, h(Icon, { name: "muestra", size: 13 }), "SISCAN · ", props.batch || "Lote B"),
      h("div", { className: "lk-v" }, fmt(m), " %", h("span", null, " → ", props.target || 11, " %")),
      h("div", { className: "lk-s" }, "Faltan ", props.remaining || "4 h 15 min"),
      h("span", { className: "lk-bar" }, h("span", { style: { width: Math.round(((initial - m) / (initial - (props.target || 11))) * 100) + "%" } })));
  }

  var api = {
    Icon: Icon, Button: Button, StatusMark: StatusMark, Provenance: Provenance, ConnectionStatus: ConnectionStatus, BatchTag: BatchTag,
    SensorReading: SensorReading, MoistureMeter: MoistureMeter, ActuatorControl: ActuatorControl, MeasurementField: MeasurementField,
    CalibrationTable: CalibrationTable, ProcessTimeline: ProcessTimeline, DryingCurve: DryingCurve, PredictionPanel: PredictionPanel,
    AlertItem: AlertItem, Toast: Toast, Landscape: Landscape, EmptyState: EmptyState, SideNav: SideNav, ActiveBatchHero: ActiveBatchHero,
    Glyph: Glyph, Duration: Duration, TextField: TextField, Checkbox: Checkbox, LoginForm: LoginForm, HomeWidget: HomeWidget, LockWidget: LockWidget
  };
  window.Siscan = Object.assign(window.Siscan || {}, api);
})();
