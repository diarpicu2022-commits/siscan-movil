/* @ds-bundle: {"format":4,"namespace":"Siscan","components":[{"name":"Icon"},{"name":"Logo"},{"name":"CoffeeLeafArt"},{"name":"Button"},{"name":"IconButton"},{"name":"TextField"},{"name":"Select"},{"name":"Switch"},{"name":"Segmented"},{"name":"Checkbox"},{"name":"StatusPill"},{"name":"Chip"},{"name":"LiveDot"},{"name":"Avatar"},{"name":"ProgressBar"},{"name":"Toast"},{"name":"CardTitle"},{"name":"Sparkline"},{"name":"MetricCard"},{"name":"RingGauge"},{"name":"MoistureChart"},{"name":"EnergyCard"},{"name":"ActuatorEnergy"},{"name":"PredictionCard"},{"name":"ProcessTimeline"},{"name":"MoistureScale"},{"name":"ConditionsTable"},{"name":"WeatherCard"},{"name":"WeatherChip"},{"name":"Landscape"},{"name":"ActiveBatchHero"},{"name":"BatchCard"},{"name":"ActuatorRow"},{"name":"ActuatorControl"},{"name":"CommandLog"},{"name":"SensorRow"},{"name":"AlertItem"},{"name":"AlertList"},{"name":"HealthCard"},{"name":"WeighingPanel"},{"name":"GravimetCalibration"},{"name":"SensorCalibration"},{"name":"DryerMap"},{"name":"StatusLegend"},{"name":"LocationCard"},{"name":"BatchTable"},{"name":"ProtocolComparison"},{"name":"NewBatchForm"},{"name":"DryerPhoto"},{"name":"EmptyState"},{"name":"Sidebar"},{"name":"TopBar"},{"name":"PageHeader"},{"name":"AppShell"},{"name":"LoginWeb"},{"name":"AndroidFrame"},{"name":"AndroidNav"},{"name":"AppBar"},{"name":"ListItem"},{"name":"ReadingTile"},{"name":"HoldButton"},{"name":"NotificationCard"},{"name":"HomeWidget"},{"name":"WatchFrame"},{"name":"WatchArc"},{"name":"WatchMonitor"},{"name":"WatchReadings"},{"name":"WatchActuators"},{"name":"WatchPrediction"},{"name":"WatchAlert"},{"name":"WatchWeigh"},{"name":"WatchConfirm"},{"name":"WatchTile"},{"name":"WatchFace"},{"name":"WatchAmbient"},{"name":"WatchBatches"}]} */
(function () {
  var React = window.React;
  var h = React.createElement;
  var F = React.Fragment;

  var ASSETS = {
    logo: '../assets/Logo/siscan-logo.png',
    logoClaro: '../assets/Logo/siscan-logo-claro.png',
    simbolo: '../assets/Logo/siscan-simbolo.png',
    simboloClaro: '../assets/Logo/siscan-simbolo-claro.png',
    wordmark: '../assets/Logo/siscan-wordmark.png',
    wordmarkClaro: '../assets/Logo/siscan-wordmark-claro.png',
    granoHojasClaro: '../assets/Ilustracion/grano-hojas-claro.png',
    granoHojas: '../assets/Ilustracion/grano-hojas.png'
  };

  function cx() { var o = []; for (var i = 0; i < arguments.length; i++) if (arguments[i]) o.push(arguments[i]); return o.join(' '); }
  function num(v, d) {
    if (v == null || isNaN(v)) return '—';
    var s = Math.abs(Number(v)).toFixed(d == null ? 1 : d);
    var parts = s.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return (v < 0 ? '−' : '') + parts.join(',');
  }
  function signed(v, d) { return (v > 0 ? '+' : v < 0 ? '−' : '') + num(Math.abs(v), d); }
  function money(v) { return '$ ' + num(v, 0); }

  /* ---------------- icons ----------------
     Trazo de 24px, 1,75. La mayoría son de Lucide (licencia ISC);
     el grano de café, el secador y la resistencia son propios. */
  function pth(d) { return ['path', { d: d }]; }
  function cir(x, y, r, fill) { return ['circle', { cx: x, cy: y, r: r, fill: fill ? 'currentColor' : undefined, stroke: fill ? 'none' : undefined }]; }
  var I = {
    inicio: [pth('M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8'), pth('M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z')],
    monitoreo: [pth('M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2')],
    lotes: [pth('M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z'), pth('M12 22V12'), pth('m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7'), pth('m7.5 4.27 9 5.15')],
    balanza: [pth('m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z'), pth('m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z'), pth('M7 21h10'), pth('M12 3v18'), pth('M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2')],
    ventilador: [pth('M10.827 16.379a6.082 6.082 0 0 1-8.618-7.002l5.412 1.45a6.082 6.082 0 0 1 7.002-8.618l-1.45 5.412a6.082 6.082 0 0 1 8.618 7.002l-5.412-1.45a6.082 6.082 0 0 1-7.002 8.618l1.45-5.412Z'), pth('M12 12v.01')],
    resistencia: [['rect', { x: 2.5, y: 6, width: 19, height: 13, rx: 2.5 }], pth('M6 15.5c1.2-1.4 1.2-3.6 0-5'), pth('M10 15.5c1.2-1.4 1.2-3.6 0-5'), pth('M14 15.5c1.2-1.4 1.2-3.6 0-5'), pth('M18 15.5c1.2-1.4 1.2-3.6 0-5'), pth('M6 19v2M18 19v2')],
    sensor: [pth('M4.9 19.1C1 15.2 1 8.8 4.9 4.9'), pth('M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5'), cir(12, 12, 2), pth('M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5'), pth('M19.1 4.9C23 8.8 23 15.1 19.1 19')],
    calibracion: [pth('M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z'), pth('m14.5 12.5 2-2'), pth('m11.5 9.5 2-2'), pth('m8.5 6.5 2-2'), pth('m17.5 15.5 2-2')],
    historial: [pth('M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8'), pth('M3 3v5h5'), pth('M12 7v5l4 2')],
    mapa: [pth('M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z'), pth('M15 5.764v15'), pth('M9 3.236v15')],
    alertas: [pth('M10.268 21a2 2 0 0 0 3.464 0'), pth('M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326')],
    config: [pth('M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z'), cir(12, 12, 3)],
    termometro: [pth('M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z'), pth('M12 8.5v7.5'), cir(12, 17.6, 1.7, true)],
    termometroTope: [pth('M11 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z'), pth('M9 8.5v7.5'), cir(9, 17.6, 1.7, true), pth('M18 10V3'), pth('m15 6 3-3 3 3')],
    gota: [pth('M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z')],
    gotas: [pth('M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z'), pth('M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97')],
    nube: [pth('M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z')],
    nubeSol: [pth('M12 2v2'), pth('m4.93 4.93 1.41 1.41'), pth('M20 12h2'), pth('m19.07 4.93-1.41 1.41'), pth('M15.947 12.65a4 4 0 0 0-5.925-4.128'), pth('M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z')],
    grano: [['g', { transform: 'rotate(38 12 12)' }, [['ellipse', { cx: 12, cy: 12, rx: 6.6, ry: 9.4 }], pth('M12.2 2.8c-2.6 3.1-2.6 6 0 9.2s2.6 6.1 0 9.2')]]],
    termometroGrano: [pth('M12 2.8c-2.6 3.1-2.6 6 0 9.2')],
    reloj: [cir(12, 12, 10), pth('M12 6v6l4 2')],
    sol: [cir(12, 12, 4), pth('M12 2v2'), pth('M12 20v2'), pth('m4.93 4.93 1.41 1.41'), pth('m17.66 17.66 1.41 1.41'), pth('M2 12h2'), pth('M20 12h2'), pth('m6.34 17.66-1.41 1.41'), pth('m19.07 4.93-1.41 1.41')],
    rayo: [pth('M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z')],
    potencia: [pth('m12 14 4-4'), pth('M3.34 19a10 10 0 1 1 17.32 0')],
    viento: [pth('M12.8 19.6A2 2 0 1 0 14 16H2'), pth('M17.5 8a2.5 2.5 0 1 1 2 4H2'), pth('M9.8 4.4A2 2 0 1 1 11 8H2')],
    moneda: [cir(12, 12, 10), pth('M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8'), pth('M12 18V6')],
    enchufe: [pth('M12 22v-5'), pth('M9 8V2'), pth('M15 8V2'), pth('M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8Z')],
    hoja: [pth('M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z'), pth('M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12')],
    ia: [pth('M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z'), pth('M20 3v4'), pth('M22 5h-4')],
    aviso: [pth('m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3'), pth('M12 9v4'), pth('M12 17h.01')],
    info: [cir(12, 12, 10), pth('M12 16v-4'), pth('M12 8h.01')],
    check: [pth('M20 6 9 17l-5-5')],
    checkCirculo: [cir(12, 12, 10), pth('m9 12 2 2 4-4')],
    pausa: [['rect', { x: 6, y: 4.5, width: 4, height: 15, rx: 1 }], ['rect', { x: 14, y: 4.5, width: 4, height: 15, rx: 1 }]],
    chevron: [pth('m9 18 6-6-6-6')],
    abajo: [pth('m6 9 6 6 6-6')],
    atras: [pth('m12 19-7-7 7-7'), pth('M19 12H5')],
    flechaArriba: [pth('m5 12 7-7 7 7'), pth('M12 19V5')],
    flechaAbajo: [pth('M12 5v14'), pth('m19 12-7 7-7-7')],
    pin: [pth('M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0'), cir(12, 10, 3)],
    ubicar: [pth('M2 12h3'), pth('M19 12h3'), pth('M12 2v3'), pth('M12 19v3'), cir(12, 12, 7), cir(12, 12, 3)],
    grafica: [pth('M3 3v16a2 2 0 0 0 2 2h16'), pth('m19 9-5 5-4-4-3 3')],
    usuario: [pth('M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2'), cir(12, 7, 4)],
    correo: [['rect', { x: 2, y: 4, width: 20, height: 16, rx: 2 }], pth('m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7')],
    candado: [['rect', { x: 3, y: 11, width: 18, height: 11, rx: 2 }], pth('M7 11V7a5 5 0 0 1 10 0v4')],
    ojo: [pth('M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0'), cir(12, 12, 3)],
    ojoNo: [pth('M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49'), pth('M14.084 14.158a3 3 0 0 1-4.242-4.242'), pth('M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143'), pth('m2 2 20 20')],
    huella: [pth('M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4'), pth('M14 13.12c0 2.38 0 6.38-1 8.88'), pth('M17.29 21.02c.12-.6.43-2.3.5-3.02'), pth('M2 12a10 10 0 0 1 18-6'), pth('M2 16h.01'), pth('M21.8 16c.2-2 .131-5.354 0-6'), pth('M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2'), pth('M8.65 22c.21-.66.45-1.32.57-2'), pth('M9 6.8a6 6 0 0 1 9 5.2v2')],
    mas: [pth('M5 12h14'), pth('M12 5v14')],
    menos: [pth('M5 12h14')],
    expandir: [pth('M15 3h6v6'), pth('M9 21H3v-6'), pth('M21 3l-7 7'), pth('M3 21l7-7')],
    salir: [pth('M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'), pth('m16 17 5-5-5-5'), pth('M21 12H9')],
    encendido: [pth('M12 2v10'), pth('M18.4 6.6a9 9 0 1 1-12.77.04')],
    buscar: [cir(11, 11, 8), pth('m21 21-4.3-4.3')],
    editar: [pth('M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z'), pth('m15 5 4 4')],
    borrar: [pth('M3 6h18'), pth('M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6'), pth('M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2')],
    descargar: [pth('M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'), pth('m7 10 5 5 5-5'), pth('M12 15V3')],
    camara: [pth('M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z'), cir(12, 13, 3)],
    actualizar: [pth('M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8'), pth('M21 3v5h-5'), pth('M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16'), pth('M8 16H3v5')],
    wifi: [pth('M12 20h.01'), pth('M2 8.82a15 15 0 0 1 20 0'), pth('M5 12.859a10 10 0 0 1 14 0'), pth('M8.5 16.429a5 5 0 0 1 7 0')],
    wifiNo: [pth('M12 20h.01'), pth('M8.5 16.429a5 5 0 0 1 7 0'), pth('M5 12.859a10 10 0 0 1 5.17-2.69'), pth('M19 12.859a10 10 0 0 0-2.007-1.523'), pth('M2 8.82a15 15 0 0 1 4.177-2.643'), pth('M22 8.82a15 15 0 0 0-11.288-3.764'), pth('m2 2 20 20')],
    menu: [pth('M4 6h16'), pth('M4 12h16'), pth('M4 18h16')],
    puntos: [cir(12, 5, 1.3, true), cir(12, 12, 1.3, true), cir(12, 19, 1.3, true)],
    reloj2: [cir(12, 12, 6), pth('M12 10v2l1 1'), pth('m16.13 7.66-.81-4.05a2 2 0 0 0-2-1.61h-2.68a2 2 0 0 0-2 1.61l-.78 4.05'), pth('m7.88 16.36.8 4a2 2 0 0 0 2 1.61h2.72a2 2 0 0 0 2-1.61l.81-4.05')],
    secador: [pth('M2.5 20h19'), pth('M4 20v-7a8 8 0 0 1 16 0v7'), pth('M4 14h16'), pth('M8 6.2V20'), pth('M16 6.2V20')],
    x: [pth('M18 6 6 18'), pth('m6 6 12 12')],
    bateria: [['rect', { x: 2, y: 7, width: 16, height: 10, rx: 2 }], pth('M22 11v2'), pth('M6 11v2'), pth('M10 11v2')],
    mano: [pth('M18 11V6a2 2 0 0 0-4 0v1'), pth('M14 10V4a2 2 0 0 0-4 0v2'), pth('M10 10.5V6a2 2 0 0 0-4 0v8'), pth('M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15')]
  };
  function renderEl(e, k) {
    var kids = e[2] ? e[2].map(renderEl) : undefined;
    return h(e[0], Object.assign({ key: k }, e[1]), kids);
  }
  function Icon(p) {
    var s = p.size || 20;
    var def = I[p.name] || I.hoja;
    return h('svg', { className: cx('sc-ic', p.className), width: s, height: s, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: p.stroke || 1.75, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': p.label ? undefined : true, role: p.label ? 'img' : undefined, 'aria-label': p.label },
      def.map(renderEl));
  }

  /* ---------------- brand ---------------- */
  function Logo(p) {
    var v = p.variant || 'full';
    var src = v === 'symbol' ? (p.inverse ? ASSETS.simboloClaro : ASSETS.simbolo) : v === 'wordmark' ? (p.inverse ? ASSETS.wordmarkClaro : ASSETS.wordmark) : (p.inverse ? ASSETS.logoClaro : ASSETS.logo);
    return h('img', { className: cx('sc-logo', 'sc-logo-' + v), src: p.src || src, alt: 'SISCAN · Secado Inteligente de Café', style: { height: p.height || (v === 'symbol' ? 40 : 48) } });
  }
  function CoffeeLeafArt(p) {
    return h('img', { className: cx('sc-leafart', p.className), src: p.dark ? ASSETS.granoHojas : ASSETS.granoHojasClaro, alt: '', 'aria-hidden': true, style: { width: p.width || 150 } });
  }

  /* ---------------- atoms ---------------- */
  function Button(p) {
    var v = p.variant || 'secondary';
    return h('button', { type: p.type || 'button', className: cx('sc-btn', 'sc-btn-' + v, p.size && 'sc-btn-' + p.size, p.block && 'sc-btn-block', p.className), disabled: p.disabled, onClick: p.onClick, 'aria-busy': p.busy || undefined },
      p.busy ? h('span', { className: 'sc-spinner', 'aria-hidden': true }) : p.icon ? h(Icon, { name: p.icon, size: 18 }) : null,
      p.children,
      p.trailing ? h(Icon, { name: p.trailing, size: 16 }) : null);
  }
  function IconButton(p) {
    return h('button', { type: 'button', className: cx('sc-iconbtn', p.variant && 'sc-iconbtn-' + p.variant), 'aria-label': p.label, title: p.label, onClick: p.onClick },
      h(Icon, { name: p.icon, size: p.size || 20 }),
      p.count ? h('span', { className: 'sc-count' }, p.count) : null);
  }
  var fid = 0;
  function useId(pref) { var r = React.useRef(null); if (!r.current) r.current = (pref || 'sc') + (++fid); return r.current; }
  function TextField(p) {
    var id = p.id || useId('f');
    var sh = React.useState(false), show = sh[0], setShow = sh[1];
    var isPw = p.type === 'password';
    return h('div', { className: cx('sc-field', p.error && 'sc-field-error', p.size === 'lg' && 'sc-field-lg') },
      p.label ? h('label', { className: 'sc-field-label', htmlFor: id }, p.label) : null,
      h('div', { className: 'sc-field-box' },
        p.icon ? h(Icon, { name: p.icon, size: 18 }) : null,
        h('input', { id: id, type: isPw && show ? 'text' : (p.type || 'text'), defaultValue: p.value, placeholder: p.placeholder, inputMode: p.inputMode, 'aria-invalid': p.error ? true : undefined, 'aria-describedby': (p.hint || p.error) ? id + 'h' : undefined }),
        p.suffix ? h('span', { className: 'sc-field-suffix' }, p.suffix) : null,
        isPw ? h('button', { type: 'button', className: 'sc-field-eye', 'aria-label': show ? 'Ocultar contraseña' : 'Mostrar contraseña', onClick: function () { setShow(!show); } }, h(Icon, { name: show ? 'ojoNo' : 'ojo', size: 18 })) : null),
      (p.hint || p.error) ? h('p', { className: 'sc-field-hint', id: id + 'h' }, p.error ? h(Icon, { name: 'aviso', size: 14 }) : null, p.error || p.hint) : null);
  }
  function Select(p) {
    var id = useId('s');
    return h('div', { className: 'sc-field' },
      p.label ? h('label', { className: 'sc-field-label', htmlFor: id }, p.label) : null,
      h('div', { className: 'sc-field-box sc-select' },
        p.icon ? h(Icon, { name: p.icon, size: 18 }) : null,
        h('select', { id: id, defaultValue: p.value }, (p.options || []).map(function (o) { return h('option', { key: o, value: o }, o); })),
        h(Icon, { name: 'abajo', size: 16 })));
  }
  function Switch(p) {
    var st = React.useState(!!p.checked), on = st[0], set = st[1];
    React.useEffect(function () { set(!!p.checked); }, [p.checked]);
    return h('label', { className: cx('sc-switch', p.disabled && 'sc-switch-off') },
      h('input', { type: 'checkbox', role: 'switch', checked: on, disabled: p.disabled, 'aria-label': p.label, onChange: function (e) { set(e.target.checked); if (p.onChange) p.onChange(e.target.checked); } }),
      h('span', { className: 'sc-switch-track', 'aria-hidden': true }, h('span', { className: 'sc-switch-thumb' }, on ? h(Icon, { name: 'check', size: 12, stroke: 3 }) : null)));
  }
  function Segmented(p) {
    var st = React.useState(p.value || p.options[0].id), v = st[0], set = st[1];
    return h('div', { className: cx('sc-seg', p.block && 'sc-seg-block'), role: 'radiogroup', 'aria-label': p.label },
      p.options.map(function (o) {
        var on = o.id === v;
        return h('button', { key: o.id, type: 'button', role: 'radio', 'aria-checked': on, className: cx('sc-seg-opt', on && 'sc-seg-on'), onClick: function () { set(o.id); if (p.onChange) p.onChange(o.id); } },
          o.icon ? h(Icon, { name: o.icon, size: 16 }) : null, o.label);
      }));
  }
  function Checkbox(p) {
    return h('label', { className: 'sc-check' }, h('input', { type: 'checkbox', defaultChecked: p.checked }), h('span', { className: 'sc-check-box', 'aria-hidden': true }, h(Icon, { name: 'check', size: 13, stroke: 3 })), h('span', null, p.label));
  }
  var STATES = {
    running: { label: 'En operación', icon: null },
    paused: { label: 'En pausa', icon: 'pausa' },
    alert: { label: 'Alerta', icon: 'aviso' },
    offline: { label: 'Sin conexión', icon: 'wifiNo' }
  };
  function StatusPill(p) {
    var s = p.state || 'running', m = STATES[s];
    return h('span', { className: cx('sc-pill', 'sc-st-' + s, p.size === 'sm' && 'sc-pill-sm') },
      m.icon ? h(Icon, { name: m.icon, size: 13, stroke: 2.2 }) : h('span', { className: cx('sc-pill-dot', s === 'running' && p.live && 'sc-live') }),
      p.children || m.label);
  }
  function Chip(p) {
    return h('span', { className: cx('sc-chip', 'sc-chip-' + (p.tone || 'brote')) }, p.icon ? h(Icon, { name: p.icon, size: 14 }) : null, p.children);
  }
  function LiveDot(p) {
    return h('span', { className: cx('sc-livetag', p.off && 'sc-livetag-off', p.onLight && 'sc-livetag-light') }, h('span', { className: cx('sc-livedot', !p.off && 'sc-live') }), p.off ? (p.label || 'Sin conexión') : (p.label || 'En vivo'));
  }
  function Avatar(p) {
    var ini = (p.name || 'A').split(' ').map(function (w) { return w[0]; }).slice(0, 2).join('');
    return h('span', { className: 'sc-avatar', role: 'img', 'aria-label': p.name }, ini);
  }
  function ProgressBar(p) {
    var pct = Math.max(0, Math.min(100, p.value));
    return h('div', { className: 'sc-progress', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': Math.round(pct), 'aria-label': p.label },
      h('span', { style: { width: pct + '%' } }));
  }
  function Toast(p) {
    return h('div', { className: cx('sc-toast', 'sc-toast-' + (p.tone || 'ok')), role: 'status' },
      h('span', { className: 'sc-toast-ic' }, h(Icon, { name: p.tone === 'alert' ? 'aviso' : 'check', size: 16, stroke: 2.4 })),
      h('div', null, h('strong', null, p.title), p.children ? h('span', null, p.children) : null),
      p.action ? h('button', { type: 'button', className: 'sc-toast-act' }, p.action) : null);
  }
  function CardTitle(p) {
    return h('header', { className: 'sc-ctitle' },
      h('span', { className: 'sc-ctitle-ic' }, h(Icon, { name: p.icon, size: 18 })), h('h3', null, p.title),
      p.right || (p.link ? h('a', { className: 'sc-link', href: '#', onClick: function (e) { e.preventDefault(); } }, p.link, h(Icon, { name: 'chevron', size: 14 })) : null));
  }

  /* ---------------- data viz ---------------- */
  function pts(data, w, hh, pad, min, max) {
    var n = data.length; if (min == null) min = Math.min.apply(null, data); if (max == null) max = Math.max.apply(null, data);
    var rng = max - min || 1;
    return data.map(function (v, i) { return [pad + (i / (n - 1)) * (w - 2 * pad), pad + (1 - (v - min) / rng) * (hh - 2 * pad)]; });
  }
  function smooth(p) {
    var d = 'M' + p[0][0].toFixed(1) + ' ' + p[0][1].toFixed(1);
    for (var i = 1; i < p.length; i++) {
      var a = p[i - 1], b = p[i], mx = (a[0] + b[0]) / 2;
      d += ' C' + mx.toFixed(1) + ' ' + a[1].toFixed(1) + ' ' + mx.toFixed(1) + ' ' + b[1].toFixed(1) + ' ' + b[0].toFixed(1) + ' ' + b[1].toFixed(1);
    }
    return d;
  }
  var gid = 0;
  function useGid(p) { var r = React.useRef(null); if (!r.current) r.current = (p || 'g') + (++gid); return r.current; }

  function Sparkline(p) {
    var id = useGid('sp');
    var data = p.data || [], w = 200, hh = 44;
    var q = pts(data, w, hh, 3), line = smooth(q);
    var area = line + ' L' + q[q.length - 1][0] + ' ' + hh + ' L' + q[0][0] + ' ' + hh + ' Z';
    var last = q[q.length - 1];
    return h('div', { className: cx('sc-spark', 'sc-c-' + (p.tone || 'humedad')) },
      h('svg', { viewBox: '0 0 ' + w + ' ' + hh, preserveAspectRatio: 'none', 'aria-hidden': true },
        h('defs', null, h('linearGradient', { id: id, x1: 0, y1: 0, x2: 0, y2: 1 }, h('stop', { offset: '0', className: 'sc-stop-a' }), h('stop', { offset: '1', className: 'sc-stop-b' }))),
        h('path', { d: area, fill: 'url(#' + id + ')' }),
        h('path', { d: line, className: 'sc-spark-line sc-draw', pathLength: 1, vectorEffect: 'non-scaling-stroke' })),
      h('span', { className: cx('sc-spark-dot', p.live && 'sc-live'), style: { left: (last[0] / w * 100) + '%', top: (last[1] / hh * 100) + '%' } }));
  }

  var MAG = {
    temperatura: { icon: 'termometro' }, tope: { icon: 'termometroTope' }, exterior: { icon: 'nubeSol' },
    humedad: { icon: 'gotas' }, grano: { icon: 'grano' }, tiempo: { icon: 'reloj' }, potencia: { icon: 'potencia' }, corriente: { icon: 'rayo' }, solar: { icon: 'sol' }
  };
  function MetricCard(p) {
    var d = p.delta, tone = p.tone || 'humedad';
    var good = p.goodWhen === 'down' ? d < 0 : p.goodWhen === 'up' ? d > 0 : null;
    return h('article', { className: cx('sc-card', 'sc-metric', p.compact && 'sc-metric-compact') },
      h('header', { className: 'sc-metric-head' },
        h('span', { className: cx('sc-metric-ic', 'sc-c-' + tone) }, h(Icon, { name: p.icon || (MAG[tone] || {}).icon || 'gota', size: 18 })),
        h('span', { className: 'sc-metric-name' }, p.label),
        p.action ? h(Icon, { name: 'chevron', size: 16, className: 'sc-metric-go' }) : null),
      h('div', { className: 'sc-metric-value', 'aria-live': 'polite' },
        h('span', { className: 'sc-read', key: String(p.value) + (p.text || '') }, p.text || num(p.value, p.decimals)),
        p.unit ? h('span', { className: 'sc-unit' }, p.unit) : null),
      d != null ? h('p', { className: cx('sc-delta', good === true && 'sc-delta-good', good === false && 'sc-delta-bad') },
        h(Icon, { name: d >= 0 ? 'flechaArriba' : 'flechaAbajo', size: 13, stroke: 2.2 }), signed(d, p.decimals) + (p.unit ? ' ' + p.unit : ''), h('span', null, ' · última hora')) : null,
      p.sub ? h('p', { className: 'sc-metric-sub' }, p.sub) : null,
      p.progress != null ? h(ProgressBar, { value: p.progress, label: p.label }) : null,
      p.data ? h(Sparkline, { data: p.data, tone: tone, live: p.live }) : null);
  }

  function RingGauge(p) {
    var size = p.size || 132, sw = p.stroke || Math.max(8, Math.round(size / 11)), r = (size - sw) / 2;
    var pct = Math.max(0, Math.min(100, p.value));
    var id = useGid('rg');
    return h('div', { className: cx('sc-ring', 'sc-c-' + (p.tone || 'grano'), p.className), style: { width: size, height: size } },
      h('svg', { width: size, height: size, viewBox: '0 0 ' + size + ' ' + size, 'aria-hidden': true },
        h('defs', null, h('linearGradient', { id: id, x1: 0, y1: 0, x2: 1, y2: 1 }, h('stop', { offset: '0', className: 'sc-ring-s1' }), h('stop', { offset: '1', className: 'sc-ring-s2' }))),
        h('circle', { cx: size / 2, cy: size / 2, r: r, className: 'sc-ring-track', strokeWidth: sw, fill: 'none' }),
        p.band ? h('circle', { cx: size / 2, cy: size / 2, r: r, className: 'sc-ring-band', strokeWidth: sw, fill: 'none', pathLength: 100, strokeDasharray: (p.band[1] - p.band[0]) + ' 100', strokeDashoffset: -p.band[0], transform: 'rotate(-90 ' + size / 2 + ' ' + size / 2 + ')' }) : null,
        h('circle', { cx: size / 2, cy: size / 2, r: r, className: 'sc-ring-fill sc-fill', stroke: p.gradient ? 'url(#' + id + ')' : undefined, strokeWidth: sw, fill: 'none', pathLength: 100, strokeDasharray: '100 100', strokeDashoffset: 100 - pct, strokeLinecap: 'round', transform: 'rotate(-90 ' + size / 2 + ' ' + size / 2 + ')' })),
      h('div', { className: 'sc-ring-in' },
        h('span', { className: 'sc-ring-val', key: p.text || String(p.value), style: { fontSize: Math.max(16, Math.round(size / 5.4)) + 'px' } }, p.text || num(p.value) + ' %'),
        p.label ? h('span', { className: 'sc-ring-label', style: { maxWidth: (size - 2 * sw - 14) + 'px' } }, p.label) : null));
  }

  function MoistureChart(p) {
    var id = useGid('mc');
    var data = p.data || [], pred = p.prediction || [];
    var labels = p.labels || data.map(function (_, i) { return 'Día ' + i; });
    var all = data.length + pred.length;
    var W = p.width || 640, H = p.height || 260, L = 46, R = 22, T = 26, B = 34;
    var max = p.max || 55, min = 0;
    function X(i) { return L + (i / (all - 1)) * (W - L - R); }
    function Y(v) { return T + (1 - (v - min) / (max - min)) * (H - T - B); }
    var q = data.map(function (v, i) { return [X(i), Y(v)]; });
    var line = smooth(q);
    var area = line + ' L' + q[q.length - 1][0] + ' ' + Y(0) + ' L' + q[0][0] + ' ' + Y(0) + ' Z';
    var pq = pred.length ? [q[q.length - 1]].concat(pred.map(function (v, i) { return [X(data.length + i), Y(v)]; })) : null;
    var ticks = []; for (var t = 0; t <= max; t += (max > 30 ? 10 : 5)) ticks.push(t);
    var last = q[q.length - 1], lv = data[data.length - 1];
    var t0 = p.target || [10, 12];
    return h('figure', { className: 'sc-chart sc-c-grano', 'aria-label': p.summary || ('La humedad del grano bajó de ' + num(data[0]) + ' % a ' + num(lv) + ' %; objetivo ' + t0[0] + ' – ' + t0[1] + ' %.') },
      h('svg', { viewBox: '0 0 ' + W + ' ' + H, role: 'img' },
        h('defs', null, h('linearGradient', { id: id, x1: 0, y1: 0, x2: 0, y2: 1 }, h('stop', { offset: '0', className: 'sc-stop-a' }), h('stop', { offset: '1', className: 'sc-stop-b' }))),
        ticks.map(function (tk) { return h(F, { key: tk }, h('line', { x1: L, x2: W - R, y1: Y(tk), y2: Y(tk), className: 'sc-grid' }), h('text', { x: L - 10, y: Y(tk) + 4, className: 'sc-axis', textAnchor: 'end' }, tk + ' %')); }),
        h('rect', { x: L, width: W - L - R, y: Y(t0[1]), height: Y(t0[0]) - Y(t0[1]), className: 'sc-target-band' }),
        h('line', { x1: L, x2: W - R, y1: Y(t0[1]), y2: Y(t0[1]), className: 'sc-target-line' }),
        h('text', { x: W - R, y: Y(t0[1]) - 6, textAnchor: 'end', className: 'sc-target-txt' }, 'Objetivo ' + t0[0] + ' – ' + t0[1] + ' %'),
        h('path', { d: area, fill: 'url(#' + id + ')' }),
        h('path', { d: line, className: 'sc-chart-line sc-draw', pathLength: 1 }),
        pq ? h('path', { d: smooth(pq), className: 'sc-chart-pred' }) : null,
        pq ? h('circle', { cx: pq[pq.length - 1][0], cy: pq[pq.length - 1][1], r: 4.5, className: 'sc-chart-predpt' }) : null,
        q.map(function (c, i) { var isLast = i === q.length - 1; return h('circle', { key: i, cx: c[0], cy: c[1], r: isLast ? 6 : 3.6, className: cx('sc-chart-pt', isLast && 'sc-chart-last', isLast && p.live && 'sc-live-svg') }); }),
        labels.map(function (l, i) { return l ? h('text', { key: i, x: X(i), y: H - 10, className: 'sc-axis', textAnchor: 'middle' }, l) : null; }),
        h('g', { transform: 'translate(' + Math.min(last[0], W - R - 34) + ' ' + Math.max(18, last[1] - 30) + ')' },
          h('rect', { x: -32, y: -14, width: 64, height: 26, rx: 8, className: 'sc-chart-tag' }),
          h('text', { x: 0, y: 4, textAnchor: 'middle', className: 'sc-chart-tagtxt' }, num(lv) + ' %'))),
      p.legend === false ? null : h('figcaption', { className: 'sc-legend-inline sc-chart-legend' },
        h('span', null, h('i', { className: 'sc-sw sc-sw-grano' }), 'Humedad del grano (gravimétrico)'),
        pred.length ? h('span', null, h('i', { className: 'sc-sw sc-sw-pred' }), 'Predicción IA') : null,
        h('span', null, h('i', { className: 'sc-sw sc-sw-obj' }), 'Objetivo')));
  }

  function EnergyCard(p) {
    var bars = p.bars || [];
    var max = Math.max.apply(null, bars.map(function (b) { return b.solar + b.grid; })) || 1;
    return h('article', { className: 'sc-card sc-energy' },
      h(CardTitle, { icon: 'rayo', title: p.title || 'Consumo energético y costo', right: p.right }),
      h('div', { className: 'sc-energy-stats' },
        h('div', { className: 'sc-stat sc-stat-solar' }, h('span', { className: 'sc-stat-k' }, h(Icon, { name: 'sol', size: 16 }), 'Solar'), h('span', { className: 'sc-stat-v' }, num(p.solar), h('small', null, ' kWh'))),
        h('div', { className: 'sc-stat sc-stat-grid' }, h('span', { className: 'sc-stat-k' }, h(Icon, { name: 'enchufe', size: 16 }), 'Red eléctrica'), h('span', { className: 'sc-stat-v' }, num(p.grid), h('small', null, ' kWh'))),
        h('div', { className: 'sc-stat' }, h('span', { className: 'sc-stat-k' }, h(Icon, { name: 'moneda', size: 16 }), 'Costo hoy'), h('span', { className: 'sc-stat-v' }, money(p.cost), h('small', null, ' COP')))),
      h('div', { className: 'sc-bars', role: 'img', 'aria-label': 'Energía por hora: solar abajo, red eléctrica arriba' },
        bars.map(function (b, i) {
          return h('div', { key: i, className: 'sc-bar' },
            h('div', { className: 'sc-bar-col' },
              b.grid ? h('span', { className: 'sc-bar-grid sc-grow', style: { height: (b.grid / max * 100) + '%' } }) : null,
              h('span', { className: 'sc-bar-solar sc-grow', style: { height: (b.solar / max * 100) + '%' } })),
            h('span', { className: 'sc-bar-l' }, b.label));
        })),
      h('div', { className: 'sc-legend-inline' }, h('span', null, h('i', { className: 'sc-sw sc-sw-solar' }), 'Solar'), h('span', null, h('i', { className: 'sc-sw sc-sw-grid' }), 'Red eléctrica'), p.tariff ? h('span', { className: 'sc-legend-note' }, 'Tarifa ' + money(p.tariff) + '/kWh') : null));
  }

  function ActuatorEnergy(p) {
    var rows = p.rows || [], max = Math.max.apply(null, rows.map(function (r) { return r.kwh; })) || 1;
    var total = rows.reduce(function (a, r) { return a + r.kwh; }, 0);
    return h('article', { className: 'sc-card' },
      h(CardTitle, { icon: 'potencia', title: 'Energía por actuador · 24 h' }),
      h('ul', { className: 'sc-hbars' }, rows.map(function (r) {
        return h('li', { key: r.name },
          h('span', { className: 'sc-hbar-name' }, h(Icon, { name: r.icon, size: 16 }), r.name),
          h('span', { className: 'sc-hbar-track' }, h('span', { className: 'sc-hbar-fill sc-grow-x', style: { width: (r.kwh / max * 100) + '%' } })),
          h('span', { className: 'sc-hbar-v' }, num(r.kwh) + ' kWh'));
      })),
      h('p', { className: 'sc-foot' }, 'Total ', h('strong', null, num(total) + ' kWh'), ' · costo ', h('strong', null, money(total * (p.tariff || 780))), ' · estimado con la potencia nominal y las horas de relé cerrado'));
  }

  function PredictionCard(p) {
    return h('article', { className: cx('sc-card', 'sc-pred', p.compact && 'sc-pred-compact') },
      h(CardTitle, { icon: 'ia', title: 'Predicción de IA', right: h('span', { className: 'sc-chip sc-chip-pred' }, 'Confianza ' + (p.confidence >= 75 ? 'alta' : p.confidence >= 50 ? 'media' : 'baja')) }),
      h('p', { className: 'sc-pred-k' }, 'Tiempo restante estimado'),
      h('p', { className: 'sc-pred-v' }, h('span', { className: 'sc-read', key: p.remaining }, p.remaining)),
      h('p', { className: 'sc-pred-range' }, 'Entre ', h('strong', null, p.min), ' y ', h('strong', null, p.max), ' · listo cerca de las ', h('strong', null, p.eta)),
      h('div', { className: 'sc-pred-conf' }, h('span', null, 'Confianza de la predicción'), h('b', null, p.confidence + ' %')),
      h('div', { className: 'sc-progress sc-progress-pred' }, h('span', { style: { width: p.confidence + '%' } })),
      p.compact ? null : h('div', { className: 'sc-pred-inputs' }, h('span', { className: 'sc-pred-k' }, 'Datos considerados'),
        h('div', { className: 'sc-row' }, (p.inputs || []).map(function (x) { return h(Chip, { key: x.label, tone: 'neutral', icon: x.icon }, x.label); }))));
  }

  var PHASES = [['inicio', 'Inicio'], ['calentamiento', 'Calentamiento'], ['secado', 'Secado activo'], ['reduccion', 'Reducción de humedad'], ['ajustes', 'Ajustes'], ['final', 'Finalización']];
  function ProcessTimeline(p) {
    var idx = PHASES.findIndex(function (x) { return x[0] === p.phase; });
    var times = p.times || [];
    return h('ol', { className: cx('sc-phases', p.compact && 'sc-phases-compact', p.vertical && 'sc-phases-v'), 'aria-label': 'Proceso del lote' },
      PHASES.map(function (x, i) {
        var st = i < idx ? 'done' : i === idx ? 'now' : 'next';
        return h('li', { key: x[0], className: 'sc-phase sc-phase-' + st, 'aria-current': st === 'now' ? 'step' : undefined },
          h('span', { className: 'sc-phase-dot' }, st === 'done' ? h(Icon, { name: 'check', size: 12, stroke: 3 }) : st === 'now' ? h('i', { className: 'sc-live-core' }) : null),
          h('span', { className: 'sc-phase-text' }, h('span', { className: 'sc-phase-l' }, x[1]), times[i] ? h('span', { className: 'sc-phase-t' }, st === 'now' ? 'En curso · ' + times[i] : times[i]) : (st === 'next' && !p.compact ? h('span', { className: 'sc-phase-t' }, 'Pendiente') : null)));
      }));
  }

  function MoistureScale(p) {
    var v = p.value, lo = 6, hi = 56;
    function pos(x) { return Math.max(0, Math.min(100, (1 - (x - lo) / (hi - lo)) * 100)); }
    var zone = v > 30 ? 'Húmedo' : v > 20 ? 'Oreado' : v > 12 ? 'Secando' : v >= 10 ? 'Objetivo alcanzado' : 'Sobresecado';
    return h('div', { className: 'sc-mscale' },
      h('div', { className: 'sc-mscale-bar' },
        h('span', { className: 'sc-mscale-target', style: { left: pos(12) + '%', width: (pos(10) - pos(12)) + '%' } }),
        h('span', { className: 'sc-mscale-mark', style: { left: pos(v) + '%' } }, h('b', null, num(v) + ' %'))),
      h('div', { className: 'sc-mscale-l' }, h('span', null, 'Húmedo 53 %'), h('span', null, 'Oreado'), h('span', null, 'Secando'), h('span', { className: 'sc-mscale-ok' }, '10 – 12 %')),
      h('p', { className: 'sc-mscale-zone' }, 'Zona actual: ', h('strong', null, zone)));
  }

  function ConditionsTable(p) {
    return h('div', { className: 'sc-card sc-table-wrap' },
      h('div', { className: 'sc-table-head' }, h(CardTitle, { icon: 'grafica', title: p.title || 'Condiciones durante el lote' })),
      h('table', { className: 'sc-table' },
        h('thead', null, h('tr', null, ['Variable', 'Mínimo', 'Promedio', 'Máximo'].map(function (c, i) { return h('th', { key: c, className: i ? 'sc-num' : null }, c); }))),
        h('tbody', null, (p.rows || []).map(function (r) {
          return h('tr', { key: r.name }, h('td', null, h('span', { className: 'sc-td-ic sc-c-' + r.tone }, h(Icon, { name: r.icon, size: 16 })), r.name),
            h('td', { className: 'sc-num' }, r.min), h('td', { className: 'sc-num' }, h('strong', null, r.avg)), h('td', { className: 'sc-num' }, r.max));
        }))));
  }

  function WeatherCard(p) {
    return h('article', { className: 'sc-card sc-weathercard' },
      h('div', { className: 'sc-wc-main' }, h(Icon, { name: 'nubeSol', size: 40 }),
        h('div', null, h('span', { className: 'sc-wc-temp' }, num(p.temp, 0) + ' °C'), h('span', { className: 'sc-wc-sky' }, p.sky || 'Parcialmente nublado'))),
      h('dl', { className: 'sc-wc-dl' },
        h('div', null, h('dt', null, 'Humedad'), h('dd', null, num(p.hr, 0) + ' %')),
        h('div', null, h('dt', null, 'Radiación'), h('dd', null, num(p.rad, 0) + ' W/m²')),
        h('div', null, h('dt', null, 'Lluvia'), h('dd', null, p.rain || '10 %'))),
      h('p', { className: 'sc-foot' }, 'Clima en la finca ahora · ' + (p.place || 'Chachagüí, Nariño') + ' · Open-Meteo'));
  }

  function WeatherChip(p) {
    return h('div', { className: 'sc-weather' },
      h(Icon, { name: 'nubeSol', size: 26 }),
      h('div', null, h('span', { className: 'sc-weather-place' }, p.place || 'Chachagüí, Nariño'), h('span', { className: 'sc-weather-meta' }, num(p.temp, 0) + ' °C · ' + (p.sky || 'Parcialmente nublado'))));
  }

  /* ---------------- illustration: Nariño coffee hillside with the hybrid solar dryer ---------------- */
  var PAL = {
    day: { sky: ['#bfe0da', '#e6f1e2', '#fbf0d4'], sun: '#ffd25e', glow: 'rgba(255,212,110,0.55)', far1: '#c6ddcd', far2: '#a5c9a4', far3: '#82b276', fog: 'rgba(250,246,230,0.75)', hill: ['#77ad5c', '#5f9649'], bush: '#2c6a34', bushMid: '#3c8540', bushHi: '#78b35e', cherry: '#c43f2c', cherryHi: '#f07b5e', ground: ['#649b4b', '#4c8239'], tuft: '#3f7432', path: '#ecdfbd', pathEdge: '#d4c196', wood: '#80573a', woodDark: '#5c3c26', frame: '#eef4ef', frameShade: '#a4b8aa', dome: ['rgba(255,255,255,0.62)', 'rgba(232,244,236,0.22)'], interior: 'rgba(36,82,52,0.20)', bean: '#d9b77e', beanDark: '#b58b56', house: '#f5eee1', houseShade: '#e2d6c1', roof: '#bd5a31', roofDark: '#93421f', win: '#5f7469', cloud: '#ffffff', tree: '#2e6a35', treeHi: '#5c9c4c', trunk: '#6b4a2f', panel: '#28507c', panelLine: '#9cc0e3', box: '#eef1ef', led: '#3ccf6e', bird: '#36574a', heat: 'rgba(255,170,90,0)' },
    dusk: { sky: ['#e9a77f', '#f6c99c', '#fde6c0'], sun: '#ff8f4d', glow: 'rgba(255,140,80,0.5)', far1: '#d4b8a8', far2: '#b5ab8e', far3: '#8e9c6b', fog: 'rgba(253,226,196,0.7)', hill: ['#7a9a52', '#5e8442'], bush: '#2a5a30', bushMid: '#3a7339', bushHi: '#8aa85a', cherry: '#b8402c', cherryHi: '#e06d4f', ground: ['#5f8a43', '#4a7335'], tuft: '#3c6630', path: '#e9d1ad', pathEdge: '#cdb28a', wood: '#7a5236', woodDark: '#573823', frame: '#f6ece2', frameShade: '#b9a898', dome: ['rgba(255,240,225,0.6)', 'rgba(255,220,190,0.2)'], interior: 'rgba(80,60,40,0.2)', bean: '#d9b77e', beanDark: '#b58b56', house: '#f4e6d4', houseShade: '#dfc9ae', roof: '#b4532d', roofDark: '#8a3c1c', win: '#ffcf7a', cloud: '#fff1e2', tree: '#2c5a31', treeHi: '#6b8f4c', trunk: '#5f4129', panel: '#2b4566', panelLine: '#e3b28b', box: '#f1ebe4', led: '#3ccf6e', bird: '#5a4636', heat: 'rgba(255,150,70,0.45)' },
    night: { sky: ['#071510', '#0f261b', '#1d3a2d'], sun: '#f4f0e2', glow: 'rgba(230,240,220,0.18)', far1: '#173226', far2: '#1b3a2a', far3: '#21452f', fog: 'rgba(40,70,55,0.5)', hill: ['#1f4329', '#173520'], bush: '#0f2b17', bushMid: '#163a20', bushHi: '#2c5a35', cherry: '#7a2c22', cherryHi: '#a8463a', ground: ['#173520', '#10291a'], tuft: '#0e2516', path: '#3e4f3f', pathEdge: '#334334', wood: '#4a3424', woodDark: '#33231a', frame: '#c4d3c8', frameShade: '#6f857a', dome: ['rgba(255,226,180,0.30)', 'rgba(255,200,140,0.10)'], interior: 'rgba(255,170,90,0.10)', bean: '#c9a26b', beanDark: '#9b7448', house: '#bdb5a5', houseShade: '#9c9483', roof: '#6e3a24', roofDark: '#552c1b', win: '#ffd27a', cloud: 'rgba(255,255,255,0.06)', tree: '#0f2a17', treeHi: '#1f4428', trunk: '#3a2a1c', panel: '#1b2d44', panelLine: '#3d5878', box: '#b9c2bc', led: '#3ccf6e', bird: 'none', heat: 'rgba(255,165,80,0.75)' }
  };
  function rng(seed) { var s = seed; return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
  function Bush(c, x, y, s, k) {
    return h('g', { key: k },
      h('ellipse', { cx: x, cy: y + 1, rx: 15 * s, ry: 3.6 * s, fill: 'rgba(0,0,0,0.16)' }),
      h('ellipse', { cx: x - 7 * s, cy: y - 7 * s, rx: 10 * s, ry: 8.5 * s, fill: c.bush }),
      h('ellipse', { cx: x + 7.5 * s, cy: y - 8 * s, rx: 10 * s, ry: 9.5 * s, fill: c.bush }),
      h('ellipse', { cx: x, cy: y - 15 * s, rx: 9.5 * s, ry: 9 * s, fill: c.bushMid }),
      h('ellipse', { cx: x - 3.5 * s, cy: y - 19 * s, rx: 5.2 * s, ry: 3.4 * s, fill: c.bushHi, opacity: 0.9 }),
      h('ellipse', { cx: x + 8 * s, cy: y - 12 * s, rx: 3.6 * s, ry: 2.4 * s, fill: c.bushHi, opacity: 0.6 }),
      h('circle', { cx: x - 5 * s, cy: y - 5 * s, r: 2.2 * s, fill: c.cherry }),
      h('circle', { cx: x + 6 * s, cy: y - 3.5 * s, r: 2.1 * s, fill: c.cherry }),
      h('circle', { cx: x + 1.5 * s, cy: y - 9.5 * s, r: 2 * s, fill: c.cherry }),
      h('circle', { cx: x - 5.6 * s, cy: y - 5.7 * s, r: 0.8 * s, fill: c.cherryHi }));
  }
  function Landscape(p) {
    var v = p.variant || 'day', c = PAL[v];
    var id = useGid('ls');
    var air = p.airflow == null ? v !== 'night' : p.airflow;
    var heat = v !== 'day' || p.heater;
    var R = rng(7);
    var rows = [];
    for (var r = 0; r < 4; r++) {
      var s = 0.6 + r * 0.2, y0 = 392 + r * 30, step = 31 * s + 16;
      rows.push(h('path', { key: 'row' + r, d: 'M-410 ' + (y0 + 2) + ' C300 ' + (y0 - 6) + ' 700 ' + (y0 + 10) + ' 1610 ' + (y0 - 2), fill: 'none', stroke: c.hill[1], strokeWidth: 6 * s, strokeLinecap: 'round', opacity: 0.7 }));
      for (var x = -400 + (r % 2) * step / 2; x < 1620; x += step) {
        var y = y0 + Math.sin(x / 170 + r) * 4;
        rows.push(Bush(c, x + (R() - 0.5) * 6, y, s * (0.9 + R() * 0.2), 'b' + r + '-' + Math.round(x)));
      }
    }
    var beans = [];
    for (var b = 0; b < 70; b++) { var bx = 20 + b * 5.9; beans.push(h('ellipse', { key: 'k' + b, cx: bx, cy: 76 - Math.sin(b / 70 * Math.PI) * 6 + (b % 3), rx: 3.4, ry: 2.1, fill: b % 4 ? c.bean : c.beanDark, transform: 'rotate(' + ((b * 37) % 60 - 30) + ' ' + bx + ' 76)' })); }
    var beans2 = [];
    for (var b2 = 0; b2 < 70; b2++) { var bx2 = 20 + b2 * 5.9; beans2.push(h('ellipse', { key: 'm' + b2, cx: bx2, cy: 99 - Math.sin(b2 / 70 * Math.PI) * 5 + (b2 % 2), rx: 3.4, ry: 2.1, fill: b2 % 5 ? c.bean : c.beanDark, transform: 'rotate(' + ((b2 * 53) % 60 - 30) + ' ' + bx2 + ' 99)' })); }
    var tufts = [];
    for (var t = 0; t < 34; t++) { var tx = R() * 2000 - 400, ty = 480 + R() * 110; tufts.push(h('path', { key: 't' + t, d: 'M' + tx.toFixed(0) + ' ' + ty.toFixed(0) + 'l3 -11 l3 11 l3 -8 l2.5 8', fill: 'none', stroke: c.tuft, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' })); }
    var stars = v === 'night' ? [[80, 50], [160, 120], [250, 40], [330, 90], [430, 30], [520, 70], [610, 45], [700, 110], [780, 35], [860, 80], [960, 50], [1040, 100], [1120, 40], [1170, 140], [380, 150], [900, 160]].map(function (q, i) { return h('circle', { key: 's' + i, cx: q[0], cy: q[1], r: i % 4 ? 1.4 : 2.2, fill: '#f4f0e2', opacity: i % 3 ? 0.6 : 0.95 }); }) : null;
    var sunX = v === 'dusk' ? 960 : 930, sunY = v === 'dusk' ? 215 : v === 'night' ? 95 : 105;
    var view = p.view || '0 0 1200 600';
    return h('svg', { className: cx('sc-land', 'sc-land-' + v), viewBox: view, preserveAspectRatio: p.fit || 'xMidYMid slice', 'aria-hidden': true },
      h('defs', null,
        h('linearGradient', { id: id + 'sky', x1: 0, y1: 0, x2: 0, y2: 1 }, h('stop', { offset: '0', stopColor: c.sky[0] }), h('stop', { offset: '0.55', stopColor: c.sky[1] }), h('stop', { offset: '1', stopColor: c.sky[2] })),
        h('radialGradient', { id: id + 'sun' }, h('stop', { offset: '0', stopColor: c.glow }), h('stop', { offset: '1', stopColor: c.glow, stopOpacity: 0 })),
        h('linearGradient', { id: id + 'fog', x1: 0, y1: 0, x2: 0, y2: 1 }, h('stop', { offset: '0', stopColor: c.fog, stopOpacity: 0 }), h('stop', { offset: '0.6', stopColor: c.fog }), h('stop', { offset: '1', stopColor: c.fog, stopOpacity: 0 })),
        h('linearGradient', { id: id + 'hill', x1: 0, y1: 0, x2: 0, y2: 1 }, h('stop', { offset: '0', stopColor: c.hill[0] }), h('stop', { offset: '1', stopColor: c.hill[1] })),
        h('linearGradient', { id: id + 'gr', x1: 0, y1: 0, x2: 0, y2: 1 }, h('stop', { offset: '0', stopColor: c.ground[0] }), h('stop', { offset: '1', stopColor: c.ground[1] })),
        h('linearGradient', { id: id + 'dome', x1: 0, y1: 0, x2: 0, y2: 1 }, h('stop', { offset: '0', stopColor: c.dome[0] }), h('stop', { offset: '1', stopColor: c.dome[1] })),
        h('radialGradient', { id: id + 'heat' }, h('stop', { offset: '0', stopColor: '#ffb15c', stopOpacity: 0.85 }), h('stop', { offset: '1', stopColor: '#ffb15c', stopOpacity: 0 }))),
      h('rect', { x: -400, width: 2000, height: 600, fill: 'url(#' + id + 'sky)' }),
      stars,
      h('circle', { cx: sunX, cy: sunY, r: 140, fill: 'url(#' + id + 'sun)' }),
      h('circle', { cx: sunX, cy: sunY, r: v === 'night' ? 30 : 46, fill: c.sun }),
      v === 'night' ? h('circle', { cx: sunX + 12, cy: sunY - 8, r: 26, fill: c.sky[0] }) : null,
      h('g', { fill: c.cloud, opacity: v === 'night' ? 1 : 0.92 },
        h('ellipse', { cx: 210, cy: 120, rx: 70, ry: 18 }), h('ellipse', { cx: 180, cy: 108, rx: 34, ry: 22 }), h('ellipse', { cx: 232, cy: 102, rx: 42, ry: 28 }),
        h('ellipse', { cx: 690, cy: 80, rx: 54, ry: 13 }), h('ellipse', { cx: 672, cy: 70, rx: 26, ry: 16 }), h('ellipse', { cx: 706, cy: 66, rx: 30, ry: 20 }),
        h('ellipse', { cx: 1090, cy: 175, rx: 60, ry: 14 }), h('ellipse', { cx: 1110, cy: 163, rx: 32, ry: 20 })),
      v === 'day' && p.birds !== false ? h('g', { fill: 'none', stroke: c.bird, strokeWidth: 2, strokeLinecap: 'round' },
        h('path', { d: 'M460 150 q7 -7 14 0 q7 -7 14 0' }), h('path', { d: 'M500 128 q5 -5 10 0 q5 -5 10 0' }), h('path', { d: 'M438 132 q4 -4 8 0 q4 -4 8 0' })) : null,
      h('path', { fill: c.far1, d: 'M-400 300 L0 300 C70 280 120 220 190 205 C250 192 290 240 350 232 C420 222 450 160 525 148 C590 138 640 205 705 210 C765 214 800 170 865 160 C930 150 985 214 1045 206 C1110 198 1160 240 1200 236 L1600 236 V600 H-400 Z' }),
      h('path', { fill: c.far2, d: 'M-400 322 L0 322 C90 296 160 262 240 270 C320 278 360 240 440 236 C520 232 560 284 640 286 C720 288 770 246 850 242 C930 238 990 290 1070 286 C1130 283 1170 270 1200 272 L1600 272 V600 H-400 Z' }),
      h('rect', { x: -400, y: 250, width: 2000, height: 130, fill: 'url(#' + id + 'fog)' }),
      h('path', { fill: c.far3, d: 'M-400 352 L0 352 C120 330 210 318 320 326 C430 334 500 306 610 308 C720 310 800 334 900 330 C1000 326 1100 308 1200 316 L1600 316 V600 H-400 Z' }),
      h('g', { transform: 'translate(150 300)' },
        h('rect', { x: 0, y: 22, width: 82, height: 42, fill: c.house }),
        h('rect', { x: 52, y: 22, width: 30, height: 42, fill: c.houseShade }),
        h('path', { d: 'M-8 26 L41 -6 L90 26 Z', fill: c.roof }),
        h('path', { d: 'M41 -6 L90 26 L70 26 L32 0 Z', fill: c.roofDark, opacity: 0.6 }),
        h('rect', { x: 14, y: 36, width: 14, height: 28, rx: 2, fill: c.woodDark }),
        h('rect', { x: 38, y: 36, width: 14, height: 12, rx: 2, fill: c.win }),
        h('rect', { x: 60, y: 36, width: 12, height: 12, rx: 2, fill: c.win, opacity: 0.85 }),
        h('rect', { x: 64, y: -2, width: 8, height: 14, fill: c.roofDark })),
      h('g', { transform: 'translate(1015 316)' },
        h('rect', { x: -5, y: 10, width: 10, height: 52, rx: 4, fill: c.trunk }),
        h('ellipse', { cx: -26, cy: 6, rx: 34, ry: 22, fill: c.tree }), h('ellipse', { cx: 22, cy: 2, rx: 38, ry: 24, fill: c.tree }), h('ellipse', { cx: 0, cy: -16, rx: 40, ry: 26, fill: c.tree }),
        h('ellipse', { cx: -12, cy: -24, rx: 18, ry: 9, fill: c.treeHi, opacity: 0.7 }), h('ellipse', { cx: 24, cy: -8, rx: 12, ry: 6, fill: c.treeHi, opacity: 0.5 })),
      h('path', { fill: 'url(#' + id + 'hill)', d: 'M-400 372 L0 372 C200 344 380 352 560 364 C760 378 950 342 1200 354 L1600 354 V600 H-400 Z' }),
      h('g', null, rows),
      h('path', { fill: 'url(#' + id + 'gr)', d: 'M-400 498 L0 498 C250 474 520 494 760 486 C960 479 1080 494 1200 486 L1600 486 V600 H-400 Z' }),
      h('path', { fill: c.path, d: 'M150 600 C240 560 360 532 520 524 C600 520 650 520 690 522 L712 528 C650 534 560 540 470 556 C380 572 320 590 300 600 Z' }),
      h('path', { fill: 'none', stroke: c.pathEdge, strokeWidth: 3, d: 'M150 600 C240 560 360 532 520 524 C600 520 650 520 690 522' }),
      tufts,
      h('g', { className: 'sc-land-dryer', transform: 'translate(600 388)' },
        h('ellipse', { cx: 230, cy: 150, rx: 250, ry: 14, fill: 'rgba(0,0,0,0.18)' }),
        [18, 98, 178, 258, 338, 412].map(function (lx) { return h('rect', { key: lx, x: lx, y: 120, width: 9, height: 30, rx: 2, fill: c.woodDark }); }),
        h('rect', { x: 0, y: 110, width: 440, height: 15, rx: 3, fill: c.wood }),
        h('rect', { x: 0, y: 121, width: 440, height: 4, fill: c.woodDark, opacity: 0.6 }),
        h('path', { d: 'M0 112 L0 52 C0 14 30 0 70 0 L370 0 C410 0 440 14 440 52 L440 112 Z', fill: c.interior }),
        heat ? h('ellipse', { className: 'sc-glow', cx: 220, cy: 98, rx: 210, ry: 46, fill: 'url(#' + id + 'heat)', opacity: v === 'day' ? 0.5 : 0.9 }) : null,
        h('rect', { x: 12, y: 80, width: 416, height: 6, rx: 2, fill: c.woodDark }),
        h('g', null, beans),
        h('rect', { x: 12, y: 102, width: 416, height: 6, rx: 2, fill: c.woodDark }),
        h('g', null, beans2),
        air ? h('g', { className: 'sc-dryer-air', fill: 'none', stroke: v === 'night' ? '#ffd9a8' : '#3f86c8', strokeWidth: 2.4, strokeLinecap: 'round', opacity: 0.85 },
          h('path', { d: 'M40 58 C140 40 300 40 400 58' }), h('path', { d: 'M60 40 C160 24 280 24 380 40' }), h('path', { d: 'M30 70 C150 58 290 58 410 70' })) : null,
        h('path', { d: 'M0 112 L0 52 C0 14 30 0 70 0 L370 0 C410 0 440 14 440 52 L440 112 Z', fill: 'url(#' + id + 'dome)', stroke: c.frame, strokeWidth: 3.5 }),
        [70, 130, 190, 250, 310, 370].map(function (rx) { return h('path', { key: rx, d: 'M' + rx + ' 112 V1', stroke: c.frame, strokeWidth: 2.4, opacity: 0.95 }); }),
        h('path', { d: 'M14 112 L14 54 C14 26 36 13 70 13', fill: 'none', stroke: c.frameShade, strokeWidth: 2, opacity: 0.7 }),
        h('path', { d: 'M426 112 L426 54 C426 26 404 13 370 13', fill: 'none', stroke: c.frameShade, strokeWidth: 2, opacity: 0.7 }),
        h('path', { d: 'M46 13 C140 5 300 5 396 14', fill: 'none', stroke: '#ffffff', strokeWidth: 4, strokeLinecap: 'round', opacity: 0.75 }),
        [92, 212, 332].map(function (sx) { return h('rect', { key: sx, x: sx, y: 6, width: 16, height: 100, fill: '#ffffff', opacity: 0.16 }); }),
        h('rect', { x: 396, y: 52, width: 32, height: 60, rx: 3, fill: 'rgba(255,255,255,0.18)', stroke: c.frame, strokeWidth: 2.5 }),
        h('circle', { cx: 401, cy: 84, r: 2.2, fill: c.frameShade }),
        h('path', { d: 'M508 150 V44', stroke: c.frameShade, strokeWidth: 5, strokeLinecap: 'round' }),
        h('path', { d: 'M470 44 L548 30 L556 70 L478 84 Z', fill: c.panel, stroke: c.frame, strokeWidth: 2 }),
        h('path', { d: 'M496 39.5 L504 79.5 M522 35 L530 75 M474 64 L552 50', stroke: c.panelLine, strokeWidth: 1.4, opacity: 0.8 }),
        h('path', { d: 'M508 96 C490 96 476 86 466 82', fill: 'none', stroke: c.woodDark, strokeWidth: 2 }),
        h('rect', { x: 448, y: 74, width: 26, height: 34, rx: 4, fill: c.box, stroke: c.frameShade, strokeWidth: 1.5 }),
        h('circle', { className: 'sc-led', cx: 461, cy: 84, r: 3.2, fill: c.led }),
        h('rect', { x: 454, y: 92, width: 14, height: 3, rx: 1.5, fill: c.frameShade }),
        h('path', { d: 'M470 74 V62', stroke: c.frameShade, strokeWidth: 1.6 })),
      Bush(c, 60, 590, 2.1, 'f1'), Bush(c, 1150, 596, 2.3, 'f2'), Bush(c, 1060, 600, 1.7, 'f3'),
      p.wave === 'bottom' ? h('path', { fill: 'var(--superficie)', d: 'M-400 600 V566 H0 V566 C160 586 300 548 470 560 C640 572 780 540 960 556 C1060 565 1140 558 1200 552 V600 Z' }) : null);
  }

  /* ---------------- domain ---------------- */
  function ActiveBatchHero(p) {
    return h('section', { className: 'sc-bhero' },
      h('div', { className: 'sc-bhero-art' }, h(Landscape, { variant: p.variant || 'day', airflow: p.airflow, heater: p.heater, fit: 'xMaxYMax slice' })),
      h('div', { className: 'sc-bhero-card' },
        h('div', { className: 'sc-row' }, h(Chip, { tone: 'brote', icon: 'lotes' }, p.batch), h(StatusPill, { state: p.state || 'running', live: true }, p.stateLabel || 'Secando')),
        h('p', { className: 'sc-bhero-k' }, 'Humedad del grano'),
        h('p', { className: 'sc-bhero-v' }, h('span', { className: 'sc-read', key: String(p.moisture) }, num(p.moisture)), h('small', null, ' %')),
        h('p', { className: 'sc-bhero-sub' }, 'Objetivo 10 – 12 % · ', h('strong', null, p.left || 'faltan ~5 h 40 min')),
        h(ProgressBar, { value: p.progress == null ? 88 : p.progress, label: 'Avance hacia el objetivo' }),
        h('div', { className: 'sc-bhero-meta' },
          h('span', null, h(Icon, { name: 'hoja', size: 15 }), p.variety || 'Caturra'),
          h('span', null, h(Icon, { name: 'secador', size: 15 }), p.site || 'Secador · continuo 40 °C'),
          h('span', null, h(Icon, { name: 'reloj', size: 15 }), p.time || '62 h 10 min'))),
      p.children ? h('div', { className: 'sc-bhero-foot' }, p.children) : null);
  }

  function BatchCard(p) {
    return h('article', { className: 'sc-card sc-batch' },
      h(CardTitle, { icon: 'lotes', title: p.title || 'Lote activo', right: h(Chip, { tone: 'brote' }, p.name) }),
      h('div', { className: 'sc-batch-body' },
        h('div', { className: 'sc-batch-art' }, h(Landscape, { variant: p.variant || 'day', airflow: p.airflow, view: '560 330 600 230', fit: 'xMidYMid slice' })),
        h('dl', { className: 'sc-dl' },
          h('div', null, h('dt', null, 'Variedad'), h('dd', null, p.variety)),
          h('div', null, h('dt', null, 'Protocolo'), h('dd', null, p.method)),
          h('div', null, h('dt', null, 'Ingreso'), h('dd', null, p.start)))),
      p.phase ? h(ProcessTimeline, { phase: p.phase, compact: true }) : null);
  }

  function ActuatorRow(p) {
    var on = p.on, kind = p.kind || 'fan', st = p.blocked ? 'blocked' : p.pending ? 'pending' : on ? 'on' : 'off';
    var label = { on: 'Encendido', off: 'Apagado', blocked: 'Bloqueado', pending: on ? 'Apagando…' : 'Encendiendo…' }[st];
    return h('div', { className: cx('sc-act', 'sc-act-' + st) },
      h('span', { className: cx('sc-act-ic', on && kind === 'heater' && 'sc-glow') }, h(Icon, { name: kind === 'fan' ? 'ventilador' : 'resistencia', size: 20, className: on && kind === 'fan' ? 'sc-spin' : null })),
      h('div', { className: 'sc-act-text' },
        h('span', { className: 'sc-act-name' }, p.name),
        h('span', { className: 'sc-act-meta' }, p.blocked ? 'Bloqueado por seguridad · ' + p.blocked : p.auto ? 'Controlado por el protocolo' : 'Nominal ' + (p.watts || 350) + ' W' + (p.since ? ' · ' + p.since : ''))),
      h('span', { className: cx('sc-act-state', 'sc-act-state-' + st) }, st === 'pending' ? h('span', { className: 'sc-spinner sc-spinner-sm' }) : st === 'blocked' ? h(Icon, { name: 'candado', size: 13 }) : null, label),
      h(Switch, { checked: on, disabled: p.auto || p.blocked || p.pending, label: p.name, onChange: p.onChange }));
  }
  function ActuatorControl(p) {
    var items = p.items || [];
    var m = React.useState(p.mode || 'auto'), mode = m[0], setMode = m[1];
    return h('article', { className: 'sc-card sc-actpanel' },
      h(CardTitle, { icon: 'ventilador', title: p.title || 'Actuadores', right: h(StatusPill, { state: items.some(function (i) { return i.on; }) ? 'running' : 'paused', size: 'sm' }, items.some(function (i) { return i.on; }) ? 'En funcionamiento' : 'Detenidos') }),
      p.showMode === false ? null : h('div', { className: 'sc-act-mode' }, h('span', null, 'Modo de operación'), h(Segmented, { value: mode, onChange: setMode, label: 'Modo de operación', options: [{ id: 'auto', label: 'Automático', icon: 'ia' }, { id: 'manual', label: 'Manual', icon: 'mano' }] })),
      h('div', { className: 'sc-actlist' }, items.map(function (it, i) { return h(ActuatorRow, Object.assign({ key: i }, it, { auto: mode === 'auto' && !it.blocked, onChange: p.onToggle ? function (v) { p.onToggle(i, v); } : undefined })); })),
      mode === 'manual' ? h('p', { className: 'sc-foot' }, h(Icon, { name: 'info', size: 14 }), 'Las órdenes se cumplen cuando el ESP32 las confirma. Si el secador no reporta, se aplican al reconectar.') : h('p', { className: 'sc-foot' }, h(Icon, { name: 'ia', size: 14 }), 'El protocolo «Continuo · 40 °C» decide cuándo encender. Cambia a Manual para mandar órdenes.'));
  }

  function CommandLog(p) {
    return h('article', { className: 'sc-card' },
      h(CardTitle, { icon: 'historial', title: 'Órdenes al equipo', link: 'Ver historial' }),
      h('ol', { className: 'sc-log' }, (p.items || []).map(function (x, i) {
        return h('li', { key: i, className: 'sc-log-' + (x.result || 'ok') },
          h('span', { className: 'sc-log-t' }, x.time),
          h('span', { className: 'sc-log-dot' }),
          h('div', null, h('strong', null, x.action), h('span', null, x.by + (x.result === 'fail' ? ' · No se confirmó' : ' · Confirmado por el ESP32'))));
      })));
  }

  function SensorRow(p) {
    var state = p.state || 'running';
    return h('div', { className: 'sc-sensor' },
      h('span', { className: cx('sc-sq', 'sc-c-' + (p.tone || 'humedad')) }, h(Icon, { name: p.icon || 'sensor', size: 18 })),
      h('div', { className: 'sc-sensor-text' }, h('span', { className: 'sc-sensor-name' }, p.name), h('span', { className: 'sc-sensor-meta' }, p.meta)),
      h('span', { className: 'sc-sensor-val' }, p.value),
      h(StatusPill, { state: state, size: 'sm' }, state === 'running' ? 'Hace ' + (p.ago || '3 s') : state === 'paused' ? 'Desactualizado' : undefined));
  }

  function AlertItem(p) {
    var sev = p.severity || 'warning';
    var map = { warning: ['pausa', 'aviso'], critical: ['alerta', 'termometro'], ok: ['operando', 'checkCirculo'], info: ['info', 'info'] };
    var m = map[sev];
    return h('li', { className: cx('sc-alert', 'sc-alert-' + sev) },
      h('span', { className: 'sc-sq sc-sq-' + m[0] }, h(Icon, { name: p.icon || m[1], size: 18 })),
      h('div', { className: 'sc-alert-text' }, h('span', { className: 'sc-alert-title' }, p.title), h('span', { className: 'sc-alert-meta' }, p.meta)),
      h('span', { className: 'sc-alert-time' }, p.time));
  }
  function AlertList(p) {
    return h('article', { className: 'sc-card sc-alerts' },
      h(CardTitle, { icon: 'alertas', title: p.title || 'Alertas recientes', link: p.link === false ? null : 'Ver todas' }),
      (p.items || []).length ? h('ul', { className: 'sc-alertlist' }, p.items.map(function (a, i) { return h(AlertItem, Object.assign({ key: a.id || i }, a)); }))
        : h('div', { className: 'sc-allgood' }, h(Icon, { name: 'checkCirculo', size: 22 }), h('div', null, h('strong', null, 'Sin alertas activas'), h('span', null, 'Todo en orden.'))));
  }

  function HealthCard(p) {
    var ok = p.ok !== false;
    var rows = p.rows || [['ESP32 conectado', 'Último reporte hace 3 s', true], ['8 de 8 sensores reportando', 'DHT22, termopar, capacitivo y medidor de corriente', true], ['Actuadores responden', 'Ventilador y resistencia confirman órdenes', true]];
    return h('article', { className: cx('sc-card', 'sc-health', ok ? 'sc-health-ok' : 'sc-health-bad') },
      h(CardTitle, { icon: 'secador', title: '¿Está funcionando el equipo?' }),
      h('p', { className: 'sc-health-big' }, h(Icon, { name: ok ? 'checkCirculo' : 'aviso', size: 22 }), ok ? 'Sí, todo en orden' : 'Revisa el equipo'),
      h('ul', { className: 'sc-checks' }, rows.map(function (r) { return h('li', { key: r[0], className: r[2] ? '' : 'sc-check-bad' }, h(Icon, { name: r[2] ? 'check' : 'x', size: 15, stroke: 2.4 }), h('div', null, h('strong', null, r[0]), h('span', null, r[1]))); })));
  }

  function WeighingPanel(p) {
    var dry = p.sample * (1 - p.initial / 100);
    function hum(m) { return (1 - dry / m) * 100; }
    var lo = dry / (1 - 0.10), hi = dry / (1 - 0.12);
    var list = p.weighings || [];
    var last = list[list.length - 1];
    var lastH = last ? hum(last.w) : p.initial;
    var verdict = lastH > 12 ? ['pausa', 'Todavía le falta secar.'] : lastH >= 10 ? ['operando', 'Está en el rango comercial: retíralo.'] : ['alerta', 'Ya pasó el punto: está sobre-secado.'];
    return h('article', { className: 'sc-card sc-weigh' },
      h(CardTitle, { icon: 'balanza', title: 'Pesaje gravimétrico', right: h(Chip, { tone: 'cafe', icon: 'grano' }, p.batch) }),
      h('div', { className: 'sc-weigh-target' },
        h('div', null, h('span', { className: 'sc-weigh-k' }, 'Retira el café cuando la muestra pese entre'), h('span', { className: 'sc-weigh-range' }, num(lo) + ' y ' + num(hi) + ' g')),
        h('div', { className: 'sc-weigh-now sc-st-' + (verdict[0] === 'operando' ? 'running' : verdict[0] === 'pausa' ? 'paused' : 'alert') }, h('span', { className: 'sc-weigh-k' }, 'Último pesaje'), h('b', null, last ? num(last.w) + ' g · ' + num(lastH) + ' %' : '—'), h('span', null, verdict[1]))),
      h('form', { className: 'sc-weigh-form', onSubmit: function (e) { e.preventDefault(); } },
        h(TextField, { label: 'Peso de la muestra', value: p.draft || '', placeholder: '0,0', suffix: 'g', icon: 'balanza', inputMode: 'decimal', size: 'lg' }),
        h(Button, { variant: 'primary', icon: 'mas', type: 'submit' }, 'Registrar pesaje')),
      h('table', { className: 'sc-table sc-table-tight' },
        h('thead', null, h('tr', null, ['Hora', 'Peso', 'Humedad', ''].map(function (c, i) { return h('th', { key: i, className: i === 1 || i === 2 ? 'sc-num' : null }, c); }))),
        h('tbody', null, list.slice().reverse().map(function (x, i) {
          return h('tr', { key: i }, h('td', null, x.t), h('td', { className: 'sc-num' }, num(x.w) + ' g'), h('td', { className: 'sc-num' }, h('strong', null, num(hum(x.w)) + ' %')), h('td', { className: 'sc-num' }, h('button', { type: 'button', className: 'sc-textbtn' }, h(Icon, { name: 'editar', size: 14 }), 'Corregir')));
        }))),
      h('p', { className: 'sc-foot' }, h(Icon, { name: 'info', size: 14 }), 'Humedad por conservación de materia seca (Cenicafé). Muestra de ' + num(p.sample, 0) + ' g con ' + num(p.initial, 0) + ' % inicial: ' + num(dry) + ' g de materia seca.'));
  }

  function GravimetCalibration(p) {
    return h('article', { className: 'sc-card' },
      h(CardTitle, { icon: 'balanza', title: 'Calibración del Gravimet', right: h(Chip, { tone: 'brote', icon: 'check' }, 'Calibrado') }),
      h(Segmented, { block: true, value: 'ref', label: 'Forma de calibrar', options: [{ id: 'ref', label: 'Referencia Cenicafé (53 %)' }, { id: 'man', label: 'Humedad inicial manual' }, { id: 'med', label: 'Puntos medidos' }] }),
      h('div', { className: 'sc-grid2', style: { marginTop: '16px' } },
        h(TextField, { label: 'Lectura del medidor de grano', value: '12,9', suffix: '%' }),
        h(TextField, { label: 'Peso de la muestra', value: '107,3', suffix: 'g', hint: 'Usa el peso del último pesaje para que el punto quede consistente.' })),
      h('table', { className: 'sc-table sc-table-tight', style: { marginTop: '12px' } },
        h('thead', null, h('tr', null, ['Fecha', 'Peso', 'Medidor', 'Calculada', 'Diferencia'].map(function (c, i) { return h('th', { key: c, className: i ? 'sc-num' : null }, c); }))),
        h('tbody', null, (p.points || []).map(function (r, i) { return h('tr', { key: i }, h('td', null, r[0]), h('td', { className: 'sc-num' }, r[1]), h('td', { className: 'sc-num' }, r[2]), h('td', { className: 'sc-num' }, r[3]), h('td', { className: 'sc-num' }, h('span', { className: 'sc-chip sc-chip-' + (r[5] ? 'brote' : 'warn') }, r[4]))); }))),
      h('div', { className: 'sc-row', style: { justifyContent: 'flex-end', marginTop: '14px' } }, h(Button, { variant: 'ghost' }, 'Borrar puntos medidos'), h(Button, { variant: 'primary' }, 'Calibrar y recalcular el lote')));
  }

  function SensorCalibration(p) {
    return h('article', { className: 'sc-card sc-table-wrap' },
      h('div', { className: 'sc-table-head' }, h(CardTitle, { icon: 'calibracion', title: 'Corrección de sensores', right: h(Segmented, { value: '2', label: 'Puntos', options: [{ id: '1', label: 'Un punto' }, { id: '2', label: 'Dos puntos' }] }) }),
        h('p', { className: 'sc-muted' }, 'Recta de corrección por variable: valor = crudo × ganancia + desplazamiento.')),
      h('table', { className: 'sc-table' },
        h('thead', null, h('tr', null, ['Variable', 'Crudo', 'Corregido', 'Ganancia', 'Desplazamiento', 'Estado', ''].map(function (c, i) { return h('th', { key: c + i, className: i && i < 5 ? 'sc-num' : null }, c); }))),
        h('tbody', null, (p.rows || []).map(function (r) {
          return h('tr', { key: r.name },
            h('td', null, h('span', { className: 'sc-td-ic sc-c-' + r.tone }, h(Icon, { name: r.icon, size: 16 })), r.name),
            h('td', { className: 'sc-num sc-muted' }, r.raw), h('td', { className: 'sc-num' }, h('strong', null, r.fixed)), h('td', { className: 'sc-num' }, r.gain), h('td', { className: 'sc-num' }, r.offset),
            h('td', null, r.ok ? h(StatusPill, { state: 'running', size: 'sm' }, 'Dentro de tolerancia') : h(StatusPill, { state: 'paused', size: 'sm' }, 'Requiere ajuste')),
            h('td', { className: 'sc-num' }, h('button', { type: 'button', className: 'sc-textbtn' }, 'Ajustar')));
        }))));
  }

  var TOWNS = [['Pasto', 250, 172], ['Chachagüí', 222, 92], ['La Unión', 330, 54], ['Sandoná', 120, 150], ['Ipiales', 175, 228]];
  function DryerMap(p) {
    var pins = p.pins || [];
    return h('article', { className: cx('sc-card', 'sc-map', p.stacked && 'sc-map-stacked', p.bare && 'sc-map-bare') },
      p.bare ? null : h(CardTitle, { icon: 'mapa', title: p.title || 'Mapa de secadores', right: h(IconButton, { icon: 'expandir', label: 'Ampliar mapa', size: 18 }) }),
      h('div', { className: 'sc-map-body' },
        h('div', { className: 'sc-map-canvas', style: p.height ? { height: p.height } : undefined },
          h('svg', { viewBox: '0 0 420 260', preserveAspectRatio: 'xMidYMid slice', role: 'img', 'aria-label': 'Mapa de Nariño con ' + pins.length + ' secadores' },
            h('rect', { width: 420, height: 260, className: 'sc-map-bg' }),
            h('path', { className: 'sc-map-l1', d: 'M0 70 C60 40 120 80 180 50 S300 30 420 60 V260 H0 Z' }),
            h('path', { className: 'sc-map-l2', d: 'M0 130 C70 100 140 150 220 110 S340 90 420 120 V260 H0 Z' }),
            h('path', { className: 'sc-map-l3', d: 'M0 195 C80 165 170 215 250 185 S360 165 420 190 V260 H0 Z' }),
            h('g', { className: 'sc-map-contours' }, [60, 85, 110, 140, 170, 200, 230].map(function (y, i) { return h('path', { key: i, d: 'M-10 ' + y + ' C80 ' + (y - 30) + ' 160 ' + (y + 25) + ' 240 ' + (y - 12) + ' S360 ' + (y - 28) + ' 430 ' + (y - 6) }); })),
            h('path', { className: 'sc-map-river', d: 'M20 260 C70 220 80 190 140 168 S230 132 262 92 S330 46 370 0' }),
            h('path', { className: 'sc-map-road', d: 'M175 228 C200 205 230 190 250 172 S240 120 222 92 S290 70 330 54' }),
            TOWNS.map(function (t) { return h('g', { key: t[0] }, h('circle', { cx: t[1], cy: t[2], r: 3, className: 'sc-map-town' }), h('text', { x: t[1] + 6, y: t[2] + 4, className: 'sc-map-txt' }, t[0])); }),
            pins.map(function (pin, i) {
              return h('g', { key: i, className: 'sc-mpin sc-st-' + pin.state, transform: 'translate(' + pin.x + ' ' + pin.y + ')' },
                pin.state === 'alert' ? h('circle', { r: 11, cy: -2, className: 'sc-ripple' }) : null,
                h('path', { d: 'M0 0 C-3 -6 -11 -12 -11 -20 A11 11 0 0 1 11 -20 C11 -12 3 -6 0 0 Z', className: 'sc-mpin-body' }),
                h('circle', { cy: -20, r: 4, className: 'sc-mpin-hole' }),
                pin.label ? h('text', { x: 14, y: -16, className: 'sc-mpin-label' }, pin.label) : null);
            })),
          h('span', { className: 'sc-map-label' }, 'Nariño')),
        p.bare ? null : h(StatusLegend, { counts: p.counts })));
  }
  function StatusLegend(p) {
    var c = p.counts || {};
    var L = { running: 'En operación', paused: 'En pausa', alert: 'Alerta', offline: 'Sin conexión' };
    return h('ul', { className: 'sc-legend' }, ['running', 'paused', 'alert', 'offline'].map(function (k) {
      return h('li', { key: k }, h('span', { className: 'sc-pill-dot sc-st-' + k }), h('span', null, L[k]), h('b', null, c[k] || 0));
    }));
  }

  function LocationCard(p) {
    return h('article', { className: 'sc-card' },
      h(CardTitle, { icon: 'ubicar', title: 'Ubicación del secador', right: h(Chip, { tone: 'neutral', icon: 'candado' }, 'Fijada a mano') }),
      h('div', { className: 'sc-grid2' }, h(TextField, { label: 'Latitud', value: '1,3588' }), h(TextField, { label: 'Longitud', value: '−77,2833' })),
      h('div', { style: { margin: '14px 0' } }, h(TextField, { label: 'Nombre del sitio (opcional)', value: 'Secador CISNA · Chachagüí' })),
      h(Checkbox, { checked: true, label: 'Bloquear la ubicación (ignorar la geolocalización por IP del ESP32)' }),
      h('div', { className: 'sc-row', style: { marginTop: '14px' } }, h(Button, { icon: 'ubicar' }, 'Usar mi ubicación actual'), h(Button, { variant: 'primary' }, 'Guardar ubicación y refrescar clima')),
      h('p', { className: 'sc-foot' }, h(Icon, { name: 'info', size: 14 }), 'El clima se consulta con el sitio correcto.'));
  }

  function BatchTable(p) {
    var rows = p.rows || [];
    return h('div', { className: 'sc-card sc-table-wrap' },
      h('table', { className: 'sc-table' },
        h('thead', null, h('tr', null, ['Lote', 'Sitio', 'Variedad', 'Ingreso', 'Duración', 'Humedad final', 'Estado', ''].map(function (c, i) { return h('th', { key: i, className: i === 4 || i === 5 ? 'sc-num' : null }, c); }))),
        h('tbody', null, rows.map(function (r) {
          return h('tr', { key: r.n, className: r.active ? 'sc-tr-active' : null },
            h('td', null, h('span', { className: 'sc-td-bean' }, h(Icon, { name: 'grano', size: 16 })), h('strong', null, r.n)),
            h('td', null, h(Chip, { tone: r.site === 'Aire libre' ? 'cafe' : 'brote', icon: r.site === 'Aire libre' ? 'sol' : 'secador' }, r.site)),
            h('td', null, r.variety), h('td', null, r.start), h('td', { className: 'sc-num' }, r.dur), h('td', { className: 'sc-num' }, h('strong', null, r.final)),
            h('td', null, r.active ? h(StatusPill, { state: 'running', live: true, size: 'sm' }, 'Secando') : h(StatusPill, { state: 'running', size: 'sm' }, 'Completado')),
            h('td', { className: 'sc-num' }, h(IconButton, { icon: 'chevron', label: 'Ver ' + r.n, size: 18 })));
        }))));
  }

  function ProtocolComparison(p) {
    var rows = p.rows || [];
    return h('article', { className: 'sc-card' },
      h(CardTitle, { icon: 'grafica', title: 'Comparación de protocolos', right: h('div', { className: 'sc-legend-inline' }, h('span', null, h('i', { className: 'sc-sw sc-sw-dry' }), 'Secador'), h('span', null, h('i', { className: 'sc-sw sc-sw-open' }), 'Aire libre')) }),
      h('ul', { className: 'sc-compare' }, rows.map(function (r) {
        var m = Math.max(r.a, r.b) || 1;
        return h('li', { key: r.label },
          h('span', { className: 'sc-compare-l' }, r.label),
          h('div', { className: 'sc-compare-bars' },
            h('div', null, h('span', { className: 'sc-cbar sc-cbar-dry sc-grow-x', style: { width: Math.max(2, r.a / m * 100) + '%' } }), h('b', null, r.fa)),
            h('div', null, h('span', { className: 'sc-cbar sc-cbar-open sc-grow-x', style: { width: Math.max(2, r.b / m * 100) + '%' } }), h('b', null, r.fb))));
      })),
      p.note ? h('p', { className: 'sc-foot' }, h(Icon, { name: 'info', size: 14 }), p.note) : null);
  }

  function NewBatchForm(p) {
    var dry = 200 * (1 - 0.53);
    return h('article', { className: 'sc-card sc-newbatch' },
      h(CardTitle, { icon: 'mas', title: 'Nuevo lote' }),
      h('div', { className: 'sc-form' },
        h(TextField, { label: 'Nombre del lote', value: 'Lote C · Castillo', hint: 'Así aparecerá en el panel, la app y el reloj.' }),
        h('div', { className: 'sc-field' }, h('span', { className: 'sc-field-label' }, '¿Dónde se seca?'), h(Segmented, { block: true, value: 'dryer', label: '¿Dónde se seca?', options: [{ id: 'dryer', label: 'Secador', icon: 'secador' }, { id: 'open', label: 'Aire libre', icon: 'sol' }] })),
        h('div', { className: 'sc-grid2' }, h(Select, { label: 'Variedad', value: 'Castillo', options: ['Castillo', 'Caturra', 'Colombia', 'Tabi', 'Cenicafé 1'] }), h(Select, { label: 'Protocolo', value: 'Continuo · 40 °C', options: ['Continuo · 40 °C', 'Escalonado 35 → 45 °C', 'Solo solar'] })),
        h('div', { className: 'sc-grid3' }, h(TextField, { label: 'Muestra Gravimet', value: '200', suffix: 'g' }), h(TextField, { label: 'Humedad inicial', value: '53', suffix: '%', hint: 'Referencia Cenicafé' }), h(TextField, { label: 'Humedad objetivo', value: '11', suffix: '%' })),
        h('div', { className: 'sc-calc' }, h(Icon, { name: 'balanza', size: 20 }), h('div', null, h('span', null, 'Peso de retiro calculado'), h('strong', null, num(dry / 0.89) + ' g')), h('small', null, 'con ' + num(dry) + ' g de materia seca')),
        h('div', { className: 'sc-field' }, h('span', { className: 'sc-field-label' }, 'Variables a registrar'),
          h('div', { className: 'sc-checkgrid' }, ['Temperatura interior', 'Temperatura tope', 'Humedad relativa', 'Humedad del grano', 'Clima exterior', 'Corriente y potencia'].map(function (x, i) { return h(Checkbox, { key: x, checked: i !== 1, label: x }); }))),
        h('div', { className: 'sc-row', style: { justifyContent: 'flex-end' } }, h(Button, { variant: 'ghost' }, 'Cancelar'), h(Button, { variant: 'primary', icon: 'encendido' }, 'Iniciar lote'))));
  }

  function DryerPhoto(p) {
    return h('article', { className: 'sc-card sc-photo' },
      h('div', { className: 'sc-photo-img' }, h(Landscape, { variant: 'day', view: '540 300 640 300', fit: 'xMidYMid slice' }), h('span', { className: 'sc-glass-chip' }, h(Icon, { name: 'camara', size: 14 }), 'Foto del secador')),
      h('div', { className: 'sc-photo-body' }, h('div', null, h('strong', null, 'Secador CISNA · Chachagüí'), h('span', null, '1,3588 · −77,2833 · 2.100 m s. n. m.')), h(Button, { size: 'sm', icon: 'camara' }, 'Cambiar la foto')));
  }

  function EmptyState(p) {
    return h('div', { className: 'sc-card sc-empty' },
      h('div', { className: 'sc-empty-art' }, h(Landscape, { variant: 'day', airflow: false, view: '480 260 720 340' })),
      h('h3', null, p.title || 'No hay lotes registrados'),
      h('p', null, p.body || 'Cuando ingreses café al secador, su registro aparecerá aquí.'),
      p.action ? h(Button, { variant: 'primary', icon: 'mas' }, p.action) : null);
  }

  /* ---------------- web layout ---------------- */
  var NAV = [['monitoreo', 'Monitoreo', 'monitoreo'], ['lotes', 'Lotes', 'lotes'], ['gravimetrico', 'Gravimétrico', 'balanza'], ['actuadores', 'Actuadores', 'ventilador'], ['calibracion', 'Calibración', 'calibracion'], ['historial', 'Historial', 'historial'], ['alertas', 'Alertas', 'alertas'], ['mapa', 'Mapa', 'mapa']];
  function Sidebar(p) {
    var active = p.active || 'monitoreo';
    return h('aside', { className: cx('sc-side', p.collapsed && 'sc-side-collapsed') },
      h('div', { className: 'sc-side-logo' }, h(Logo, { variant: p.collapsed ? 'symbol' : 'full', inverse: true, height: p.collapsed ? 40 : 42 })),
      p.collapsed ? null : h('button', { type: 'button', className: 'sc-side-site' }, h('span', { className: 'sc-side-site-ic' }, h(Icon, { name: 'secador', size: 16 })), h('span', null, h('b', null, 'Secador CISNA'), h('small', null, 'Chachagüí · Nariño')), h(Icon, { name: 'abajo', size: 14 })),
      h('nav', { className: 'sc-side-nav', 'aria-label': 'Navegación principal' },
        NAV.map(function (n) {
          var on = n[0] === active;
          return h('a', { key: n[0], href: '#', className: cx('sc-side-item', on && 'sc-side-on'), 'aria-current': on ? 'page' : undefined, title: n[1], onClick: function (e) { e.preventDefault(); if (p.onNav) p.onNav(n[0]); } },
            h(Icon, { name: n[2], size: 20 }), p.collapsed ? null : h('span', null, n[1]),
            n[0] === 'alertas' && p.alerts ? h('span', { className: 'sc-side-badge' }, p.alerts) : null);
        })),
      h('div', { className: 'sc-side-art', 'aria-hidden': true }, h(CoffeeLeafArt, { width: p.collapsed ? 70 : 150 })),
      p.collapsed ? null : h('div', { className: 'sc-side-foot' }, h(LiveDot, { off: p.offline, label: p.offline ? 'Sin conexión · último dato 07:12' : 'ESP32 conectado' })));
  }
  function TopBar(p) {
    return h('header', { className: 'sc-top' },
      h('div', { className: 'sc-top-text' }, h('h1', { className: 'sc-hello' }, p.title || '¡Hola, Administrador!'), h('p', null, p.subtitle || 'Monitoreo y control de secadores de café en tiempo real.')),
      h('div', { className: 'sc-top-right' },
        p.weather !== false ? h(WeatherChip, { temp: p.temp == null ? 18 : p.temp }) : null,
        h(IconButton, { icon: 'alertas', label: 'Alertas', count: p.alerts }),
        h('button', { type: 'button', className: 'sc-user' }, h(Avatar, { name: p.user || 'Administrador CISNA' }), h('span', { className: 'sc-user-txt' }, h('b', null, p.userName || 'Diego'), h('small', null, 'Administrador')), h(Icon, { name: 'abajo', size: 16 }))));
  }
  function PageHeader(p) {
    return h('header', { className: 'sc-pagehead' },
      h('div', null, p.eyebrow ? h('p', { className: 'sc-eyebrow' }, p.eyebrow) : null, h('h1', { className: 'sc-hello' }, p.title), p.subtitle ? h('p', { className: 'sc-pagehead-sub' }, p.subtitle) : null),
      p.actions ? h('div', { className: 'sc-row' }, p.actions) : null);
  }
  function AppShell(p) {
    return h('div', { className: cx('sc-shell', p.className) },
      h(Sidebar, { active: p.active, alerts: p.alerts, onNav: p.onNav, collapsed: p.collapsed, offline: p.offline }),
      h('main', { className: 'sc-main', key: p.active }, p.children));
  }

  function LoginWeb(p) {
    var st = React.useState(p.state || 'idle'), state = st[0], set = st[1];
    return h('section', { className: 'sc-login2' },
      h('div', { className: 'sc-login2-scene' }, h(Landscape, { variant: p.variant || 'day', fit: 'xMidYMid slice', view: '250 0 1200 600', birds: false })),
      h('div', { className: 'sc-login2-shade', 'aria-hidden': true }),
      h('div', { className: 'sc-login2-brand' }, h(Logo, { height: 58 })),
      h('div', { className: 'sc-login2-story' },
        h('h2', null, 'Del cafetal al pergamino,', h('br'), 'cada grado cuenta.'),
        h('div', { className: 'sc-row' },
          h('span', { className: 'sc-glass-chip' }, h('span', { className: 'sc-livedot sc-live' }), '3 secadores reportando'),
          h('span', { className: 'sc-glass-chip' }, h(Icon, { name: 'nubeSol', size: 15 }), 'Chachagüí · 18 °C'),
          h('span', { className: 'sc-glass-chip' }, h(Icon, { name: 'grano', size: 15 }), 'Lote B · 12,4 %'))),
      h('form', { className: 'sc-login2-card', onSubmit: function (e) { e.preventDefault(); set(state === 'error' ? 'idle' : 'busy'); } },
        h(Logo, { variant: 'symbol', height: 52 }),
        h('h3', null, 'Bienvenido de nuevo'),
        h('p', { className: 'sc-muted' }, 'Ingresa con tu correo del portal CISNA.'),
        state === 'error' ? h('div', { className: 'sc-formerr', role: 'alert' }, h(Icon, { name: 'aviso', size: 16 }), 'No pudimos verificar tus datos. Revisa el correo y la contraseña.') : null,
        h(TextField, { label: 'Correo', icon: 'correo', value: 'diego@narino.gov.co', type: 'email', size: 'lg' }),
        h(TextField, { label: 'Contraseña', icon: 'candado', value: 'secador2025', type: 'password', size: 'lg' }),
        h('div', { className: 'sc-login2-row' }, h(Checkbox, { checked: true, label: 'Recordarme en este equipo' }), h('a', { href: '#', className: 'sc-link', onClick: function (e) { e.preventDefault(); } }, '¿Olvidaste tu contraseña?')),
        h(Button, { variant: 'primary', size: 'lg', block: true, type: 'submit', busy: state === 'busy' }, state === 'busy' ? 'Verificando…' : 'Ingresar'),
        h('p', { className: 'sc-login2-foot' }, 'Subsecretaría de Innovación · Gobernación de Nariño')));
  }

  /* ---------------- Android ---------------- */
  var TABS = [['inicio', 'Inicio', 'inicio'], ['lotes', 'Lotes', 'lotes'], ['pesaje', 'Pesaje', 'balanza'], ['equipo', 'Equipo', 'ventilador'], ['mas', 'Más', 'menu']];
  function AndroidNav(p) {
    var a = p.active || 'inicio';
    return h('nav', { className: 'sc-anav', 'aria-label': 'Navegación' }, TABS.map(function (t) {
      var on = t[0] === a;
      return h('button', { key: t[0], type: 'button', className: cx('sc-anav-item', on && 'sc-anav-on'), 'aria-current': on ? 'page' : undefined, onClick: p.onChange ? function () { p.onChange(t[0]); } : undefined },
        h('span', { className: 'sc-anav-pill' }, h(Icon, { name: t[2], size: 22 }), t[0] === 'inicio' && p.alerts ? h('span', { className: 'sc-count' }, p.alerts) : null), h('span', null, t[1]));
    }));
  }
  function AndroidFrame(p) {
    return h('div', { className: cx('sc-android', p.dark && 'sc-android-dark', p.className) },
      h('div', { className: cx('sc-astatus', p.lightStatus && 'sc-astatus-light') }, h('span', null, p.time || '10:24'), h('span', { className: 'sc-acam' }), h('span', { className: 'sc-astatus-ic' }, h(Icon, { name: 'wifi', size: 14, stroke: 2.2 }), h(Icon, { name: 'bateria', size: 16, stroke: 2 }))),
      h('div', { className: 'sc-abody', key: p.screenKey }, p.children),
      p.fab ? h('button', { type: 'button', className: 'sc-fab', 'aria-label': p.fab.label }, h(Icon, { name: p.fab.icon, size: 22 }), p.fab.text ? h('span', null, p.fab.text) : null) : null,
      p.nav === false ? null : h(AndroidNav, { active: p.nav, alerts: p.alerts, onChange: p.onNav }),
      h('div', { className: 'sc-agesture' }, h('span', null)));
  }
  function AppBar(p) {
    return h('header', { className: cx('sc-appbar', p.tone === 'dark' && 'sc-appbar-dark', p.large && 'sc-appbar-lg') },
      h('div', { className: 'sc-appbar-row' },
        p.back ? h(IconButton, { icon: 'atras', label: 'Volver', variant: p.tone === 'dark' ? 'dark' : undefined }) : null,
        p.logo ? h(Logo, { inverse: p.tone === 'dark', height: 30 }) : h('h1', { className: 'sc-appbar-title' }, p.title),
        h('span', { style: { flex: 1 } }),
        (p.actions || []).map(function (a, i) { return h(IconButton, { key: i, icon: a.icon, label: a.label, count: a.count, variant: p.tone === 'dark' ? 'dark' : undefined }); })),
      p.large && p.logo ? h('div', { className: 'sc-appbar-big' }, h('h1', null, p.title), p.subtitle ? h('p', null, p.subtitle) : null) : null,
      p.children);
  }
  function ListItem(p) {
    return h('button', { type: 'button', className: cx('sc-li', p.danger && 'sc-li-danger') },
      h('span', { className: cx('sc-sq', p.tone && 'sc-c-' + p.tone) }, h(Icon, { name: p.icon, size: 19 })),
      h('span', { className: 'sc-li-text' }, h('b', null, p.title), p.sub ? h('small', null, p.sub) : null),
      p.right || h(Icon, { name: 'chevron', size: 18, className: 'sc-li-chev' }));
  }
  function ReadingTile(p) {
    return h('div', { className: cx('sc-rtile', 'sc-c-' + (p.tone || 'humedad')) },
      h('span', { className: 'sc-rtile-ic' }, h(Icon, { name: p.icon || (MAG[p.tone] || {}).icon, size: 18 })),
      h('span', { className: 'sc-rtile-l' }, p.label),
      h('span', { className: 'sc-rtile-v' }, h('span', { className: 'sc-read', key: String(p.value) }, p.text || num(p.value, p.decimals)), h('small', null, ' ' + (p.unit || ''))),
      p.data ? h(Sparkline, { data: p.data, tone: p.tone, live: p.live }) : null);
  }
  function HoldButton(p) {
    var s = React.useState(0), pr = s[0], set = s[1];
    var tm = React.useRef(null);
    function start() { var v = 0; clearInterval(tm.current); tm.current = setInterval(function () { v += 8; set(Math.min(100, v)); if (v >= 100) clearInterval(tm.current); }, 60); }
    function stop() { clearInterval(tm.current); if (pr < 100) set(0); }
    return h('button', { type: 'button', className: cx('sc-hold', pr >= 100 && 'sc-hold-done'), onPointerDown: start, onPointerUp: stop, onPointerLeave: stop },
      h('span', { className: 'sc-hold-fill', style: { width: pr + '%' } }),
      h('span', { className: 'sc-hold-txt' }, h(Icon, { name: pr >= 100 ? 'check' : 'encendido', size: 18 }), pr >= 100 ? (p.done || 'Orden enviada') : (p.children || 'Mantén presionado para encender')));
  }
  function NotificationCard(p) {
    return h('div', { className: cx('sc-notif', 'sc-notif-' + (p.severity || 'warning')) },
      h('div', { className: 'sc-notif-head' }, h('img', { src: ASSETS.simbolo, alt: '', className: 'sc-notif-logo' }), h('span', null, 'SISCAN · ' + (p.when || 'ahora')), h('span', { style: { flex: 1 } }), h(Icon, { name: 'abajo', size: 14 })),
      h('div', { className: 'sc-notif-body' },
        h('span', { className: 'sc-sq sc-sq-' + (p.severity === 'critical' ? 'alerta' : p.severity === 'ok' ? 'operando' : 'pausa') }, h(Icon, { name: p.icon || 'aviso', size: 18 })),
        h('div', null, h('strong', null, p.title), h('span', null, p.text))),
      p.actions ? h('div', { className: 'sc-notif-acts' }, p.actions.map(function (a) { return h('button', { key: a, type: 'button' }, a); })) : null);
  }
  function HomeWidget(p) {
    var size = p.size || 'm';
    return h('div', { className: cx('sc-hwidget', 'sc-hwidget-' + size) },
      h('div', { className: 'sc-hw-top' }, h('img', { src: ASSETS.simboloClaro, alt: '', className: 'sc-hw-logo' }), h('span', null, p.batch || 'Lote B · Caturra'), h('span', { style: { flex: 1 } }), h('span', { className: 'sc-livedot sc-live' })),
      size === 's' ? h('div', { className: 'sc-hw-big' }, h('b', null, num(p.moisture) + ' %'), h('small', null, 'humedad del grano'))
        : h('div', { className: 'sc-hw-row' },
          h(RingGauge, { value: p.progress || 88, text: num(p.moisture) + ' %', size: 84, stroke: 8, tone: 'lima', gradient: true }),
          h('div', { className: 'sc-hw-stats' },
            h('span', null, h(Icon, { name: 'termometro', size: 14 }), num(p.temp) + ' °C'),
            h('span', null, h(Icon, { name: 'gotas', size: 14 }), num(p.hr, 0) + ' % HR'),
            h('span', null, h(Icon, { name: 'reloj', size: 14 }), 'Listo en ' + (p.left || '5 h 40')))));
  }

  /* ---------------- Wear OS ---------------- */
  function WatchFrame(p) {
    var cid = useGid('wt');
    return h('figure', { className: 'sc-wfig' },
      h('div', { className: cx('sc-wcase', p.ambient && 'sc-wcase-amb') },
        h('span', { className: 'sc-wcrown', 'aria-hidden': true }),
        h('div', { className: cx('sc-wscreen', p.className), 'data-theme': 'oscuro', role: 'group', 'aria-label': p.label },
          p.time === false ? null : h('svg', { className: 'sc-wtime', viewBox: '0 0 224 224', 'aria-hidden': true },
            h('defs', null, h('path', { id: cid, d: 'M 20 112 A 92 92 0 0 1 204 112' })),
            h('text', null, h('textPath', { href: '#' + cid, startOffset: '50%', textAnchor: 'middle' }, p.time || '10:24'))),
          p.children)),
      p.caption ? h('figcaption', null, p.caption) : null);
  }
  function WatchArc(p) {
    var pct = Math.max(0, Math.min(100, p.value)), r = 104, c = 112;
    var len = 2 * Math.PI * r * 0.75;
    return h('svg', { className: cx('sc-warc', 'sc-c-' + (p.tone || 'lima')), viewBox: '0 0 224 224', 'aria-hidden': true },
      h('circle', { cx: c, cy: c, r: r, className: 'sc-warc-track', strokeDasharray: len + ' 999', transform: 'rotate(-45 112 112)' }),
      h('circle', { cx: c, cy: c, r: r, className: 'sc-warc-fill sc-fill', pathLength: 133.33, strokeDasharray: '100 999', strokeDashoffset: 100 - pct, transform: 'rotate(-45 112 112)' }));
  }
  function WatchMonitor(p) {
    return h(WatchFrame, { label: 'Monitoreo del lote', caption: p.caption },
      h(WatchArc, { value: p.progress || 88 }),
      h('div', { className: 'sc-wstack' },
        h('span', { className: 'sc-wk' }, h(Icon, { name: 'grano', size: 14 }), 'Humedad del grano'),
        h('span', { className: 'sc-wbig' }, h('span', { className: 'sc-read', key: String(p.moisture) }, num(p.moisture)), h('small', null, '%')),
        h('span', { className: 'sc-wsub' }, 'Objetivo 10 – 12 %'),
        h('span', { className: 'sc-wchip' }, h('span', { className: 'sc-livedot sc-live' }), p.batch || 'Lote B · Secando')));
  }
  function WatchReadings(p) {
    return h(WatchFrame, { label: 'Lecturas', caption: p.caption },
      h('div', { className: 'sc-wlist' },
        h('span', { className: 'sc-wtitle' }, 'Lecturas'),
        (p.items || []).map(function (x) {
          return h('div', { key: x.label, className: cx('sc-wrow', 'sc-c-' + x.tone) }, h(Icon, { name: x.icon || MAG[x.tone].icon, size: 16 }), h('span', null, x.label), h('b', null, x.value));
        })));
  }
  function WatchActuators(p) {
    var s = React.useState(p.items || []), it = s[0], set = s[1];
    return h(WatchFrame, { label: 'Equipo', caption: p.caption },
      h('div', { className: 'sc-wlist' },
        h('span', { className: 'sc-wtitle' }, 'Equipo · ', h('b', null, p.mode || 'Manual')),
        it.map(function (x, i) {
          return h('button', { key: x.name, type: 'button', className: cx('sc-wtoggle', x.on && 'sc-wtoggle-on'), 'aria-pressed': x.on, onClick: function () { var n = it.slice(); n[i] = Object.assign({}, x, { on: !x.on }); set(n); } },
            h('span', { className: cx('sc-wtoggle-ic', x.on && x.kind === 'heater' && 'sc-glow') }, h(Icon, { name: x.kind === 'fan' ? 'ventilador' : 'resistencia', size: 18, className: x.on && x.kind === 'fan' ? 'sc-spin' : null })),
            h('span', { className: 'sc-wtoggle-t' }, h('b', null, x.name), h('small', null, x.on ? 'Encendido' : 'Apagado')),
            h('span', { className: 'sc-wtoggle-sw' }, h('i', null)));
        })));
  }
  function WatchPrediction(p) {
    return h(WatchFrame, { label: 'Predicción', caption: p.caption },
      h(WatchArc, { value: p.confidence || 82, tone: 'pred' }),
      h('div', { className: 'sc-wstack' },
        h('span', { className: 'sc-wk sc-wk-pred' }, h(Icon, { name: 'ia', size: 14 }), 'Listo en'),
        h('span', { className: 'sc-wbig sc-wbig-sm' }, p.remaining || '5 h 40'),
        h('span', { className: 'sc-wsub' }, 'entre ' + (p.min || '4 h 50') + ' y ' + (p.max || '6 h 30')),
        h('span', { className: 'sc-wchip sc-wchip-pred' }, 'Confianza ' + (p.confidence || 82) + ' %')));
  }
  function WatchAlert(p) {
    var crit = (p.severity || 'critical') === 'critical';
    return h(WatchFrame, { label: 'Alerta', caption: p.caption, className: crit ? 'sc-wscreen-alert' : 'sc-wscreen-warn' },
      h('div', { className: 'sc-wstack sc-walert' },
        h('span', { className: 'sc-walert-ic' }, h(Icon, { name: p.icon || 'termometro', size: 24 })),
        h('span', { className: 'sc-wtitle2' }, p.title || 'Temperatura alta'),
        h('span', { className: 'sc-wsub' }, p.text || '48,7 °C · Secador CISNA'),
        h('div', { className: 'sc-wbtns' }, h('button', { type: 'button', className: 'sc-wbtn sc-wbtn-ghost', 'aria-label': 'Descartar' }, h(Icon, { name: 'x', size: 20 })), h('button', { type: 'button', className: 'sc-wbtn', 'aria-label': 'Ver detalle' }, h(Icon, { name: 'check', size: 20 })))));
  }
  function WatchWeigh(p) {
    var s = React.useState(p.value || 107.3), v = s[0], set = s[1];
    var dry = 94, hum = (1 - dry / v) * 100;
    return h(WatchFrame, { label: 'Registrar pesaje', caption: p.caption },
      h('div', { className: 'sc-wstack sc-wweigh' },
        h('span', { className: 'sc-wk' }, h(Icon, { name: 'balanza', size: 14 }), 'Peso de la muestra'),
        h('div', { className: 'sc-wweigh-row' },
          h('button', { type: 'button', className: 'sc-wround', 'aria-label': 'Restar 0,1 g', onClick: function () { set(Math.round((v - 0.1) * 10) / 10); } }, h(Icon, { name: 'menos', size: 18 })),
          h('span', { className: 'sc-wbig sc-wbig-sm' }, h('span', { className: 'sc-read', key: String(v) }, num(v)), h('small', null, 'g')),
          h('button', { type: 'button', className: 'sc-wround', 'aria-label': 'Sumar 0,1 g', onClick: function () { set(Math.round((v + 0.1) * 10) / 10); } }, h(Icon, { name: 'mas', size: 18 }))),
        h('span', { className: 'sc-wsub' }, '= ' + num(hum) + ' % · retira 104,4 – 106,8 g'),
        h('button', { type: 'button', className: 'sc-wcta' }, 'Guardar')));
  }
  function WatchConfirm(p) {
    return h(WatchFrame, { label: p.title || 'Pesaje registrado', caption: p.caption, time: false },
      h('div', { className: 'sc-wstack', key: p.replay },
        h('svg', { className: 'sc-wc-check', width: 64, height: 64, viewBox: '0 0 64 64', 'aria-hidden': true }, h('circle', { cx: 32, cy: 32, r: 28, className: 'sc-wc-circle' }), h('path', { d: 'M20 33l8 8l16-17', className: 'sc-wc-tick' })),
        h('span', { className: 'sc-wtitle2' }, p.title || 'Pesaje registrado'),
        h('span', { className: 'sc-wsub' }, p.text || '107,3 g · 12,4 % de humedad')));
  }
  function WatchTile(p) {
    return h(WatchFrame, { label: 'Tarjeta SISCAN', caption: p.caption },
      h('div', { className: 'sc-wstack sc-wtile' },
        h('span', { className: 'sc-wk' }, h('img', { src: ASSETS.simboloClaro, alt: '', className: 'sc-wlogo' }), p.batch || 'Lote B'),
        h(RingGauge, { value: p.progress || 88, text: num(p.moisture || 12.4) + ' %', size: 84, stroke: 7, tone: 'lima', gradient: true }),
        h('div', { className: 'sc-wtile-stats' }, h('span', null, h(Icon, { name: 'termometro', size: 13 }), '42,6°'), h('span', null, h(Icon, { name: 'reloj', size: 13 }), '5 h 40')),
        h('button', { type: 'button', className: 'sc-wcta sc-wcta-sm' }, 'Abrir')));
  }
  function WatchFace(p) {
    return h(WatchFrame, { label: 'Esfera con complicaciones SISCAN', caption: p.caption, time: false, className: 'sc-wface' },
      h('div', { className: 'sc-wstack' },
        h('span', { className: 'sc-wdate' }, p.date || 'jue 8 oct'),
        h('span', { className: 'sc-wclock' }, p.time || '10:24'),
        h('div', { className: 'sc-wcomps' },
          h('span', { className: 'sc-wcomp' }, h(RingGauge, { value: 88, text: '12,4', size: 48, stroke: 4, tone: 'lima' })),
          h('span', { className: 'sc-wcomp sc-wcomp-t' }, h(Icon, { name: 'termometro', size: 14 }), h('b', null, '42°')),
          h('span', { className: cx('sc-wcomp', 'sc-wcomp-t', p.alerts && 'sc-wcomp-alert') }, h(Icon, { name: 'alertas', size: 14 }), h('b', null, String(p.alerts || 0)))),
        h('span', { className: 'sc-wsub' }, 'Lote B · listo en 5 h 40')));
  }
  function WatchAmbient(p) {
    return h(WatchFrame, { label: 'Modo siempre activo', caption: p.caption, ambient: true, time: false, className: 'sc-wamb' },
      h('div', { className: 'sc-wstack' },
        h('span', { className: 'sc-wamb-clock' }, p.time || '10:24'),
        h('span', { className: 'sc-wamb-line' }, h(Icon, { name: 'grano', size: 14 }), '12,4 % · Lote B'),
        h('span', { className: 'sc-wamb-line' }, 'Listo en 5 h 40')));
  }
  function WatchBatches(p) {
    return h(WatchFrame, { label: 'Lotes', caption: p.caption },
      h('div', { className: 'sc-wlist' },
        h('span', { className: 'sc-wtitle' }, 'Lotes'),
        (p.items || []).map(function (x) {
          return h('div', { key: x.name, className: cx('sc-wbatch', x.active && 'sc-wbatch-on') }, h(Icon, { name: 'grano', size: 16 }), h('span', null, h('b', null, x.name), h('small', null, x.state)), h('em', null, x.value));
        })));
  }

  var EXPORTS = {
    ASSETS: ASSETS, num: num, money: money, Icon: Icon, ICON_NAMES: Object.keys(I).filter(function (k) { return k !== 'termometroGrano'; }),
    Logo: Logo, CoffeeLeafArt: CoffeeLeafArt, Button: Button, IconButton: IconButton, TextField: TextField, Select: Select, Switch: Switch, Segmented: Segmented, Checkbox: Checkbox,
    StatusPill: StatusPill, Chip: Chip, LiveDot: LiveDot, Avatar: Avatar, ProgressBar: ProgressBar, Toast: Toast, CardTitle: CardTitle,
    Sparkline: Sparkline, MetricCard: MetricCard, RingGauge: RingGauge, MoistureChart: MoistureChart, EnergyCard: EnergyCard, ActuatorEnergy: ActuatorEnergy,
    PredictionCard: PredictionCard, ProcessTimeline: ProcessTimeline, MoistureScale: MoistureScale, ConditionsTable: ConditionsTable, WeatherCard: WeatherCard, WeatherChip: WeatherChip,
    Landscape: Landscape, ActiveBatchHero: ActiveBatchHero, BatchCard: BatchCard, ActuatorRow: ActuatorRow, ActuatorControl: ActuatorControl, CommandLog: CommandLog,
    SensorRow: SensorRow, AlertItem: AlertItem, AlertList: AlertList, HealthCard: HealthCard, WeighingPanel: WeighingPanel, GravimetCalibration: GravimetCalibration,
    SensorCalibration: SensorCalibration, DryerMap: DryerMap, StatusLegend: StatusLegend, LocationCard: LocationCard, BatchTable: BatchTable, ProtocolComparison: ProtocolComparison,
    NewBatchForm: NewBatchForm, DryerPhoto: DryerPhoto, EmptyState: EmptyState,
    Sidebar: Sidebar, TopBar: TopBar, PageHeader: PageHeader, AppShell: AppShell, LoginWeb: LoginWeb,
    AndroidFrame: AndroidFrame, AndroidNav: AndroidNav, AppBar: AppBar, ListItem: ListItem, ReadingTile: ReadingTile, HoldButton: HoldButton, NotificationCard: NotificationCard, HomeWidget: HomeWidget,
    WatchFrame: WatchFrame, WatchArc: WatchArc, WatchMonitor: WatchMonitor, WatchReadings: WatchReadings, WatchActuators: WatchActuators, WatchPrediction: WatchPrediction,
    WatchAlert: WatchAlert, WatchWeigh: WatchWeigh, WatchConfirm: WatchConfirm, WatchTile: WatchTile, WatchFace: WatchFace, WatchAmbient: WatchAmbient, WatchBatches: WatchBatches
  };
  window.Siscan = Object.assign(window.Siscan || {}, EXPORTS);
})();
