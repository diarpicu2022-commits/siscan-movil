// SISCAN — tipos de los componentes (documentación). window.Siscan.<Componente>
import type { ReactNode, ButtonHTMLAttributes, ChangeEventHandler } from "react";

export type IconName = "temperatura" | "humedad" | "aire" | "ventilador" | "resistencia" | "balanza" | "muestra" | "calibracion" | "lote" | "alerta" | "prediccion" | "sincronizar" | "sin-conexion" | "historial" | "mapa" | "energia" | "solar" | "candado" | "mano" | "correo" | "usuario" | "ojo" | "ojo-cerrado" | "finca" | "flecha" | "cerrar" | "check";
export type Status = "normal" | "advertencia" | "critico" | "error" | "sin-conexion" | "desactualizado" | "resuelta" | "info";
export type ProvenanceKind = "medido" | "estimado" | "prediccion" | "objetivo" | "desactualizado" | "no-disponible";
export type BatchStatus = "programado" | "activo" | "secando" | "pausa" | "completado" | "detenido" | "alerta";

export interface IconProps { name: IconName; size?: number; title?: string; strokeWidth?: number; className?: string }
export type Tone = "arcilla" | "cafeto" | "bruma" | "anil" | "panela" | "oxido" | "monte";
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> { variant?: "primario" | "suave" | "secundario" | "silencioso" | "peligro"; tone?: Tone; size?: "sm" | "md" | "lg"; icon?: IconName; badge?: number | string; iconOnly?: boolean; loading?: boolean; loadingLabel?: string; children?: ReactNode }
export interface StatusMarkProps { status: Status; variant?: "suave" | "solido" | "linea"; size?: "lg"; label?: string; detail?: string; live?: boolean; quiet?: boolean; className?: string }
export interface ProvenanceProps { kind: ProvenanceKind; label?: string; source?: string; variant?: "linea"; title?: string; className?: string }
export interface ConnectionStatusProps { status: "conectado" | "sincronizando" | "offline" | "error"; detail?: string; onDark?: boolean; className?: string }
export interface BatchTagProps { code?: string; variety?: string; protocol?: string; date?: string; status?: BatchStatus; size?: "s"; className?: string }
export interface SensorReadingProps { name: string; icon?: IconName; value: number | null; unit: string; decimals?: number; status?: "normal" | "advertencia" | "error" | "desactualizado" | "sin-conexion"; live?: boolean; range?: string; updated?: string; kind?: ProvenanceKind; compact?: boolean; simulate?: boolean; jitter?: number; className?: string }
export interface MoistureMeterProps { initial?: number; current: number; target?: number; label?: string; kind?: ProvenanceKind; size?: "campo"; className?: string }
export interface ActuatorControlProps { name: string; icon?: IconName; power?: string; runtime?: string; state?: "encendido" | "apagado" | "bloqueado" | "error"; mode?: "automatico" | "manual"; guarded?: boolean; holdMs?: number; warning?: string; lockReason?: string; errorText?: string; size?: "campo"; transitionMs?: number; simulateFailure?: boolean; onChange?: (state: string) => void; onModeChange?: (mode: "automatico" | "manual") => void; className?: string }
export interface MeasurementFieldProps { label: string; unit?: string; value?: string; defaultValue?: string; onChange?: ChangeEventHandler<HTMLInputElement>; readOnly?: boolean; hint?: string; error?: string; placeholder?: string; className?: string }
export interface CalibrationRow { sensor: string; icon?: IconName; reference: number; measured: number; unit: string; adjustment?: number; tolerance?: number; decimals?: number; status?: Status; statusLabel?: string }
export interface CalibrationTableProps { rows: CalibrationRow[]; caption?: string }
export interface TimelineStage { label: string; time?: string; flag?: { status: Status; label: string } }
export interface ProcessTimelineProps { stages?: TimelineStage[]; current?: number; vertical?: boolean; className?: string }
export interface DryingCurveProps { measured?: [number, number][]; predicted?: [number, number][]; band?: [number, number, number][]; target?: number; xMax?: number; yMax?: number; anomalies?: [number, number][]; title?: string | false; xLabel?: string; width?: number; height?: number; className?: string }
export interface PredictionPanelProps { remaining?: string; low?: string; high?: string; eta?: string; confidence?: number; variables?: string[]; note?: string | false; size?: "campo"; className?: string }
export interface AlertItemProps { level: "informativa" | "advertencia" | "critica" | "resuelta"; title: string; description?: string; time?: string; batch?: string; sensor?: string; icon?: IconName; action?: string; onAction?: () => void; secondaryAction?: string; className?: string }
export interface ToastProps { tone?: "success" | "info" | "warning" | "error"; title: string; description?: string; label?: string; onClose?: (() => void) | false; className?: string }
export interface LandscapeProps { scene?: "valle" | "vacio" | "loma"; wide?: boolean; animated?: boolean; sky?: boolean; onDark?: boolean; preserve?: string; title?: string; className?: string }
export interface EmptyStateProps { title: string; text?: string; action?: string; actionIcon?: IconName; onAction?: () => void; scene?: "valle" | "vacio" | "loma"; animated?: boolean; className?: string }
export interface NavItem { id: string; label: string; icon: IconName; href?: string; badge?: number }
export interface SideNavProps { items?: NavItem[]; active?: string; onNavigate?: (id: string) => void; connection?: ConnectionStatusProps["status"]; device?: string; className?: string }
export interface ActiveBatchHeroProps { batch?: { code?: string; variety?: string; name?: string; protocol?: string; date?: string; status?: BatchStatus; initial?: number; moisture?: number; target?: number; temperature?: number; elapsed?: string; remaining?: string; power?: number }; status?: Status; verdict?: string; simulate?: boolean; animated?: boolean; className?: string }

export interface TextFieldProps { label: string; icon?: IconName; type?: string; value?: string; defaultValue?: string; onChange?: ChangeEventHandler<HTMLInputElement>; placeholder?: string; name?: string; autoComplete?: string; inputMode?: string; required?: boolean; hint?: string; error?: string; valid?: boolean; aside?: ReactNode; size?: "campo"; className?: string; style?: object }
export interface CheckboxProps { label: ReactNode; checked?: boolean; defaultChecked?: boolean; onChange?: ChangeEventHandler<HTMLInputElement>; name?: string; className?: string }
export interface LoginFormProps { size?: "campo"; defaultEmail?: string; defaultPassword?: string; onSuccess?: (d: { email: string }) => void; onForgot?: () => void; forgotHref?: string; footer?: ReactNode; submitLabel?: string; successLabel?: string; delay?: number; simulateError?: boolean; resetAfter?: number; baseDelay?: number; className?: string }
export declare function TextField(p: TextFieldProps): JSX.Element;
export declare function Checkbox(p: CheckboxProps): JSX.Element;
export declare function LoginForm(p: LoginFormProps): JSX.Element;
export interface HomeWidgetProps { kind: "humedad" | "prediccion" | "lote" | "equipo" | "alertas" | "curva"; size?: "s" | "m" | "l"; data?: { batch?: string; variety?: string; moisture?: number; initial?: number; target?: number; temperature?: number; remaining?: string; eta?: string; confidence?: number; updated?: string; alert?: string; alertTime?: string }; level?: "critica" | "advertencia" | "normal"; fanOn?: boolean; simulate?: boolean; href?: string; appHref?: string; label?: string; className?: string; style?: object }
export interface LockWidgetProps { shape?: "circle" | "rect" | "inline"; moisture?: number; initial?: number; target?: number; remaining?: string; batch?: string; style?: object }
export declare function HomeWidget(p: HomeWidgetProps): JSX.Element;
export declare function LockWidget(p: LockWidgetProps): JSX.Element;
export declare function Icon(p: IconProps): JSX.Element;
export declare function Button(p: ButtonProps): JSX.Element;
export declare function StatusMark(p: StatusMarkProps): JSX.Element;
export declare function Provenance(p: ProvenanceProps): JSX.Element;
export declare function ConnectionStatus(p: ConnectionStatusProps): JSX.Element;
export declare function BatchTag(p: BatchTagProps): JSX.Element;
export declare function SensorReading(p: SensorReadingProps): JSX.Element;
export declare function MoistureMeter(p: MoistureMeterProps): JSX.Element;
export declare function ActuatorControl(p: ActuatorControlProps): JSX.Element;
export declare function MeasurementField(p: MeasurementFieldProps): JSX.Element;
export declare function CalibrationTable(p: CalibrationTableProps): JSX.Element;
export declare function ProcessTimeline(p: ProcessTimelineProps): JSX.Element;
export declare function DryingCurve(p: DryingCurveProps): JSX.Element;
export declare function PredictionPanel(p: PredictionPanelProps): JSX.Element;
export declare function AlertItem(p: AlertItemProps): JSX.Element;
export declare function Toast(p: ToastProps): JSX.Element;
export declare function Landscape(p: LandscapeProps): JSX.Element;
export declare function EmptyState(p: EmptyStateProps): JSX.Element;
export declare function SideNav(p: SideNavProps): JSX.Element;
export declare function ActiveBatchHero(p: ActiveBatchHeroProps): JSX.Element;
/** Duración con unidades reducidas: <Duration value="18 h 20 min" /> */
export declare function Duration(p: { value: string; className?: string }): JSX.Element;
