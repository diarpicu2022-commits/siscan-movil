/** SISCAN — window.Siscan. React 18. Visible text in Spanish; identifiers in English. Numbers with comma decimals via Siscan.num(). */

export interface LogoProps { variant?: 'full' | 'symbol' | 'wordmark'; inverse?: boolean; height?: number; src?: string }
export declare function Logo(props: LogoProps): JSX.Element;
export interface IconProps { name: string; size?: number; stroke?: number; label?: string }
export declare function Icon(props: IconProps): JSX.Element;
export interface ButtonProps { variant?: 'primary' | 'secondary' | 'soft' | 'ghost' | 'danger'; size?: 'sm' | 'lg'; icon?: string; trailing?: string; block?: boolean; busy?: boolean; disabled?: boolean; onClick?: () => void; children: React.ReactNode }
export declare function Button(props: ButtonProps): JSX.Element;
export interface IconButtonProps { icon: string; label: string; count?: number; variant?: 'dark'; size?: number }
export declare function IconButton(props: IconButtonProps): JSX.Element;
export interface TextFieldProps { label?: string; value?: string; placeholder?: string; icon?: string; suffix?: string; hint?: string; error?: string; type?: string; size?: 'lg'; inputMode?: string }
export declare function TextField(props: TextFieldProps): JSX.Element;
export interface SegmentedProps { options: Array<{id: string; label: string; icon?: string}>; value?: string; label: string; block?: boolean; onChange?: (id: string) => void }
export declare function Segmented(props: SegmentedProps): JSX.Element;
export interface SwitchProps { checked?: boolean; disabled?: boolean; label: string; onChange?: (on: boolean) => void }
export declare function Switch(props: SwitchProps): JSX.Element;
export interface StatusPillProps { state: 'running' | 'paused' | 'alert' | 'offline'; live?: boolean; size?: 'sm'; children?: React.ReactNode }
export declare function StatusPill(props: StatusPillProps): JSX.Element;
export interface ToastProps { title: string; tone?: 'ok' | 'alert'; action?: string; children?: React.ReactNode }
export declare function Toast(props: ToastProps): JSX.Element;
export interface MetricCardProps { label: string; icon?: string; tone?: string; value?: number; text?: string; unit?: string; decimals?: number; delta?: number; goodWhen?: 'up' | 'down'; data?: number[]; live?: boolean; progress?: number; sub?: string; action?: boolean }
export declare function MetricCard(props: MetricCardProps): JSX.Element;
export interface RingGaugeProps { value: number; text?: string; label?: string; tone?: string; size?: number; stroke?: number; band?: [number, number]; gradient?: boolean }
export declare function RingGauge(props: RingGaugeProps): JSX.Element;
export interface MoistureChartProps { data: number[]; prediction?: number[]; labels?: string[]; target?: [number, number]; max?: number; live?: boolean; width?: number; height?: number; legend?: boolean; summary?: string }
export declare function MoistureChart(props: MoistureChartProps): JSX.Element;
export interface EnergyCardProps { solar: number; grid: number; cost: number; tariff?: number; bars: Array<{label: string; solar: number; grid: number}>; title?: string }
export declare function EnergyCard(props: EnergyCardProps): JSX.Element;
export interface ActuatorEnergyProps { rows: Array<{name: string; icon: string; kwh: number}>; tariff?: number }
export declare function ActuatorEnergy(props: ActuatorEnergyProps): JSX.Element;
export interface PredictionCardProps { remaining: string; min: string; max: string; eta: string; confidence: number; inputs?: Array<{label: string; icon: string}>; compact?: boolean }
export declare function PredictionCard(props: PredictionCardProps): JSX.Element;
export interface ProcessTimelineProps { phase: 'inicio' | 'calentamiento' | 'secado' | 'reduccion' | 'ajustes' | 'final'; times?: string[]; compact?: boolean; vertical?: boolean }
export declare function ProcessTimeline(props: ProcessTimelineProps): JSX.Element;
export interface MoistureScaleProps { value: number }
export declare function MoistureScale(props: MoistureScaleProps): JSX.Element;
export interface ConditionsTableProps { rows: Array<{name: string; icon: string; tone: string; min: string; avg: string; max: string}>; title?: string }
export declare function ConditionsTable(props: ConditionsTableProps): JSX.Element;
export interface WeatherCardProps { temp: number; hr: number; rad: number; sky?: string; rain?: string; place?: string }
export declare function WeatherCard(props: WeatherCardProps): JSX.Element;
export interface LandscapeProps { variant?: 'day' | 'dusk' | 'night'; airflow?: boolean; heater?: boolean; view?: string; fit?: string; wave?: 'bottom' }
export declare function Landscape(props: LandscapeProps): JSX.Element;
export interface ActiveBatchHeroProps { batch: string; moisture: number; progress?: number; left?: string; variety?: string; site?: string; time?: string; state?: string; stateLabel?: string; variant?: string; airflow?: boolean; heater?: boolean; children?: React.ReactNode }
export declare function ActiveBatchHero(props: ActiveBatchHeroProps): JSX.Element;
export interface BatchCardProps { name: string; variety: string; method: string; start: string; phase?: string; variant?: string; airflow?: boolean; title?: string }
export declare function BatchCard(props: BatchCardProps): JSX.Element;
export interface ActuatorControlProps { items: ActuatorRowProps[]; mode?: 'auto' | 'manual'; showMode?: boolean; title?: string; onToggle?: (index: number, on: boolean) => void }
export declare function ActuatorControl(props: ActuatorControlProps): JSX.Element;
export interface CommandLogProps { items: Array<{time: string; action: string; by: string; result?: 'ok' | 'fail'}> }
export declare function CommandLog(props: CommandLogProps): JSX.Element;
export interface SensorRowProps { name: string; meta?: string; value: string; icon?: string; tone?: string; state?: 'running' | 'paused' | 'alert' | 'offline'; ago?: string }
export declare function SensorRow(props: SensorRowProps): JSX.Element;
export interface AlertListProps { title?: string; items: AlertItemProps[]; link?: boolean }
export declare function AlertList(props: AlertListProps): JSX.Element;
export interface HealthCardProps { ok?: boolean; rows?: Array<[string, string, boolean]> }
export declare function HealthCard(props: HealthCardProps): JSX.Element;
export interface WeighingPanelProps { batch: string; sample: number; initial: number; weighings: Array<{t: string; w: number}>; draft?: string }
export declare function WeighingPanel(props: WeighingPanelProps): JSX.Element;
export interface GravimetCalibrationProps { points: Array<[string, string, string, string, string, boolean]> }
export declare function GravimetCalibration(props: GravimetCalibrationProps): JSX.Element;
export interface SensorCalibrationProps { rows: Array<{name: string; icon: string; tone: string; raw: string; fixed: string; gain: string; offset: string; ok: boolean}> }
export declare function SensorCalibration(props: SensorCalibrationProps): JSX.Element;
export interface DryerMapProps { pins: Array<{x: number; y: number; state: string; label?: string}>; counts?: Record<string, number>; stacked?: boolean; bare?: boolean; height?: number; title?: string }
export declare function DryerMap(props: DryerMapProps): JSX.Element;
export interface BatchTableProps { rows: Array<{n: string; site: string; variety: string; start: string; dur: string; final: string; active?: boolean}> }
export declare function BatchTable(props: BatchTableProps): JSX.Element;
export interface ProtocolComparisonProps { rows: Array<{label: string; a: number; b: number; fa: string; fb: string}>; note?: string }
export declare function ProtocolComparison(props: ProtocolComparisonProps): JSX.Element;
export interface EmptyStateProps { title?: string; body?: string; action?: string }
export declare function EmptyState(props: EmptyStateProps): JSX.Element;
export interface SidebarProps { active?: string; alerts?: number; collapsed?: boolean; offline?: boolean; onNav?: (id: string) => void }
export declare function Sidebar(props: SidebarProps): JSX.Element;
export interface TopBarProps { title?: string; subtitle?: string; temp?: number; alerts?: number; user?: string; userName?: string; weather?: boolean }
export declare function TopBar(props: TopBarProps): JSX.Element;
export interface AndroidNavProps { active?: string; alerts?: number; onChange?: (id: string) => void }
export declare function AndroidNav(props: AndroidNavProps): JSX.Element;
export interface ReadingTileProps { label: string; tone?: string; icon?: string; value?: number; text?: string; unit?: string; decimals?: number; data?: number[]; live?: boolean }
export declare function ReadingTile(props: ReadingTileProps): JSX.Element;
export interface HoldButtonProps { children?: React.ReactNode; done?: string }
export declare function HoldButton(props: HoldButtonProps): JSX.Element;
export interface NotificationCardProps { severity?: 'critical' | 'warning' | 'ok'; icon?: string; title: string; text: string; when?: string; actions?: string[] }
export declare function NotificationCard(props: NotificationCardProps): JSX.Element;
export interface HomeWidgetProps { size?: 's' | 'm'; moisture: number; temp?: number; hr?: number; progress?: number; left?: string; batch?: string }
export declare function HomeWidget(props: HomeWidgetProps): JSX.Element;
export interface CoffeeLeafArtProps { dark?: boolean; width?: number; className?: string }
export declare function CoffeeLeafArt(props: CoffeeLeafArtProps): JSX.Element;
export interface SelectProps { label?: string; icon?: string; value: string; options: string[]; onChange?: (v: string) => void }
export declare function Select(props: SelectProps): JSX.Element;
export interface CheckboxProps { checked: boolean; label: string; onChange?: (v: boolean) => void }
export declare function Checkbox(props: CheckboxProps): JSX.Element;
export interface ChipProps { tone?: 'brote' | 'neutral'; icon?: string; children: React.ReactNode }
export declare function Chip(props: ChipProps): JSX.Element;
export interface LiveDotProps { label?: string; off?: boolean; onLight?: boolean }
export declare function LiveDot(props: LiveDotProps): JSX.Element;
export interface AvatarProps { name: string }
export declare function Avatar(props: AvatarProps): JSX.Element;
export interface ProgressBarProps { value: number; label?: string }
export declare function ProgressBar(props: ProgressBarProps): JSX.Element;
export interface CardTitleProps { icon: string; title: string; link?: string }
export declare function CardTitle(props: CardTitleProps): JSX.Element;
export interface SparklineProps { data: number[]; tone?: 'temperatura' | 'tope' | 'humedad' | 'exterior' | 'grano' | 'potencia'; live?: boolean }
export declare function Sparkline(props: SparklineProps): JSX.Element;
export interface WeatherChipProps { place?: string; temp: number; sky?: string }
export declare function WeatherChip(props: WeatherChipProps): JSX.Element;
export interface ActuatorRowProps { name: string; kind: 'fan' | 'heater'; on: boolean; watts?: number; since?: string; onChange?: (v: boolean) => void }
export declare function ActuatorRow(props: ActuatorRowProps): JSX.Element;
export interface AlertItemProps { severity?: 'critical' | 'warning' | 'ok' | 'info'; title: string; meta?: string; time?: string; icon?: string }
export declare function AlertItem(props: AlertItemProps): JSX.Element;
export interface StatusLegendProps { counts: { running?: number; paused?: number; alert?: number; offline?: number } }
export declare function StatusLegend(props: StatusLegendProps): JSX.Element;
export interface PageHeaderProps { eyebrow?: string; title: string; subtitle?: string; actions?: React.ReactNode[] }
export declare function PageHeader(props: PageHeaderProps): JSX.Element;
export interface AppShellProps { active: string; alerts?: number; onNav?: (id: string) => void; collapsed?: boolean; offline?: boolean; children: React.ReactNode }
export declare function AppShell(props: AppShellProps): JSX.Element;
export interface LoginWebProps { variant?: 'day' | 'dusk' | 'night'; state?: 'idle' | 'busy' | 'error' }
export declare function LoginWeb(props: LoginWebProps): JSX.Element;
export interface AndroidFrameProps { nav?: string | false; dark?: boolean; lightStatus?: boolean; time?: string; fab?: { icon: string; label: string; text?: string }; children: React.ReactNode }
export declare function AndroidFrame(props: AndroidFrameProps): JSX.Element;
export interface AppBarProps { title: string; subtitle?: string; tone?: 'dark'; logo?: boolean; large?: boolean; back?: boolean; actions?: { icon: string; label: string; count?: number }[] }
export declare function AppBar(props: AppBarProps): JSX.Element;
export interface ListItemProps { icon: string; title: string; sub?: string; onClick?: () => void }
export declare function ListItem(props: ListItemProps): JSX.Element;
export interface WatchFrameProps { caption?: string; label?: string; time?: string | false; ambient?: boolean; className?: string; children?: React.ReactNode }
export declare function WatchFrame(props: WatchFrameProps): JSX.Element;
export interface WatchArcProps { value: number; tone?: string }
export declare function WatchArc(props: WatchArcProps): JSX.Element;
export interface WatchMonitorProps { moisture: number; progress?: number; caption?: string }
export declare function WatchMonitor(props: WatchMonitorProps): JSX.Element;
export interface WatchReadingsProps { items: { label: string; tone: string; value: string }[]; caption?: string }
export declare function WatchReadings(props: WatchReadingsProps): JSX.Element;
export interface WatchActuatorsProps { items: { name: string; kind: 'fan' | 'heater'; on: boolean }[]; mode?: string; caption?: string }
export declare function WatchActuators(props: WatchActuatorsProps): JSX.Element;
export interface WatchPredictionProps { caption?: string }
export declare function WatchPrediction(props: WatchPredictionProps): JSX.Element;
export interface WatchAlertProps { severity?: 'critical' | 'warning'; icon?: string; title?: string; text?: string; caption?: string }
export declare function WatchAlert(props: WatchAlertProps): JSX.Element;
export interface WatchWeighProps { caption?: string }
export declare function WatchWeigh(props: WatchWeighProps): JSX.Element;
export interface WatchConfirmProps { caption?: string; replay?: number }
export declare function WatchConfirm(props: WatchConfirmProps): JSX.Element;
export interface WatchTileProps { caption?: string }
export declare function WatchTile(props: WatchTileProps): JSX.Element;
export interface WatchFaceProps { alerts?: number; caption?: string }
export declare function WatchFace(props: WatchFaceProps): JSX.Element;
export interface WatchAmbientProps { caption?: string }
export declare function WatchAmbient(props: WatchAmbientProps): JSX.Element;
export interface WatchBatchesProps { items: { name: string; state: string; value: string; active?: boolean }[]; caption?: string }
export declare function WatchBatches(props: WatchBatchesProps): JSX.Element;
export declare function LocationCard(props: any): JSX.Element;
export declare function NewBatchForm(props: any): JSX.Element;
export declare function DryerPhoto(props: any): JSX.Element;
export declare function num(value: number, decimals?: number): string;
