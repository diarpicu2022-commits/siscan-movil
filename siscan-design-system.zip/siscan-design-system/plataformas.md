# Web y móvil

Mismo producto, distinta composición. Web (React + TypeScript + Tailwind, ≥ 1280 px) es para monitorear, analizar y administrar; móvil (Flutter, 390 px) es para mirar de reojo junto al secador. Comparten tokens, terminología, glifos de estado, iconos, ilustración y reglas de datos — no la maqueta.

## Web — Tailwind

Carga `tokens.css` del sistema (o copia sus variables) y mapea los tokens en `tailwind.config.ts`; nunca escribas hex sueltos en componentes.

```ts
// tailwind.config.ts
const v = (n: string) => `var(--${n})`;
export default {
  theme: {
    colors: {
      pergamino: v("pergamino"), papel: v("papel"), arena: v("arena"),
      linea: { DEFAULT: v("linea"), fuerte: v("linea-fuerte") },
      tierra: { DEFAULT: v("tierra"), suave: v("tierra-suave") },
      monte: v("monte"),
      arcilla: { DEFAULT: v("arcilla"), fuerte: v("arcilla-fuerte"), suave: v("arcilla-suave") },
      cafeto: { DEFAULT: v("cafeto"), suave: v("cafeto-suave") },
      panela: { DEFAULT: v("panela"), suave: v("panela-suave") },
      oxido: { DEFAULT: v("oxido"), suave: v("oxido-suave") },
      bruma: { DEFAULT: v("bruma"), suave: v("bruma-suave") },
      anil: { DEFAULT: v("anil"), suave: v("anil-suave") },
    },
    fontFamily: { editorial: v("font-editorial"), interfaz: v("font-interfaz"), instrumento: v("font-instrumento") },
    borderRadius: { etiqueta: v("radio-etiqueta"), control: v("radio-control"), hoja: v("radio-hoja"), loma: v("radio-loma"), grano: v("radio-grano") },
    boxShadow: { hoja: v("sombra-hoja"), control: v("sombra-control"), hundido: v("sombra-hundido") },
  },
};
```

Estructura sugerida: `components/{atoms,molecules,organisms,templates}` + `features/{monitoring,actuators,batches,gravimetric,calibration,history,alerts,prediction,synchronization}`. Los componentes de este sistema (`window.Siscan`) son la referencia visual y de comportamiento; reimpleméntalos en TSX con los mismos nombres y props (`components/index.d.ts`).

Modelo de datos listo para API, aun con datos simulados:

```ts
type Provenance = "medido" | "estimado" | "prediccion" | "desactualizado" | "no-disponible";
type SensorStatus = "normal" | "advertencia" | "error" | "sin-conexion" | "desactualizado";
type SensorReading = { sensorId: string; value: number | null; unit: string; timestamp: string; status: SensorStatus; provenance: Provenance };
type ActuatorState = "encendido" | "apagado" | "encendiendo" | "apagando" | "bloqueado" | "error";
type Actuator = { id: string; name: string; nominalPowerW: number; state: ActuatorState; mode: "automatico" | "manual"; guarded: boolean };
type DryingBatch = { id: string; code: string; variety: string; protocol: string; status: "programado" | "activo" | "secando" | "pausa" | "completado" | "detenido" | "alerta";
  initialMoisture: number; currentMoisture: number; targetMoisture: number; startedAt: string };
type AIPrediction = { remainingMinutes: number; lowMinutes: number; highMinutes: number; confidence: number; variables: string[]; createdAt: string };
type SyncStatus = "conectado" | "sincronizando" | "offline" | "error";
```

## Móvil — Flutter

Los tokens se exponen como una `ThemeExtension` para que ningún widget use `Color(0x…)` directo. Dos instancias: `SiscanTokens.dia` y `SiscanTokens.sol`.

```dart
@immutable
class SiscanTokens extends ThemeExtension<SiscanTokens> {
  final Color pergamino, papel, arena, linea, lineaFuerte, tierra, tierraSuave, monte,
      arcilla, arcillaSuave, cafeto, cafetoSuave, panela, panelaSuave, oxido, oxidoSuave,
      bruma, brumaSuave, anil, anilSuave, datoAgua;
  const SiscanTokens({required this.pergamino, /* … */ required this.datoAgua});

  static const dia = SiscanTokens(
    pergamino: Color(0xFFF3EADA), papel: Color(0xFFFBF6EC), arena: Color(0xFFEADFCB),
    linea: Color(0xFFD9C8AC), lineaFuerte: Color(0xFF8F7A5E),
    tierra: Color(0xFF2B1E15), tierraSuave: Color(0xFF66523F), monte: Color(0xFF24452F),
    arcilla: Color(0xFFA0431D), arcillaSuave: Color(0xFFF7E2D3),
    cafeto: Color(0xFF2F6A3C), cafetoSuave: Color(0xFFDCE8D2),
    panela: Color(0xFF8A5700), panelaSuave: Color(0xFFF6E2B3),
    oxido: Color(0xFF8C2A1F), oxidoSuave: Color(0xFFF2D3CC),
    bruma: Color(0xFF256A6E), brumaSuave: Color(0xFFD3E6E3),
    anil: Color(0xFF35557F), anilSuave: Color(0xFFDCE3EE), datoAgua: Color(0xFF3E7F92));
  // static const sol = SiscanTokens(...) — valores del tema "Pleno sol" en tokens.json
  @override SiscanTokens copyWith() => this;
  @override SiscanTokens lerp(SiscanTokens? o, double t) => t < .5 ? this : (o ?? this);
}
```

- Fuentes: empaqueta los `.woff2` del sistema convertidos a `.ttf` (o `google_fonts`: Fraunces, Atkinson Hyperlegible Next / Mono). `FontFeature.tabularFigures()` en toda lectura.
- Widgets: `CustomPaint` para el lecho de humedad, la curva y el paisaje (las capas de `Landscape` se trasladan 1:1 a `Path`); `AnimatedContainer` para la palanca; `TweenAnimationBuilder` para el conteo de humedad. Respeta `MediaQuery.disableAnimations`.
- Navegación inferior: Inicio · Controles · Predicción · Alertas. Inicio en este orden: lote activo → humedad → temperatura → tiempo → predicción → equipo → alertas.
- Usa `size: "campo"` (palanca 132×60, lectura 76 px, botones ≥ 48 px). Detrás de toda cifra crítica, superficie sólida — nunca transparencia sobre la ilustración.
- Sin conexión, la barra superior muestra "Modo offline" en `panela` y cada lectura pasa a "Última lectura" con su hora; los datos se encolan y se sincronizan al volver la red.

## Widgets del sistema

Usa el paquete `home_widget` para compartir el último estado (humedad, temperatura, tiempo restante, confianza, alerta más grave y hora de actualización) entre Flutter y los widgets nativos: Glance/AppWidget en Android y WidgetKit en iOS. Cada widget abre la app en su pantalla con un deep link (`siscan://lote/B`, `siscan://controles`). El ventilador puede conmutarse desde el widget (intención interactiva de Android / `AppIntent` de iOS 17); la resistencia no. Diseño de referencia: `HomeWidget` y `LockWidget`.
